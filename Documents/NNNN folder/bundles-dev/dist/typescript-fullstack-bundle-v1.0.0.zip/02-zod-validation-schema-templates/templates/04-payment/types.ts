import { z } from 'zod';
import { creditCardSchema, paymentMethodSchema, billingDetailsSchema } from './schemas';

export type CreditCardInput = z.infer<typeof creditCardSchema>;
export type PaymentMethodInput = z.infer<typeof paymentMethodSchema>;
export type BillingDetailsInput = z.infer<typeof billingDetailsSchema>;

export type PaymentMethodType = PaymentMethodInput['type'];
