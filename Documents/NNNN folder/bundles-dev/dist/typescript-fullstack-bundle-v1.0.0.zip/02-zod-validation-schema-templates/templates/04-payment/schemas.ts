import { z } from 'zod';

// ─── Card Number (Luhn-validated) ──────────────────────────────────────────

function luhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let isOdd = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    if (isOdd) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    sum += digit;
    isOdd = !isOdd;
  }
  return sum % 10 === 0;
}

const cardNumberField = z
  .string()
  .trim()
  .transform((v) => v.replace(/\s/g, ''))
  .pipe(
    z
      .string()
      .regex(/^\d{13,19}$/, 'Card number must be 13–19 digits')
      .refine(luhnCheck, 'Invalid card number')
  );

// ─── Expiry MM/YY ──────────────────────────────────────────────────────────

const expiryField = z
  .string()
  .trim()
  .regex(/^(0[1-9]|1[0-2])\/?([0-9]{2})$/, 'Use MM/YY format')
  .refine((v) => {
    const [mm, yy] = v.replace('/', '').match(/.{1,2}/g)!.map(Number);
    const expiry = new Date(2000 + yy, mm - 1, 1);
    const now = new Date();
    now.setDate(1);
    now.setHours(0, 0, 0, 0);
    return expiry >= now;
  }, 'Card has expired');

// ─── CVV ───────────────────────────────────────────────────────────────────

const cvvField = z.string().trim().regex(/^\d{3,4}$/, 'CVV must be 3 or 4 digits');

// ─── Credit Card ───────────────────────────────────────────────────────────

export const creditCardSchema = z.object({
  number: cardNumberField,
  expiry: expiryField,
  cvv: cvvField,
  cardholderName: z
    .string()
    .trim()
    .min(1, 'Cardholder name is required')
    .max(100)
    .regex(/^[a-zA-Z\s\-'.]+$/, 'Name contains invalid characters'),
});

// ─── Payment Method Selection ─────────────────────────────────────────────

export const paymentMethodSchema = z.discriminatedUnion('type', [
  z.object({
    type: z.literal('card'),
    card: creditCardSchema,
  }),
  z.object({
    type: z.literal('saved_card'),
    paymentMethodId: z.string().min(1, 'Payment method ID is required'),
  }),
]);

// ─── Billing Details ──────────────────────────────────────────────────────

export const billingDetailsSchema = z.object({
  name: z.string().trim().min(1, 'Billing name is required').max(200),
  email: z.string().trim().toLowerCase().email('Invalid email'),
  phone: z
    .string()
    .trim()
    .regex(/^\+?[0-9\s\-().]{7,20}$/, 'Invalid phone number')
    .optional(),
  addressLine1: z.string().trim().min(1, 'Address is required').max(200),
  city: z.string().trim().min(1, 'City is required').max(100),
  postalCode: z.string().trim().min(1).max(20),
  country: z.string().length(2).toUpperCase(),
});
