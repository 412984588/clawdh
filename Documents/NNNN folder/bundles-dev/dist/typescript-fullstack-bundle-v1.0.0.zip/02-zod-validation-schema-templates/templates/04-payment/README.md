# Payment Schemas

Zod schemas for credit card and billing details validation.

## Schemas

| Schema | Purpose |
|--------|---------|
| `creditCardSchema` | Card number (Luhn), expiry (MM/YY + not expired), CVV, cardholder name |
| `paymentMethodSchema` | Discriminated union: new card vs saved payment method |
| `billingDetailsSchema` | Name, email, phone, address for billing |

## Key Validation

- **Card number** — strips spaces, validates 13–19 digits, runs Luhn algorithm
- **Expiry** — validates `MM/YY` format and checks the card hasn't expired against current month
- **CVV** — 3 or 4 digits (Amex uses 4)
- **paymentMethodSchema** — discriminated union on `type` field handles new vs. saved card flows

## Usage

```typescript
import { paymentMethodSchema } from './schemas';
import type { PaymentMethodInput } from './types';

const result = paymentMethodSchema.safeParse(req.body);
if (!result.success) {
  return res.status(400).json({ errors: result.error.flatten() });
}
const method: PaymentMethodInput = result.data;

if (method.type === 'card') {
  // method.card.number is normalized (no spaces)
}
```

## Security Notes

- Never log or store raw card data — validate at the edge and immediately pass to your payment processor (Stripe, etc.)
- The Luhn check prevents typos but is not a fraud prevention measure
- CVV should never be stored under any circumstances (PCI DSS)
