# Search & Filter Schemas

Zod schemas for query params — pagination, sorting, text search, date ranges, and status filters.

## Schemas

| Schema | Purpose |
|--------|---------|
| `paginationSchema` | page + limit with defaults and max |
| `cursorPaginationSchema` | cursor-based pagination with direction |
| `sortSchema(fields)` | Generic sort factory for typed field names |
| `searchQuerySchema` | Text search `q` + pagination |
| `dateRangeSchema` | from/to date range with coercion and ordering check |
| `statusFilterSchema` | Single or multi-value status filter |
| `fullSearchSchema` | All of the above combined |

## Usage

```typescript
import { fullSearchSchema, sortSchema } from './schemas';
import type { FullSearchInput } from './types';

// In your API route handler (Express/Fastify/Next.js)
const result = fullSearchSchema.safeParse(req.query);
if (!result.success) {
  return res.status(400).json({ errors: result.error.flatten().fieldErrors });
}
const filters: FullSearchInput = result.data;
// filters.page is a number (coerced from string query param)
// filters.from is a Date or undefined
```

## Design Notes

- All numeric fields use `z.coerce` — query params are always strings, coercion avoids manual `parseInt`
- `limit` capped at 100 to prevent large result set attacks
- `status` accepts single string or array (handles both `?status=active` and `?status=active&status=pending`)
- `dateRangeSchema` cross-validates `from <= to`
