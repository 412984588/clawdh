import { z } from 'zod';

// ─── Coercion helpers for query params ────────────────────────────────────

const coercedPositiveInt = z.coerce.number().int().positive();
const coercedNonNegInt = z.coerce.number().int().nonnegative();

// ─── Pagination ────────────────────────────────────────────────────────────

export const paginationSchema = z.object({
  page: coercedPositiveInt.default(1),
  limit: coercedPositiveInt.max(100, 'Limit cannot exceed 100').default(20),
});

export const cursorPaginationSchema = z.object({
  cursor: z.string().optional(),
  limit: coercedPositiveInt.max(100).default(20),
  direction: z.enum(['next', 'prev']).default('next'),
});

// ─── Sort ──────────────────────────────────────────────────────────────────

export function sortSchema<T extends string>(allowedFields: readonly T[]) {
  return z.object({
    sortBy: z.enum(allowedFields as [T, ...T[]]).optional(),
    sortOrder: z.enum(['asc', 'desc']).default('desc'),
  });
}

// ─── Text Search ───────────────────────────────────────────────────────────

export const searchQuerySchema = z.object({
  q: z.string().trim().max(200).optional(),
  ...paginationSchema.shape,
});

// ─── Date Range Filter ─────────────────────────────────────────────────────

export const dateRangeSchema = z
  .object({
    from: z.coerce.date().optional(),
    to: z.coerce.date().optional(),
  })
  .refine(
    (data) => !data.from || !data.to || data.from <= data.to,
    { message: 'from must be before to', path: ['from'] }
  );

// ─── Generic Filters ──────────────────────────────────────────────────────

export const statusFilterSchema = z.object({
  status: z
    .string()
    .or(z.array(z.string()))
    .transform((v) => (Array.isArray(v) ? v : [v]))
    .optional(),
});

// ─── Full Search + Filter Params ──────────────────────────────────────────

export const fullSearchSchema = searchQuerySchema
  .merge(statusFilterSchema)
  .extend({
    from: z.coerce.date().optional(),
    to: z.coerce.date().optional(),
    offset: coercedNonNegInt.optional(),
  })
  .refine(
    (data) => !data.from || !data.to || data.from <= data.to,
    { message: 'from must be before to', path: ['from'] }
  );
