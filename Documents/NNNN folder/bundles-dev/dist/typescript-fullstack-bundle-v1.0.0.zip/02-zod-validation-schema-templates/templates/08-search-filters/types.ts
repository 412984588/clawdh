import { z } from 'zod';
import {
  paginationSchema,
  cursorPaginationSchema,
  searchQuerySchema,
  dateRangeSchema,
  statusFilterSchema,
  fullSearchSchema,
} from './schemas';

export type PaginationInput = z.infer<typeof paginationSchema>;
export type CursorPaginationInput = z.infer<typeof cursorPaginationSchema>;
export type SearchQueryInput = z.infer<typeof searchQuerySchema>;
export type DateRangeInput = z.infer<typeof dateRangeSchema>;
export type StatusFilterInput = z.infer<typeof statusFilterSchema>;
export type FullSearchInput = z.infer<typeof fullSearchSchema>;

export type SortOrder = 'asc' | 'desc';
