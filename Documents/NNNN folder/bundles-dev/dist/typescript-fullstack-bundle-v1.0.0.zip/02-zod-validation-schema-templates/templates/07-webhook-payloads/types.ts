import { z } from 'zod';
import {
  genericWebhookSchema,
  githubPushWebhookSchema,
  githubPullRequestWebhookSchema,
  stripeEventSchema,
  stripeCheckoutCompletedSchema,
} from './schemas';

export type GenericWebhook = z.infer<typeof genericWebhookSchema>;
export type GitHubPushWebhook = z.infer<typeof githubPushWebhookSchema>;
export type GitHubPullRequestWebhook = z.infer<typeof githubPullRequestWebhookSchema>;
export type StripeEvent = z.infer<typeof stripeEventSchema>;
export type StripeCheckoutCompleted = z.infer<typeof stripeCheckoutCompletedSchema>;
