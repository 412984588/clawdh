# Webhook Payload Schemas

Zod schemas for validating incoming webhook payloads from GitHub, Stripe, and a generic format.

## Schemas

| Schema | Source |
|--------|--------|
| `genericWebhookSchema` | Generic webhook (id, event, timestamp, data) |
| `githubPushWebhookSchema` | GitHub push event |
| `githubPullRequestWebhookSchema` | GitHub pull_request event |
| `stripeEventSchema` | Stripe event envelope |
| `stripeCheckoutCompletedSchema` | Stripe `checkout.session.completed` |

## Usage

```typescript
import { stripeCheckoutCompletedSchema } from './schemas';

// In your webhook handler (after signature verification)
app.post('/webhooks/stripe', async (req, res) => {
  const event = stripeEventSchema.safeParse(req.body);
  if (!event.success) return res.status(400).send('Invalid payload');

  if (event.data.type === 'checkout.session.completed') {
    const checkout = stripeCheckoutCompletedSchema.safeParse(req.body);
    if (checkout.success) {
      // checkout.data.data.object.customer_email is typed
    }
  }
  res.sendStatus(200);
});
```

## Design Notes

- Always verify webhook signatures BEFORE running Zod validation
- `stripeCheckoutCompletedSchema` extends `stripeEventSchema` — reuse the envelope, narrow the event type
- GitHub schemas cover the most common webhook events; add more by extending the base patterns
