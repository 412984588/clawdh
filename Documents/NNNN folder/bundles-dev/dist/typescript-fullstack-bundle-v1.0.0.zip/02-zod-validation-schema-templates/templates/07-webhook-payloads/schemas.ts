import { z } from 'zod';

// ─── Generic Webhook ───────────────────────────────────────────────────────

export const genericWebhookSchema = z.object({
  id: z.string(),
  event: z.string().min(1),
  timestamp: z.string().datetime().or(z.number()),
  data: z.record(z.unknown()),
  metadata: z.record(z.unknown()).optional(),
});

// ─── GitHub Webhooks ───────────────────────────────────────────────────────

const githubUserSchema = z.object({
  id: z.number(),
  login: z.string(),
  avatar_url: z.string().url(),
  html_url: z.string().url(),
});

const githubRepoSchema = z.object({
  id: z.number(),
  name: z.string(),
  full_name: z.string(),
  html_url: z.string().url(),
  private: z.boolean(),
  default_branch: z.string(),
});

export const githubPushWebhookSchema = z.object({
  ref: z.string(),
  before: z.string(),
  after: z.string(),
  repository: githubRepoSchema,
  pusher: z.object({ name: z.string(), email: z.string().email().optional() }),
  sender: githubUserSchema,
  commits: z.array(
    z.object({
      id: z.string(),
      message: z.string(),
      timestamp: z.string(),
      added: z.array(z.string()),
      removed: z.array(z.string()),
      modified: z.array(z.string()),
      author: z.object({ name: z.string(), email: z.string() }),
    })
  ),
});

export const githubPullRequestWebhookSchema = z.object({
  action: z.enum(['opened', 'closed', 'synchronize', 'reopened', 'labeled']),
  number: z.number().int().positive(),
  pull_request: z.object({
    id: z.number(),
    number: z.number(),
    title: z.string(),
    state: z.enum(['open', 'closed']),
    merged: z.boolean(),
    body: z.string().nullable(),
    html_url: z.string().url(),
    user: githubUserSchema,
    base: z.object({ ref: z.string(), sha: z.string() }),
    head: z.object({ ref: z.string(), sha: z.string() }),
  }),
  repository: githubRepoSchema,
  sender: githubUserSchema,
});

// ─── Stripe Webhooks ───────────────────────────────────────────────────────

export const stripeEventSchema = z.object({
  id: z.string().startsWith('evt_'),
  object: z.literal('event'),
  type: z.string(),
  created: z.number().int(),
  livemode: z.boolean(),
  data: z.object({
    object: z.record(z.unknown()),
    previous_attributes: z.record(z.unknown()).optional(),
  }),
  api_version: z.string(),
});

export const stripeCheckoutCompletedSchema = stripeEventSchema.extend({
  type: z.literal('checkout.session.completed'),
  data: z.object({
    object: z.object({
      id: z.string(),
      customer: z.string().nullable(),
      customer_email: z.string().email().nullable(),
      payment_status: z.enum(['paid', 'unpaid', 'no_payment_required']),
      amount_total: z.number().nullable(),
      currency: z.string().length(3),
      metadata: z.record(z.string()),
    }),
  }),
});
