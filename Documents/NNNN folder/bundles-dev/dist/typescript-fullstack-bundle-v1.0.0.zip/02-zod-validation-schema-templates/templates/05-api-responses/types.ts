import { z } from 'zod';
import {
  apiErrorSchema,
  errorResponseSchema,
  validationErrorResponseSchema,
  apiResponseSchema,
} from './schemas';

export type ApiError = z.infer<typeof apiErrorSchema>;
export type ErrorResponse = z.infer<typeof errorResponseSchema>;
export type ValidationErrorResponse = z.infer<typeof validationErrorResponseSchema>;
export type ApiResponse = z.infer<typeof apiResponseSchema>;

// Generic success response type (use with successResponseSchema<T>)
export type SuccessResponse<T> = {
  success: true;
  data: T;
  meta?: { requestId?: string; timestamp?: string };
};

// Generic paginated response type
export type PaginatedResponse<T> = {
  success: true;
  data: T[];
  pagination: {
    page: number;
    pageSize: number;
    total: number;
    totalPages: number;
    hasNextPage: boolean;
    hasPreviousPage: boolean;
  };
};
