# API Response Schemas

Zod schemas for standardized API response envelopes — success, error, paginated, and validation error formats.

## Schemas

| Schema | Purpose |
|--------|---------|
| `successResponseSchema<T>` | Generic success envelope with `data: T` |
| `errorResponseSchema` | Error envelope with `code` + `message` |
| `paginatedResponseSchema<T>` | Paginated list with full pagination metadata |
| `validationErrorResponseSchema` | 422-style field-level validation errors |

## Usage

```typescript
import { successResponseSchema, paginatedResponseSchema } from './schemas';
import { z } from 'zod';

// Validate an API response at runtime
const userSchema = z.object({ id: z.string(), email: z.string() });
const responseSchema = successResponseSchema(userSchema);
const result = responseSchema.safeParse(await res.json());

// Typed paginated list
const listSchema = paginatedResponseSchema(userSchema);
type UserListResponse = z.infer<typeof listSchema>;
```

## Design Notes

- `success: z.literal(true/false)` enables discriminated union narrowing on the client
- `fieldErrors: z.record(z.array(z.string()))` matches Zod's own `.flatten().fieldErrors` format — easy to echo back from your API handler
- Generic factory functions (`successResponseSchema`, `paginatedResponseSchema`) keep the schema composable
