import { z } from 'zod';

// ─── Success Response ──────────────────────────────────────────────────────

export function successResponseSchema<T extends z.ZodTypeAny>(dataSchema: T) {
  return z.object({
    success: z.literal(true),
    data: dataSchema,
    meta: z
      .object({
        requestId: z.string().optional(),
        timestamp: z.string().datetime().optional(),
      })
      .optional(),
  });
}

// ─── Error Response ────────────────────────────────────────────────────────

export const apiErrorSchema = z.object({
  code: z.string(),
  message: z.string(),
  field: z.string().optional(),
  details: z.record(z.unknown()).optional(),
});

export const errorResponseSchema = z.object({
  success: z.literal(false),
  error: apiErrorSchema,
  errors: z.array(apiErrorSchema).optional(),
});

// ─── Paginated Response ────────────────────────────────────────────────────

export function paginatedResponseSchema<T extends z.ZodTypeAny>(itemSchema: T) {
  return z.object({
    success: z.literal(true),
    data: z.array(itemSchema),
    pagination: z.object({
      page: z.number().int().positive(),
      pageSize: z.number().int().positive(),
      total: z.number().int().nonnegative(),
      totalPages: z.number().int().nonnegative(),
      hasNextPage: z.boolean(),
      hasPreviousPage: z.boolean(),
    }),
  });
}

// ─── Validation Error (422 style) ─────────────────────────────────────────

export const validationErrorResponseSchema = z.object({
  success: z.literal(false),
  error: z.object({
    code: z.literal('VALIDATION_ERROR'),
    message: z.string(),
    fieldErrors: z.record(z.array(z.string())),
  }),
});

// ─── API Response union ────────────────────────────────────────────────────

export const apiResponseSchema = z.union([
  errorResponseSchema,
  validationErrorResponseSchema,
]);
