import { z } from 'zod';

// ─── Coercion helpers ──────────────────────────────────────────────────────

/** Coerces string "true"/"false"/"1"/"0" to boolean */
const boolEnv = z
  .string()
  .transform((v) => v === 'true' || v === '1')
  .pipe(z.boolean());

/** Coerces string to positive integer */
const portEnv = z.string().pipe(
  z.coerce.number().int().min(1).max(65535)
);

const positiveIntEnv = z.string().pipe(z.coerce.number().int().positive());

// ─── Core App Env ──────────────────────────────────────────────────────────

export const coreEnvSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: portEnv.default('3000'),
  HOST: z.string().default('0.0.0.0'),
  APP_URL: z.string().url('APP_URL must be a valid URL'),
  LOG_LEVEL: z
    .enum(['trace', 'debug', 'info', 'warn', 'error', 'fatal'])
    .default('info'),
});

// ─── Database Env ──────────────────────────────────────────────────────────

export const databaseEnvSchema = z.object({
  DATABASE_URL: z.string().url('DATABASE_URL must be a valid connection string'),
  DATABASE_POOL_MIN: positiveIntEnv.default('1'),
  DATABASE_POOL_MAX: positiveIntEnv.default('10'),
  DATABASE_SSL: boolEnv.default('false'),
});

// ─── Auth Env ──────────────────────────────────────────────────────────────

export const authEnvSchema = z.object({
  JWT_SECRET: z.string().min(32, 'JWT_SECRET must be at least 32 characters'),
  JWT_EXPIRES_IN: z.string().default('7d'),
  REFRESH_TOKEN_SECRET: z.string().min(32, 'REFRESH_TOKEN_SECRET must be at least 32 characters'),
  SESSION_SECRET: z.string().min(32).optional(),
  BCRYPT_ROUNDS: positiveIntEnv.default('12'),
});

// ─── Email Env ────────────────────────────────────────────────────────────

export const emailEnvSchema = z.object({
  SMTP_HOST: z.string().min(1, 'SMTP_HOST is required'),
  SMTP_PORT: portEnv.default('587'),
  SMTP_USER: z.string().optional(),
  SMTP_PASS: z.string().optional(),
  SMTP_FROM: z.string().email('SMTP_FROM must be a valid email'),
  SMTP_SECURE: boolEnv.default('false'),
});

// ─── Full App Env ─────────────────────────────────────────────────────────

export const appEnvSchema = coreEnvSchema
  .merge(databaseEnvSchema)
  .merge(authEnvSchema)
  .merge(emailEnvSchema);
