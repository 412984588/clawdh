import { z } from 'zod';
import {
  coreEnvSchema,
  databaseEnvSchema,
  authEnvSchema,
  emailEnvSchema,
  appEnvSchema,
} from './schemas';

export type CoreEnv = z.infer<typeof coreEnvSchema>;
export type DatabaseEnv = z.infer<typeof databaseEnvSchema>;
export type AuthEnv = z.infer<typeof authEnvSchema>;
export type EmailEnv = z.infer<typeof emailEnvSchema>;
export type AppEnv = z.infer<typeof appEnvSchema>;
