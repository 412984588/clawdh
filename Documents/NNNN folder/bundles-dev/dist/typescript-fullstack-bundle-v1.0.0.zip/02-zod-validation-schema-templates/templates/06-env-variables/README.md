# Environment Variables Schemas

Zod schemas for type-safe `.env` parsing — with coercion, defaults, and validation.

## Schemas

| Schema | Variables |
|--------|-----------|
| `coreEnvSchema` | NODE_ENV, PORT, HOST, APP_URL, LOG_LEVEL |
| `databaseEnvSchema` | DATABASE_URL, pool min/max, DATABASE_SSL |
| `authEnvSchema` | JWT_SECRET, REFRESH_TOKEN_SECRET, SESSION_SECRET, BCRYPT_ROUNDS |
| `emailEnvSchema` | SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM |
| `appEnvSchema` | All of the above merged |

## Usage

```typescript
import { appEnvSchema } from './schemas';
import type { AppEnv } from './types';

// At app startup — crashes with descriptive error if any var is invalid
const env: AppEnv = appEnvSchema.parse(process.env);

export { env };
```

## Design Notes

- **Coercion** — PORT and pool sizes are `string → number` (all env vars are strings)
- **Boolean coercion** — `"true"` / `"1"` → `true`, everything else → `false`
- **Defaults** — sensible defaults for optional vars; required vars (secrets, URLs) have no default and fail loudly
- **Composable** — use individual schemas per module, or `appEnvSchema` for the full set
- Crash on startup is intentional — misconfigured env should not run silently
