# User Profile Schemas

Zod schemas for user profile management flows.

## Schemas

| Schema | Purpose |
|--------|---------|
| `updateProfileSchema` | Display name, bio, website, location, avatar |
| `updateEmailSchema` | Email change with password confirmation |
| `socialLinksSchema` | Twitter handle, GitHub username, LinkedIn URL |
| `preferencesSchema` | Theme, language, notification preferences |

## Validation Highlights

- **avatarUrl / website** — optional but must be a valid URL if provided; `z.literal('')` allows clearing the field
- **Twitter** — strips leading `@` via `.transform()`, validates 1–15 alphanumeric/underscore chars
- **GitHub** — validates username format (no leading/trailing hyphens, max 39 chars)
- **language** — enforces 2-letter ISO code
- **theme** — typed enum: `"light" | "dark" | "system"`

## Usage

```typescript
import { updateProfileSchema } from './schemas';
import type { UpdateProfileInput } from './types';

const result = updateProfileSchema.safeParse(req.body);
if (!result.success) {
  return res.status(400).json({ errors: result.error.flatten().fieldErrors });
}
const profile: UpdateProfileInput = result.data;
```
