import { z } from 'zod';

// ─── Display Name ──────────────────────────────────────────────────────────

const displayNameField = z
  .string()
  .trim()
  .min(1, 'Display name is required')
  .max(50, 'Display name too long');

// ─── URL field (optional) ─────────────────────────────────────────────────

const optionalUrl = z
  .string()
  .trim()
  .url('Must be a valid URL')
  .optional()
  .or(z.literal(''));

// ─── Update Profile ────────────────────────────────────────────────────────

export const updateProfileSchema = z.object({
  displayName: displayNameField,
  bio: z.string().trim().max(500, 'Bio must be 500 characters or less').optional(),
  website: optionalUrl,
  location: z.string().trim().max(100).optional(),
  avatarUrl: z.string().url('Avatar must be a valid URL').optional().or(z.literal('')),
});

// ─── Update Email ──────────────────────────────────────────────────────────

export const updateEmailSchema = z.object({
  newEmail: z.string().trim().toLowerCase().email('Invalid email address'),
  password: z.string().min(1, 'Password required to change email'),
});

// ─── Social Links ──────────────────────────────────────────────────────────

export const socialLinksSchema = z.object({
  twitter: z
    .string()
    .trim()
    .regex(/^@?[a-zA-Z0-9_]{1,15}$/, 'Invalid Twitter handle')
    .transform((v) => v.replace(/^@/, ''))
    .optional()
    .or(z.literal('')),
  github: z
    .string()
    .trim()
    .regex(/^[a-zA-Z0-9]([a-zA-Z0-9-]{0,37}[a-zA-Z0-9])?$/, 'Invalid GitHub username')
    .optional()
    .or(z.literal('')),
  linkedin: optionalUrl,
});

// ─── Preferences ───────────────────────────────────────────────────────────

export const preferencesSchema = z.object({
  theme: z.enum(['light', 'dark', 'system']).default('system'),
  language: z.string().length(2, 'Use 2-letter language code (e.g. en)').default('en'),
  emailNotifications: z.boolean().default(true),
  marketingEmails: z.boolean().default(false),
  timezone: z.string().min(1).optional(),
});
