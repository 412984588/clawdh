import { z } from 'zod';
import {
  updateProfileSchema,
  updateEmailSchema,
  socialLinksSchema,
  preferencesSchema,
} from './schemas';

export type UpdateProfileInput = z.infer<typeof updateProfileSchema>;
export type UpdateEmailInput = z.infer<typeof updateEmailSchema>;
export type SocialLinksInput = z.infer<typeof socialLinksSchema>;
export type PreferencesInput = z.infer<typeof preferencesSchema>;

export type Theme = PreferencesInput['theme'];
