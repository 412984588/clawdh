import { z } from 'zod';

// ─── Feature Flags ─────────────────────────────────────────────────────────

export const featureFlagsSchema = z.object({
  enableBetaFeatures: z.boolean().default(false),
  enableAnalytics: z.boolean().default(true),
  enableMaintenanceMode: z.boolean().default(false),
  enableRateLimit: z.boolean().default(true),
  enableNewDashboard: z.boolean().default(false),
  flags: z.record(z.boolean()).optional(), // dynamic flags
});

// ─── Rate Limit Config ─────────────────────────────────────────────────────

export const rateLimitConfigSchema = z.object({
  enabled: z.boolean().default(true),
  windowMs: z.number().int().positive().default(60_000),
  maxRequests: z.number().int().positive().default(100),
  skipSuccessfulRequests: z.boolean().default(false),
  keyPrefix: z.string().default('rl:'),
});

// ─── Cache Config ──────────────────────────────────────────────────────────

export const cacheConfigSchema = z.object({
  ttlSeconds: z.number().int().positive().default(300),
  maxSize: z.number().int().positive().default(1000),
  checkPeriodSeconds: z.number().int().positive().default(600),
  useCompression: z.boolean().default(false),
});

// ─── CORS Config ───────────────────────────────────────────────────────────

export const corsConfigSchema = z.object({
  origin: z
    .union([z.string(), z.array(z.string()), z.literal('*')])
    .default('*'),
  methods: z
    .array(z.enum(['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS', 'HEAD']))
    .default(['GET', 'POST', 'PUT', 'PATCH', 'DELETE']),
  allowedHeaders: z.array(z.string()).default(['Content-Type', 'Authorization']),
  credentials: z.boolean().default(false),
  maxAge: z.number().int().positive().default(86400),
});

// ─── Full App Config ───────────────────────────────────────────────────────

export const appConfigSchema = z.object({
  app: z.object({
    name: z.string().min(1),
    version: z.string().regex(/^\d+\.\d+\.\d+$/, 'Use semver format'),
    environment: z.enum(['development', 'staging', 'production']),
    debug: z.boolean().default(false),
  }),
  server: z.object({
    port: z.number().int().min(1).max(65535).default(3000),
    host: z.string().default('0.0.0.0'),
    requestTimeout: z.number().int().positive().default(30_000),
    bodyLimit: z.string().default('1mb'),
  }),
  features: featureFlagsSchema,
  rateLimit: rateLimitConfigSchema,
  cache: cacheConfigSchema,
  cors: corsConfigSchema,
});
