# Config Files Schemas

Zod schemas for structured application configuration — feature flags, rate limiting, CORS, cache, and full app config.

## Schemas

| Schema | Purpose |
|--------|---------|
| `featureFlagsSchema` | Feature toggles with dynamic flag map |
| `rateLimitConfigSchema` | Rate limit window, max requests, key prefix |
| `cacheConfigSchema` | TTL, max size, compression |
| `corsConfigSchema` | Origins, methods, headers, credentials |
| `appConfigSchema` | Full app config composed from all above |

## Usage

```typescript
import { appConfigSchema } from './schemas';
import type { AppConfig } from './types';

// Load from JSON file or config object
import rawConfig from './config.json';
const config: AppConfig = appConfigSchema.parse(rawConfig);

// All missing fields are filled with defaults
console.log(config.server.port);       // 3000
console.log(config.cors.maxAge);       // 86400
console.log(config.features.enableAnalytics); // true
```

## Design Notes

- All fields have sensible `default()` values — only `app.name`, `app.version`, `app.environment` are required
- `featureFlagsSchema.flags` is a `z.record(z.boolean())` for dynamic flags from your feature flag service
- `appConfigSchema` composes sub-schemas as named fields — easy to extend with your own sections
- Version field validates semver format
