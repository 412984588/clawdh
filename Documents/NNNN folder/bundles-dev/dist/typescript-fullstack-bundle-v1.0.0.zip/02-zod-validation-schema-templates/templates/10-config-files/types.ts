import { z } from 'zod';
import {
  featureFlagsSchema,
  rateLimitConfigSchema,
  cacheConfigSchema,
  corsConfigSchema,
  appConfigSchema,
} from './schemas';

export type FeatureFlags = z.infer<typeof featureFlagsSchema>;
export type RateLimitConfig = z.infer<typeof rateLimitConfigSchema>;
export type CacheConfig = z.infer<typeof cacheConfigSchema>;
export type CorsConfig = z.infer<typeof corsConfigSchema>;
export type AppConfig = z.infer<typeof appConfigSchema>;

export type Environment = AppConfig['app']['environment'];
