# Auth Forms Schemas

Zod schemas for the five core authentication flows.

## Schemas

| Schema | Fields |
|--------|--------|
| `loginSchema` | email, password, rememberMe |
| `registerSchema` | email, password, confirmPassword, name, acceptTerms |
| `forgotPasswordSchema` | email |
| `resetPasswordSchema` | token, password, confirmPassword |
| `changePasswordSchema` | currentPassword, newPassword, confirmNewPassword |

## Validation Rules

- **email** — trimmed, lowercased, RFC email format
- **password** (new/reset) — 8–128 chars, at least one uppercase + one digit
- **password** (login) — any non-empty string (don't hint at rules on login)
- **confirmPassword** — cross-field equality check via `.refine()`
- **acceptTerms** — must be literal `true`

## Usage

```typescript
import { loginSchema } from './schemas';
import type { LoginInput } from './types';

const result = loginSchema.safeParse(formData);
if (!result.success) {
  // result.error.flatten().fieldErrors
}
const data: LoginInput = result.data;
```

## Design Notes

- Email is normalized (trim + lowercase) via `.transform()` inside the field — no manual normalization needed downstream
- `rememberMe` defaults to `false` so it's always present in parsed output
- `registerSchema` uses `.refine()` at the object level for cross-field password match
- `changePasswordSchema` rejects same-as-current passwords to encourage rotation
