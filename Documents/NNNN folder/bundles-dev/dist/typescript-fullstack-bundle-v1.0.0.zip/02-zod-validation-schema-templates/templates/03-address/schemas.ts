import { z } from 'zod';

// ─── Country Codes ─────────────────────────────────────────────────────────

const countryCodeField = z
  .string()
  .length(2, 'Use 2-letter ISO country code')
  .toUpperCase();

// ─── Postal Code — country-aware regex map ─────────────────────────────────

const postalPatterns: Record<string, RegExp> = {
  US: /^\d{5}(-\d{4})?$/,
  CA: /^[A-Z]\d[A-Z]\s?\d[A-Z]\d$/i,
  GB: /^[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}$/i,
  AU: /^\d{4}$/,
  DE: /^\d{5}$/,
  FR: /^\d{5}$/,
  JP: /^\d{3}-?\d{4}$/,
  CN: /^\d{6}$/,
};

// ─── Address Schema ────────────────────────────────────────────────────────

export const addressSchema = z
  .object({
    line1: z.string().trim().min(1, 'Address line 1 is required').max(200),
    line2: z.string().trim().max(200).optional(),
    city: z.string().trim().min(1, 'City is required').max(100),
    state: z.string().trim().max(100).optional(),
    postalCode: z.string().trim().min(1, 'Postal code is required').max(20),
    country: countryCodeField,
  })
  .refine(
    (data) => {
      const pattern = postalPatterns[data.country.toUpperCase()];
      if (!pattern) return true; // allow unknown countries
      return pattern.test(data.postalCode);
    },
    (data) => ({
      message: `Invalid postal code for country ${data.country}`,
      path: ['postalCode'],
    })
  );

// ─── Shipping Address ──────────────────────────────────────────────────────

export const shippingAddressSchema = addressSchema.and(
  z.object({
    firstName: z.string().trim().min(1, 'First name is required').max(100),
    lastName: z.string().trim().min(1, 'Last name is required').max(100),
    phone: z
      .string()
      .trim()
      .regex(/^\+?[0-9\s\-().]{7,20}$/, 'Invalid phone number')
      .optional(),
    instructions: z.string().trim().max(500).optional(),
  })
);

// ─── Billing Address ───────────────────────────────────────────────────────

export const billingAddressSchema = addressSchema.and(
  z.object({
    name: z.string().trim().min(1, 'Billing name is required').max(200),
    company: z.string().trim().max(200).optional(),
    vatNumber: z.string().trim().max(50).optional(),
    sameAsShipping: z.boolean().optional().default(false),
  })
);
