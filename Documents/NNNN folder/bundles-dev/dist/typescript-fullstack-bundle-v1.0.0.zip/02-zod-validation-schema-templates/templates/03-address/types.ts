import { z } from 'zod';
import { addressSchema, shippingAddressSchema, billingAddressSchema } from './schemas';

export type AddressInput = z.infer<typeof addressSchema>;
export type ShippingAddressInput = z.infer<typeof shippingAddressSchema>;
export type BillingAddressInput = z.infer<typeof billingAddressSchema>;
