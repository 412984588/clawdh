# Address Schemas

Zod schemas for shipping and billing address validation with country-aware postal code checking.

## Schemas

| Schema | Purpose |
|--------|---------|
| `addressSchema` | Base address (line1, city, postalCode, country) |
| `shippingAddressSchema` | Base + firstName, lastName, phone, instructions |
| `billingAddressSchema` | Base + name, company, vatNumber, sameAsShipping |

## Country-Aware Postal Validation

Built-in regex patterns for: US, CA, GB, AU, DE, FR, JP, CN.
Unknown country codes pass validation (no false positives for unsupported countries).

## Usage

```typescript
import { shippingAddressSchema } from './schemas';
import type { ShippingAddressInput } from './types';

const result = shippingAddressSchema.safeParse(formData);
if (!result.success) {
  return { errors: result.error.flatten().fieldErrors };
}
const address: ShippingAddressInput = result.data;
// address.country is always uppercase (transformed)
```

## Design Notes

- Country is normalized to uppercase via `.toUpperCase()` transform
- `billingAddressSchema` uses `.and()` to compose with base address — Prisma-style composition
- `sameAsShipping` flag lets UI skip billing address entry; your business logic handles the copy
