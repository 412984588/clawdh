import { z } from 'zod';
import {
  step1AccountSchema,
  step2ProfileSchema,
  step3PlanSchema,
  onboardingStepSchema,
  onboardingSubmissionSchema,
  wizardStateSchema,
} from './schemas';

export type Step1AccountInput = z.infer<typeof step1AccountSchema>;
export type Step2ProfileInput = z.infer<typeof step2ProfileSchema>;
export type Step3PlanInput = z.infer<typeof step3PlanSchema>;
export type OnboardingStep = z.infer<typeof onboardingStepSchema>;
export type OnboardingSubmission = z.infer<typeof onboardingSubmissionSchema>;
export type WizardState = z.infer<typeof wizardStateSchema>;

export type PlanType = Step3PlanInput['plan'];
export type BillingCycle = Step3PlanInput['billingCycle'];
