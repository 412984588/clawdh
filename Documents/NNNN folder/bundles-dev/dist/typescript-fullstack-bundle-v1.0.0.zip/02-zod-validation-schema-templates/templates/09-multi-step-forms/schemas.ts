import { z } from 'zod';

// ─── Onboarding Wizard Example (3 steps) ─────────────────────────────────

export const step1AccountSchema = z.object({
  step: z.literal(1),
  email: z.string().trim().toLowerCase().email('Invalid email'),
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .regex(/[0-9]/, 'Must contain a number'),
  confirmPassword: z.string(),
});

// Refined version for full validation (discriminatedUnion requires plain ZodObject)
export const step1AccountRefinedSchema = step1AccountSchema.refine(
  (d) => d.password === d.confirmPassword,
  { message: 'Passwords do not match', path: ['confirmPassword'] }
);

export const step2ProfileSchema = z.object({
  step: z.literal(2),
  firstName: z.string().trim().min(1, 'First name required').max(50),
  lastName: z.string().trim().min(1, 'Last name required').max(50),
  jobTitle: z.string().trim().max(100).optional(),
  company: z.string().trim().max(200).optional(),
});

export const step3PlanSchema = z.object({
  step: z.literal(3),
  plan: z.enum(['free', 'starter', 'pro', 'enterprise']),
  billingCycle: z.enum(['monthly', 'annual']).default('monthly'),
  couponCode: z.string().trim().toUpperCase().optional(),
  agreedToTerms: z.literal(true, {
    errorMap: () => ({ message: 'You must agree to the terms' }),
  }),
});

// ─── Discriminated union over all steps ───────────────────────────────────

export const onboardingStepSchema = z.discriminatedUnion('step', [
  step1AccountSchema,   // base (without refine) for union routing
  step2ProfileSchema,
  step3PlanSchema,
]);

// ─── Complete wizard submission ────────────────────────────────────────────

export const onboardingSubmissionSchema = z.object({
  account: step1AccountSchema.omit({ step: true }),
  profile: step2ProfileSchema.omit({ step: true }),
  plan: step3PlanSchema.omit({ step: true }),
});

// ─── Generic step state schema ─────────────────────────────────────────────

export const wizardStateSchema = z.object({
  currentStep: z.number().int().min(1),
  totalSteps: z.number().int().min(1),
  completedSteps: z.array(z.number().int()),
  data: z.record(z.unknown()),
});
