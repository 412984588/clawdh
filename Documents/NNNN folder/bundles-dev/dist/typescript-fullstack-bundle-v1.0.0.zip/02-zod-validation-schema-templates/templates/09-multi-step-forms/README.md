# Multi-Step Form Schemas

Zod schemas for wizard/multi-step forms with per-step validation and final submission schema.

## Schemas

| Schema | Purpose |
|--------|---------|
| `step1AccountSchema` | Step 1 — email + password (base, for union routing) |
| `step1AccountRefinedSchema` | Step 1 — same + password match refine |
| `step2ProfileSchema` | Step 2 — name, job title, company |
| `step3PlanSchema` | Step 3 — plan selection, billing cycle, terms |
| `onboardingStepSchema` | Discriminated union over all steps (for routing) |
| `onboardingSubmissionSchema` | Final merged submission object |
| `wizardStateSchema` | Generic wizard state tracker |

## Pattern: Base vs Refined Schemas

Cross-field refinements (like password match) return `ZodEffects`, which can't be used in `z.discriminatedUnion()`. Solution: keep a plain `ZodObject` base schema for routing, and a separate refined schema for full validation.

## Usage

```typescript
import { onboardingStepSchema, step1AccountRefinedSchema } from './schemas';

// Route to the right schema per step
const step = onboardingStepSchema.safeParse(formData);
if (!step.success) return showErrors(step.error);

if (step.data.step === 1) {
  // Run full refinement validation before advancing
  const refined = step1AccountRefinedSchema.safeParse(formData);
  if (!refined.success) return showErrors(refined.error);
}
```

## Design Notes

- `onboardingStepSchema` uses `z.discriminatedUnion` on the `step` literal field for zero-overhead routing
- `onboardingSubmissionSchema` omits `step` discriminant fields — only stores business data
- `wizardStateSchema` is framework-agnostic state tracking (store in localStorage or server session)
