# Zod Validation Schema Templates

**10 production-ready Zod v3 schemas — validation schemas + TypeScript types + README per template.**

Stop writing the same form validation from scratch. Each template is a battle-tested Zod schema for a common web app pattern, ready to drop in and customize.

## What's Inside

Every schema includes 3 files:
- `schemas.ts` — Zod v3 schemas with refinements, transforms, and error messages
- `types.ts` — TypeScript types inferred from schemas (`z.infer<typeof ...>`)
- `README.md` — field documentation, validation rules, and usage examples

## Schemas by Tier

### Starter ($19) — 4 schemas
| Schema | Covers |
|--------|--------|
| `01-auth-forms` | Login, register, forgot-password, reset-password, change-password |
| `02-user-profile` | Profile update, display name, bio, avatar URL, social links |
| `03-address` | Shipping/billing address with country-aware postal code validation |
| `04-payment` | Credit card, billing details, payment method selection |

### Pro ($39) — 10 schemas
Everything in Starter, plus:
| Schema | Covers |
|--------|--------|
| `05-api-responses` | Success/error wrappers, paginated responses, validation error format |
| `06-env-variables` | Typed `.env` parsing with defaults, port validation, URL validation |
| `07-webhook-payloads` | GitHub, Stripe, and generic webhook payload validation |
| `08-search-filters` | Search query, filters, sort, pagination with coercion |
| `09-multi-step-forms` | Step-by-step wizard schemas with union discriminants |
| `10-config-files` | App config, feature flags, database config, rate limiting config |

## Quick Start

```typescript
import { loginSchema } from './templates/01-auth-forms/schemas';

const result = loginSchema.safeParse({ email: 'user@example.com', password: 'secret' });
if (!result.success) {
  console.error(result.error.flatten());
}
```

## Requirements
- Zod 3+
- TypeScript 5+
