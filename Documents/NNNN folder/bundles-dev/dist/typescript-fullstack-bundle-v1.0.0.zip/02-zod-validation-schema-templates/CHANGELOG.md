# Changelog

## [1.0.0] — 2026-03-21

### Added
- 10 Zod v3 validation schema templates across 2 tiers ($19/$39)
- Each template: schemas.ts + types.ts + README.md
- Starter (4): Auth Forms, User Profile, Address, Payment
- Pro (10): + API Responses, Env Variables, Webhook Payloads, Search Filters, Multi-step Forms, Config Files
- All schemas use Zod 3+ with refinements, transforms, and custom error messages
- TypeScript types inferred via `z.infer<typeof ...>` (no drift)
- Coercion helpers for query params, numeric env vars, and boolean flags
