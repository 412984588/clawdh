# Changelog

## [1.0.0] — 2024-01-01

### Added

- `01-tsconfig-presets`: App, Node, Lib, and Base tsconfig presets
- `02-eslint-configs`: ESLint v9 flat configs for TypeScript and React
- `03-prettier-configs`: Prettier config with optional Tailwind CSS plugin
- `04-combo-starters`: React+Vite, Node ESM, Next.js App Router combos
- `05-migration-guides`: Phased migration guides for strict mode and ESLint v9
- `06-monorepo-configs`: Project reference configs for monorepos
- `07-strict-configs`: Ultra-strict tsconfig and ESLint strict type-checked rules
- `08-path-aliases`: Path alias configs for Vite, Next.js, and Node.js
- `09-build-tool-configs`: Vite, tsup, and esbuild build configs
- `10-testing-configs`: Vitest and Jest configs with TypeScript support
