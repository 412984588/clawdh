# 04 — Combo Starters

Complete `tsconfig + eslint + prettier` combos for the most common project setups. Each subfolder is a drop-in starter.

## Starters

| Folder | Stack |
|--------|-------|
| `react-vite/` | React 18 + Vite + TypeScript |
| `node-esm/` | Node.js 20+ ESM + TypeScript |
| `nextjs/` | Next.js 14+ App Router + TypeScript |

## Usage

Copy the contents of the relevant subfolder into your project root.
