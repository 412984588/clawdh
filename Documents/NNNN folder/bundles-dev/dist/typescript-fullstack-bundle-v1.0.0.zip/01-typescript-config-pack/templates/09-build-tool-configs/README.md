# 09 — Build Tool Configs

TypeScript-aware configs for popular build tools.

## Files

| File | Tool |
|------|------|
| `vite.config.ts` | Vite 5 with TypeScript + path aliases |
| `tsup.config.ts` | tsup — zero-config TypeScript library bundler |
| `esbuild.config.mjs` | esbuild — fast TypeScript bundler script |

## Vite

Best for: React/Vue/Svelte SPAs, component libraries.

```bash
npm install -D vite @vitejs/plugin-react typescript
```

## tsup

Best for: npm packages, CLI tools, Node.js libraries.

```bash
npm install -D tsup typescript
npx tsup src/index.ts
```

## esbuild

Best for: custom build pipelines, ultra-fast compilation.

```bash
npm install -D esbuild typescript
node esbuild.config.mjs
```
