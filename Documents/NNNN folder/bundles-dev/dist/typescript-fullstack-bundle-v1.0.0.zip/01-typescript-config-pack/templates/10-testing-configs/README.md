# 10 — Testing Configs

TypeScript-compatible test configurations for Vitest and Jest.

## Files

| File | Tool |
|------|------|
| `vitest.config.ts` | Vitest — fast Vite-native test runner |
| `jest.config.ts` | Jest with ts-jest transformer |
| `tsconfig.test.json` | tsconfig override for test files |

## Vitest (Recommended)

```bash
npm install -D vitest @vitest/ui
```

Run tests:
```bash
npx vitest
npx vitest --ui       # web UI
npx vitest --coverage # coverage report
```

## Jest + ts-jest

```bash
npm install -D jest ts-jest @types/jest
```

Run tests:
```bash
npx jest
npx jest --coverage
```

## tsconfig.test.json

Extends your app `tsconfig.json` but allows test-specific overrides like looser typing for mocks:

```json
{
  "extends": "./tsconfig.json",
  "compilerOptions": {
    "noUncheckedIndexedAccess": false
  },
  "include": ["src", "tests"]
}
```
