# 07 — Strict Configs

Ultra-strict TypeScript configs for production codebases that want maximum type safety.

## Files

| File | Level |
|------|-------|
| `tsconfig.strict.json` | Strict + additional safety flags |
| `tsconfig.ultra-strict.json` | All of strict + experimental strictness |
| `eslint.strict.config.js` | ESLint with TypeScript strict type-checked rules |

## What's Different from `strict: true`

`tsconfig.strict.json` adds on top of `strict`:
- `noUncheckedIndexedAccess` — array index access returns `T | undefined`
- `exactOptionalPropertyTypes` — optional props must be explicitly `undefined`, not absent
- `noPropertyAccessFromIndexSignature` — index signatures must use bracket notation

`tsconfig.ultra-strict.json` further adds:
- `noImplicitReturns` — all code paths must return
- `noFallthroughCasesInSwitch` — switch cases must break
- `noImplicitOverride` — override keyword required when overriding methods
