# 02 — ESLint Configs (Flat Config)

ESLint v9 flat config files for TypeScript projects. Drop-in ready.

## Files

| File | Use Case |
|------|----------|
| `eslint.config.js` | Base config — TypeScript + recommended rules |
| `eslint.config.react.js` | React app — adds JSX and React hooks rules |
| `eslint.config.strict.js` | Stricter ruleset for production codebases |

## Setup

```bash
npm install -D eslint @typescript-eslint/eslint-plugin @typescript-eslint/parser
```

For React config, also install:
```bash
npm install -D eslint-plugin-react eslint-plugin-react-hooks
```

## Usage

Copy the relevant file to your project root as `eslint.config.js` and run:

```bash
npx eslint src/
```
