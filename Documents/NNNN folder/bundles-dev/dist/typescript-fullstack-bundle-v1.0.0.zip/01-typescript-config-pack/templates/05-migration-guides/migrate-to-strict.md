# Migrating to `strict: true` Without Breaking Your Build

## The Problem

Turning on `strict: true` all at once typically generates hundreds of type errors. This guide shows a phased approach.

## Phase 1: Enable strict flags one at a time

Start with the least disruptive flags:

```json
{
  "compilerOptions": {
    "noImplicitAny": false,
    "strictNullChecks": true,
    "strictFunctionTypes": true
  }
}
```

Fix all `strictFunctionTypes` + `strictNullChecks` errors first.

## Phase 2: Add the harder flags

```json
{
  "compilerOptions": {
    "noImplicitAny": true,
    "strictNullChecks": true,
    "strictFunctionTypes": true,
    "strictBindCallApply": true,
    "strictPropertyInitialization": true
  }
}
```

## Phase 3: Enable `strict: true`

Once the above pass, replace the individual flags with:

```json
{
  "compilerOptions": {
    "strict": true
  }
}
```

## Quick Fixes for Common Errors

| Error | Fix |
|-------|-----|
| `Object is possibly 'null'` | Add null check or `!` non-null assertion |
| `Parameter 'x' implicitly has an 'any' type` | Add explicit type annotation |
| `Property has no initializer` | Add `!` or assign in constructor |
