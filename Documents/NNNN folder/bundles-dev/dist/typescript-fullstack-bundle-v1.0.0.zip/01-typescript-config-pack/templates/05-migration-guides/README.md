# 05 — Migration Guides

Step-by-step guides for migrating TypeScript configurations to modern settings.

## Guides

| File | Migration |
|------|-----------|
| `migrate-to-strict.md` | Enable `strict: true` without breaking your build |
| `migrate-to-eslint-flat.md` | Migrate from `.eslintrc` to ESLint v9 flat config |
| `migrate-moduleresolution.md` | Update `moduleResolution` for modern bundlers/Node |

## When to Use

- Upgrading an existing project from JS to TypeScript
- Tightening type safety on a legacy codebase
- Upgrading from ESLint v8 (`.eslintrc`) to v9 (flat config)
