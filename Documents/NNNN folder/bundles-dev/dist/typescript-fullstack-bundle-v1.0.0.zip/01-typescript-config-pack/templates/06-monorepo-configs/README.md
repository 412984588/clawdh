# 06 — Monorepo Configs

TypeScript project reference configs for monorepos (pnpm workspaces / Turborepo / Nx).

## Files

| File | Purpose |
|------|---------|
| `tsconfig.base.json` | Shared base — all packages extend this |
| `tsconfig.root.json` | Root-level tsconfig with all project references |
| `package-tsconfig.json` | Template tsconfig for an individual package |

## Setup (pnpm + Turborepo)

1. Copy `tsconfig.base.json` to repo root
2. Copy `tsconfig.root.json` to repo root as `tsconfig.json`
3. For each package in `packages/*`, copy `package-tsconfig.json` as `tsconfig.json` and update `references`

## Key Concepts

- **Project references** (`references` array) enable incremental builds
- Each package has `composite: true` so TypeScript can track it as a dependency
- The root `tsconfig.json` only references other configs — it doesn't compile anything directly
