# 03 — Prettier Configs

Prettier configuration files for TypeScript projects, with optional Tailwind CSS plugin support.

## Files

| File | Use Case |
|------|----------|
| `.prettierrc.json` | Standard Prettier config |
| `.prettierrc.tailwind.json` | Config with Tailwind CSS class sorting |
| `.prettierignore` | Standard ignore patterns |

## Setup

```bash
npm install -D prettier
# For Tailwind variant:
npm install -D prettier-plugin-tailwindcss
```

## Usage

```bash
npx prettier --write src/
```

Add to `package.json` scripts:
```json
{
  "scripts": {
    "format": "prettier --write src/",
    "format:check": "prettier --check src/"
  }
}
```
