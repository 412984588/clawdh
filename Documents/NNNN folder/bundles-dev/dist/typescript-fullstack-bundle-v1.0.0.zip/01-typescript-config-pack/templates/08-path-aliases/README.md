# 08 — Path Aliases

Configure TypeScript path aliases (`@/`) for clean imports across Vite, Next.js, and Node.js projects.

## Files

| File | Tool |
|------|------|
| `tsconfig.paths.json` | Base tsconfig with path alias setup |
| `vite.config.paths.ts` | Vite config that mirrors tsconfig paths |
| `alias-guide.md` | How to set up aliases in different tools |

## Common Pattern

Add to `tsconfig.json` → `compilerOptions.paths`:

```json
{
  "paths": {
    "@/*": ["./src/*"],
    "@components/*": ["./src/components/*"],
    "@utils/*": ["./src/utils/*"],
    "@types/*": ["./src/types/*"]
  }
}
```

Then import cleanly:

```ts
import { Button } from "@/components/Button";
import { formatDate } from "@utils/date";
```

## Important

TypeScript paths are compile-time only — your bundler (Vite/webpack) or runtime (Node via `tsconfig-paths`) must also be configured. See `alias-guide.md`.
