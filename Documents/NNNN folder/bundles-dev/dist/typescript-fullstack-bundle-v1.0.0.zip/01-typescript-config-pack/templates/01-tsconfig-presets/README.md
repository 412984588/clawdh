# 01 — tsconfig Presets

Ready-to-use `tsconfig.json` presets for the most common TypeScript project types.

## Files

| File | Use Case |
|------|----------|
| `tsconfig.app.json` | SPA / frontend app (React, Vue, Svelte) |
| `tsconfig.node.json` | Node.js server / CLI (ESM or CJS) |
| `tsconfig.lib.json` | Reusable library / npm package |
| `tsconfig.base.json` | Shared base — extend from this |

## Usage

Copy the relevant file to your project root and rename it `tsconfig.json`, or extend it:

```json
{
  "extends": "./tsconfig.base.json",
  "compilerOptions": {
    "outDir": "./dist"
  }
}
```

## Key Decisions

- `strict: true` everywhere — catch bugs at compile time
- `moduleResolution: "bundler"` for app presets — works with Vite / esbuild / webpack 5
- `moduleResolution: "node16"` for Node.js — correct ESM/CJS interop
- `declaration: true` on lib preset — consumers get types automatically
