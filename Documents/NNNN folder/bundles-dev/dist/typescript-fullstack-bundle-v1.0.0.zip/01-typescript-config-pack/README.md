# TypeScript Config Pack

Production-ready `tsconfig.json`, ESLint flat configs, and Prettier configs for TypeScript projects — copy-paste ready.

## What's Included

### Starter — $19

| Template | Contents |
|----------|----------|
| 01 — tsconfig Presets | App / Node / Lib / Base presets |
| 02 — ESLint Configs | Flat config for TS, React, strict |
| 03 — Prettier Configs | Standard + Tailwind variant |
| 04 — Combo Starters | React+Vite, Node ESM, Next.js combos |

### Pro — $39 (adds)

| Template | Contents |
|----------|----------|
| 05 — Migration Guides | Strict migration, ESLint v9, moduleResolution |
| 06 — Monorepo Configs | Project references for pnpm/Turborepo |
| 07 — Strict Configs | Ultra-strict tsconfig + ESLint strict rules |

### Complete — $59 (adds)

| Template | Contents |
|----------|----------|
| 08 — Path Aliases | @/ aliases for Vite, Next.js, Node |
| 09 — Build Tool Configs | Vite, tsup, esbuild configs |
| 10 — Testing Configs | Vitest + Jest with TypeScript |

## Quick Start

1. Find the template matching your stack
2. Copy the config file(s) to your project root
3. Adjust `include`/`exclude` paths if needed
4. Run `npx tsc --noEmit` to verify

## Pricing

| Tier | Price | Templates |
|------|-------|-----------|
| Starter | $19 | 4 template sets |
| Pro | $39 | 7 template sets |
| Complete | $59 | All 10 template sets |

## License

MIT — use in unlimited projects, commercial or personal.
