# E-commerce Schema

Orders, products, customers, payments. Covers the core data model for a standard online store.

## Tables

| Table | Purpose |
|-------|---------|
| `customers` | Buyer accounts |
| `addresses` | Shipping/billing addresses per customer |
| `categories` | Hierarchical product categories |
| `products` | Product catalog with inventory |
| `orders` | Purchase orders with status lifecycle |
| `order_items` | Line items within an order |
| `payments` | Payment records linked to orders |

## Design Decisions

**Prices in cents**: `price_cents INTEGER` avoids floating-point rounding issues. Always store monetary values as integers.

**Order status**: String not enum — easier to migrate. Use a CHECK constraint or application-level validation.

**Stock**: `stock_qty` on products for simple inventory. For warehouse-level stock, see `07-inventory`.

## Common Queries

```sql
-- Order with items and products
SELECT o.*, oi.quantity, p.name, p.price_cents
FROM orders o
JOIN order_items oi ON oi.order_id = o.id
JOIN products p ON p.id = oi.product_id
WHERE o.id = $1;

-- Revenue by day
SELECT date_trunc('day', created_at) AS day, sum(total_cents) / 100.0 AS revenue
FROM orders WHERE status = 'delivered'
GROUP BY 1 ORDER BY 1;
```
