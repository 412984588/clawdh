// Workflow Engine — TypeScript Types
// PostgreSQL 14+ · Prisma 5+ · TypeScript 5+

export type TriggerType = 'manual' | 'webhook' | 'schedule' | 'event';

export type StepType = 'task' | 'condition' | 'wait' | 'parallel' | 'loop';

export type WorkflowInstanceStatus =
  | 'pending'
  | 'running'
  | 'paused'
  | 'completed'
  | 'failed'
  | 'cancelled'
  | 'timed_out';

export type StepExecutionStatus =
  | 'pending'
  | 'running'
  | 'completed'
  | 'failed'
  | 'skipped'
  | 'cancelled'
  | 'timed_out';

// ─── Workflow Definition ───────────────────────────────────────────────────

export interface RetryConfig {
  maxAttempts: number;
  backoff: 'fixed' | 'exponential' | 'linear';
  initialDelaySeconds?: number;
  maxDelaySeconds?: number;
}

export interface Workflow {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  version: number;
  definition: Record<string, unknown>;
  triggerType: TriggerType;
  triggerConfig: Record<string, unknown>;
  timeoutSeconds: number | null;
  isActive: boolean;
  createdBy: string | null;
  createdAt: Date;
  updatedAt: Date;
}

export type CreateWorkflow = Omit<Workflow, 'id' | 'version' | 'createdAt' | 'updatedAt'> & {
  id?: string;
  version?: number;
  isActive?: boolean;
};

// ─── Workflow Step ─────────────────────────────────────────────────────────

export interface WorkflowStep {
  id: string;
  workflowId: string;
  stepKey: string;
  name: string;
  stepType: StepType;
  handler: string;
  config: Record<string, unknown>;
  inputMapping: Record<string, string>;
  outputMapping: Record<string, string>;
  retryConfig: RetryConfig;
  timeoutSeconds: number | null;
  positionX: number | null;
  positionY: number | null;
  createdAt: Date;
}

export type CreateWorkflowStep = Omit<WorkflowStep, 'id' | 'createdAt'> & {
  id?: string;
  retryConfig?: Partial<RetryConfig>;
};

// ─── Workflow Transition ───────────────────────────────────────────────────

export interface WorkflowTransition {
  id: string;
  workflowId: string;
  fromStepKey: string;
  toStepKey: string;
  condition: string | null;  // expression evaluated at runtime
  label: string | null;
  createdAt: Date;
}

// ─── Workflow Instance ─────────────────────────────────────────────────────

export interface WorkflowInstance<
  TInput = unknown,
  TOutput = unknown,
  TContext = Record<string, unknown>
> {
  id: string;
  workflowId: string;
  workflowVersion: number;
  status: WorkflowInstanceStatus;
  input: TInput;
  output: TOutput | null;
  context: TContext;
  error: string | null;
  errorStepKey: string | null;
  triggerType: TriggerType;
  triggerPayload: Record<string, unknown>;
  startedAt: Date | null;
  completedAt: Date | null;
  timeoutAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

export type StartWorkflow<TInput = unknown> = {
  workflowId: string;
  input: TInput;
  triggerType: TriggerType;
  triggerPayload?: Record<string, unknown>;
};

// ─── Step Execution ────────────────────────────────────────────────────────

export interface StepExecution<TInput = unknown, TOutput = unknown> {
  id: string;
  instanceId: string;
  workflowId: string;
  stepKey: string;
  attempt: number;
  status: StepExecutionStatus;
  input: TInput;
  output: TOutput | null;
  error: string | null;
  startedAt: Date | null;
  completedAt: Date | null;
  durationMs: number | null;  // generated column
  createdAt: Date;
  updatedAt: Date;
}

// ─── Helpers ───────────────────────────────────────────────────────────────

/** Returns true if an instance has reached a terminal state */
export function isTerminal(status: WorkflowInstanceStatus): boolean {
  return ['completed', 'failed', 'cancelled', 'timed_out'].includes(status);
}

/** Returns true if a step can be retried */
export function canRetry(
  execution: StepExecution,
  retryConfig: RetryConfig
): boolean {
  return (
    execution.status === 'failed' &&
    execution.attempt < retryConfig.maxAttempts
  );
}
