-- Workflow Engine Schema
-- PostgreSQL 14+
-- DAG-based workflow definitions with step execution tracking

-- Workflow definitions (templates/blueprints)
CREATE TABLE workflows (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,               -- machine-readable identifier
    description TEXT,
    version INTEGER NOT NULL DEFAULT 1,
    definition JSONB NOT NULL DEFAULT '{}',  -- full DAG definition (nodes, edges)
    trigger_type TEXT NOT NULL DEFAULT 'manual', -- manual / webhook / schedule / event
    trigger_config JSONB NOT NULL DEFAULT '{}',
    timeout_seconds INTEGER,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_by UUID,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_workflows_slug ON workflows (slug) WHERE is_active = true;
CREATE INDEX idx_workflows_trigger ON workflows (trigger_type) WHERE is_active = true;

-- Workflow steps (nodes in the DAG)
CREATE TABLE workflow_steps (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workflow_id UUID NOT NULL REFERENCES workflows(id) ON DELETE CASCADE,
    step_key TEXT NOT NULL,                  -- unique within workflow, used in edges
    name TEXT NOT NULL,
    step_type TEXT NOT NULL,                 -- task / condition / wait / parallel / loop
    handler TEXT NOT NULL,                   -- e.g. "send_email", "call_api"
    config JSONB NOT NULL DEFAULT '{}',      -- handler-specific configuration
    input_mapping JSONB NOT NULL DEFAULT '{}',  -- map workflow context to step input
    output_mapping JSONB NOT NULL DEFAULT '{}', -- map step output to workflow context
    retry_config JSONB NOT NULL DEFAULT '{"max_attempts": 3, "backoff": "exponential"}',
    timeout_seconds INTEGER,
    position_x INTEGER,                      -- for visual workflow editor
    position_y INTEGER,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (workflow_id, step_key)
);

CREATE INDEX idx_workflow_steps_workflow ON workflow_steps (workflow_id);

-- Step transitions (edges in the DAG)
CREATE TABLE workflow_transitions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workflow_id UUID NOT NULL REFERENCES workflows(id) ON DELETE CASCADE,
    from_step_key TEXT NOT NULL,
    to_step_key TEXT NOT NULL,
    condition TEXT,                           -- expression evaluated at runtime
    label TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (workflow_id, from_step_key, to_step_key)
);

CREATE INDEX idx_transitions_workflow ON workflow_transitions (workflow_id);
CREATE INDEX idx_transitions_from ON workflow_transitions (workflow_id, from_step_key);

-- Workflow instances (running executions of a workflow)
CREATE TYPE workflow_instance_status AS ENUM (
    'pending',
    'running',
    'paused',
    'completed',
    'failed',
    'cancelled',
    'timed_out'
);

CREATE TABLE workflow_instances (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workflow_id UUID NOT NULL REFERENCES workflows(id),
    workflow_version INTEGER NOT NULL,
    status workflow_instance_status NOT NULL DEFAULT 'pending',
    input JSONB NOT NULL DEFAULT '{}',
    output JSONB,
    context JSONB NOT NULL DEFAULT '{}',      -- mutable runtime state
    error TEXT,
    error_step_key TEXT,
    trigger_type TEXT NOT NULL,
    trigger_payload JSONB NOT NULL DEFAULT '{}',
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    timeout_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_instances_workflow ON workflow_instances (workflow_id, created_at DESC);
CREATE INDEX idx_instances_status ON workflow_instances (status, created_at DESC);
CREATE INDEX idx_instances_timeout ON workflow_instances (timeout_at)
    WHERE status IN ('pending', 'running', 'paused') AND timeout_at IS NOT NULL;

-- Step executions (individual step runs within an instance)
CREATE TYPE step_execution_status AS ENUM (
    'pending',
    'running',
    'completed',
    'failed',
    'skipped',
    'cancelled',
    'timed_out'
);

CREATE TABLE step_executions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    instance_id UUID NOT NULL REFERENCES workflow_instances(id) ON DELETE CASCADE,
    workflow_id UUID NOT NULL REFERENCES workflows(id),
    step_key TEXT NOT NULL,
    attempt INTEGER NOT NULL DEFAULT 1,
    status step_execution_status NOT NULL DEFAULT 'pending',
    input JSONB NOT NULL DEFAULT '{}',
    output JSONB,
    error TEXT,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    duration_ms INTEGER GENERATED ALWAYS AS (
        CASE
            WHEN started_at IS NOT NULL AND completed_at IS NOT NULL
            THEN EXTRACT(EPOCH FROM (completed_at - started_at))::INTEGER * 1000
            ELSE NULL
        END
    ) STORED,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_step_executions_instance ON step_executions (instance_id);
CREATE INDEX idx_step_executions_step ON step_executions (instance_id, step_key);
CREATE INDEX idx_step_executions_status ON step_executions (status, created_at DESC);

-- Triggers for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_workflows_updated
    BEFORE UPDATE ON workflows
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_instances_updated
    BEFORE UPDATE ON workflow_instances
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_step_executions_updated
    BEFORE UPDATE ON step_executions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
