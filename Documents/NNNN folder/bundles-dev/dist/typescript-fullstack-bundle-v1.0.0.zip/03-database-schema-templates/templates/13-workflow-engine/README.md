# Workflow Engine Schema

DAG-based workflow engine with step definitions, runtime instances, conditional transitions, and full execution history.

## Tables

| Table | Purpose |
|-------|---------|
| `workflows` | Blueprint definitions (slug, trigger type, DAG config) |
| `workflow_steps` | Individual nodes in the DAG, with handler and retry config |
| `workflow_transitions` | Directed edges between steps, with optional conditions |
| `workflow_instances` | Running/completed executions of a workflow |
| `step_executions` | Per-step execution records within an instance |

## Key Design Decisions

### Separation of Definition and Execution
`workflows` / `workflow_steps` / `workflow_transitions` are immutable templates. `workflow_instances` / `step_executions` are the runtime execution records. Updating a workflow increments `version`; instances store `workflow_version` so you can replay with the exact definition used.

### DAG via Transitions
`workflow_transitions` stores directed edges `from_step_key → to_step_key`. An optional `condition` field holds an expression string evaluated at runtime against the instance `context` (e.g., `"context.approved === true"`).

### Context as Mutable State
`workflow_instances.context` is the shared mutable JSONB map. Steps read from it via `input_mapping` and write back via `output_mapping`. This eliminates the need for a separate key-value store.

### Generated `duration_ms`
`step_executions.duration_ms` is a `GENERATED ALWAYS AS` column — no application code needed to compute step latency.

## Common Queries

### Start a Workflow Instance
```sql
INSERT INTO workflow_instances (workflow_id, workflow_version, input, trigger_type)
SELECT id, version, $input, 'manual'
FROM workflows WHERE slug = $slug AND is_active = true
RETURNING *;
```

### Get Next Runnable Steps
```sql
SELECT DISTINCT t.to_step_key
FROM workflow_transitions t
JOIN step_executions se ON se.instance_id = $instance_id
  AND se.step_key = t.from_step_key
  AND se.status = 'completed'
WHERE t.workflow_id = $workflow_id
  AND t.to_step_key NOT IN (
    SELECT step_key FROM step_executions
    WHERE instance_id = $instance_id
  );
```

### Instance Execution History
```sql
SELECT step_key, attempt, status, duration_ms, error, started_at
FROM step_executions
WHERE instance_id = $1
ORDER BY started_at ASC;
```

## Requirements
- PostgreSQL 14+
- Prisma 5+
- TypeScript 5+
