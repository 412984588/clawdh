// SaaS Auth — TypeScript types
// Generated from migration.sql — keep in sync

export type UserRole = 'user' | 'admin';
export type OAuthProvider = 'github' | 'google' | 'discord';

export interface User {
  id: string;
  email: string;
  emailVerified: boolean;
  passwordHash: string | null;
  name: string | null;
  avatarUrl: string | null;
  role: UserRole;
  metadata: Record<string, unknown>;
  createdAt: Date;
  updatedAt: Date;
}

export interface Session {
  id: string;
  userId: string;
  tokenHash: string;
  ipAddress: string | null;
  userAgent: string | null;
  expiresAt: Date;
  createdAt: Date;
  lastActiveAt: Date;
}

export interface OAuthAccount {
  id: string;
  userId: string;
  provider: OAuthProvider;
  providerId: string;
  accessToken: string | null;
  refreshToken: string | null;
  expiresAt: Date | null;
  createdAt: Date;
}

export interface PasswordReset {
  id: string;
  userId: string;
  tokenHash: string;
  expiresAt: Date;
  usedAt: Date | null;
  createdAt: Date;
}

export interface EmailVerification {
  id: string;
  userId: string;
  email: string;
  tokenHash: string;
  expiresAt: Date;
  verifiedAt: Date | null;
  createdAt: Date;
}

// Insert/Update helpers (omit server-generated fields)
export type CreateUser = Pick<User, 'email' | 'name'> & Partial<Pick<User, 'passwordHash' | 'role' | 'metadata'>>;
export type UpdateUser = Partial<Pick<User, 'name' | 'avatarUrl' | 'role' | 'metadata' | 'emailVerified'>>;
