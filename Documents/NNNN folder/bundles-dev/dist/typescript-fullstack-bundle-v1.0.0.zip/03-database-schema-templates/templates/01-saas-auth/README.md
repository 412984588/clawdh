# SaaS Auth Schema

Full authentication schema for SaaS products: email/password + OAuth, session management, email verification, password reset.

## Tables

| Table | Purpose |
|-------|---------|
| `users` | Core user accounts with role and metadata |
| `sessions` | Server-side sessions (token stored as hash) |
| `oauth_accounts` | OAuth provider links per user |
| `password_resets` | Time-limited reset tokens |
| `email_verifications` | Email address verification tokens |

## Design Decisions

**Token storage**: Store SHA-256 hash of tokens, never plaintext. `token_hash TEXT UNIQUE` — fast lookup, no exposure if DB is breached.

**OAuth + password**: `password_hash` is nullable — OAuth-only users have no password. Check `password_hash IS NOT NULL` before allowing password login.

**Session expiry**: `expires_at` with an index — background job deletes expired rows via `DELETE FROM sessions WHERE expires_at < now()`.

**Soft deletes**: Not used. Hard delete users removes sessions/oauth via `ON DELETE CASCADE`.

## Common Queries

```sql
-- Active sessions for user
SELECT * FROM sessions WHERE user_id = $1 AND expires_at > now();

-- Clean expired sessions
DELETE FROM sessions WHERE expires_at < now();

-- Find user by OAuth
SELECT u.* FROM users u
JOIN oauth_accounts o ON o.user_id = u.id
WHERE o.provider = $1 AND o.provider_id = $2;
```
