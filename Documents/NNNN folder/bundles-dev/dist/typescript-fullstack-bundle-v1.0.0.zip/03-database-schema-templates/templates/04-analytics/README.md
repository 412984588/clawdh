# Analytics Schema

Event tracking, pageviews, sessions, goals, and conversions. Designed for product analytics (not BI warehouse).

## Tables

| Table | Purpose |
|-------|---------|
| `events` | Raw event stream (partitioned by month) |
| `pageviews` | Page navigation events |
| `sessions` | User session aggregates |
| `goals` | Conversion goal definitions |
| `conversions` | Goal completion records |

## Design Decisions

**Partitioned events**: `PARTITION BY RANGE (created_at)` — create monthly partitions. Old partitions can be detached and archived without DELETE costs.

**JSONB properties**: Flexible event properties without schema changes.

**Session as aggregate**: `page_count` and `event_count` are denormalized for fast dashboard queries.

## Common Queries

```sql
-- Daily active users (last 30 days)
SELECT date_trunc('day', created_at) AS day, count(DISTINCT user_id) AS dau
FROM events
WHERE user_id IS NOT NULL AND created_at > now() - interval '30 days'
GROUP BY 1 ORDER BY 1;

-- Conversion rate for goal
SELECT g.name,
  count(DISTINCT c.session_id) AS conversions,
  count(DISTINCT s.id) AS sessions,
  round(count(DISTINCT c.session_id)::numeric / nullif(count(DISTINCT s.id), 0) * 100, 2) AS rate_pct
FROM goals g
LEFT JOIN conversions c ON c.goal_id = g.id
CROSS JOIN sessions s
WHERE g.id = $1
GROUP BY g.name;
```
