-- Analytics Schema
-- PostgreSQL 14+

CREATE TABLE events (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_name  TEXT NOT NULL,
  user_id     UUID,
  session_id  TEXT,
  properties  JSONB NOT NULL DEFAULT '{}',
  ip_address  INET,
  user_agent  TEXT,
  url         TEXT,
  referrer    TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
) PARTITION BY RANGE (created_at);

-- Monthly partitions (example: create as needed)
CREATE TABLE events_2026_03 PARTITION OF events
  FOR VALUES FROM ('2026-03-01') TO ('2026-04-01');

CREATE TABLE pageviews (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id  TEXT NOT NULL,
  user_id     UUID,
  url         TEXT NOT NULL,
  title       TEXT,
  referrer    TEXT,
  duration_ms INTEGER,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE sessions (
  id            TEXT PRIMARY KEY,               -- client-generated session ID
  user_id       UUID,
  started_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  ended_at      TIMESTAMPTZ,
  page_count    INTEGER NOT NULL DEFAULT 0,
  event_count   INTEGER NOT NULL DEFAULT 0,
  utm_source    TEXT,
  utm_medium    TEXT,
  utm_campaign  TEXT,
  device_type   TEXT,                           -- desktop | mobile | tablet
  country       CHAR(2)
);

CREATE TABLE goals (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name        TEXT NOT NULL,
  event_name  TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE conversions (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  goal_id     UUID NOT NULL REFERENCES goals(id),
  user_id     UUID,
  session_id  TEXT,
  value       NUMERIC(12,2),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Indexes
CREATE INDEX idx_events_event_name ON events(event_name, created_at DESC);
CREATE INDEX idx_events_user_id ON events(user_id) WHERE user_id IS NOT NULL;
CREATE INDEX idx_events_session_id ON events(session_id) WHERE session_id IS NOT NULL;
CREATE INDEX idx_pageviews_session_id ON pageviews(session_id);
CREATE INDEX idx_conversions_goal_id ON conversions(goal_id, created_at DESC);
