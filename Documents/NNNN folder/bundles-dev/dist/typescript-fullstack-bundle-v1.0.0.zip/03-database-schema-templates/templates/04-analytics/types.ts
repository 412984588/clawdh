// Analytics — TypeScript types

export type DeviceType = 'desktop' | 'mobile' | 'tablet';

export interface Event {
  id: string;
  eventName: string;
  userId: string | null;
  sessionId: string | null;
  properties: Record<string, unknown>;
  ipAddress: string | null;
  userAgent: string | null;
  url: string | null;
  referrer: string | null;
  createdAt: Date;
}

export interface Pageview {
  id: string;
  sessionId: string;
  userId: string | null;
  url: string;
  title: string | null;
  referrer: string | null;
  durationMs: number | null;
  createdAt: Date;
}

export interface AnalyticsSession {
  id: string;
  userId: string | null;
  startedAt: Date;
  endedAt: Date | null;
  pageCount: number;
  eventCount: number;
  utmSource: string | null;
  utmMedium: string | null;
  utmCampaign: string | null;
  deviceType: DeviceType | null;
  country: string | null;
}

export interface Goal {
  id: string;
  name: string;
  eventName: string;
  createdAt: Date;
}

export interface Conversion {
  id: string;
  goalId: string;
  userId: string | null;
  sessionId: string | null;
  value: number | null;
  createdAt: Date;
}

// Track event helper type
export type TrackEvent = Omit<Event, 'id' | 'createdAt'>;
