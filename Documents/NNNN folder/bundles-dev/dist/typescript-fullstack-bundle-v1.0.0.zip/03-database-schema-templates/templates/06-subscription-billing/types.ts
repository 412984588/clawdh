// Subscription Billing — TypeScript types

export type BillingInterval = 'month' | 'year';
export type SubscriptionStatus = 'active' | 'past_due' | 'cancelled' | 'paused';
export type InvoiceStatus = 'draft' | 'open' | 'paid' | 'void' | 'uncollectible';
export type PaymentMethodType = 'card' | 'bank_account';

export interface Plan {
  id: string;
  name: string;
  description: string | null;
  priceCents: number;
  currency: string;
  interval: BillingInterval;
  intervalCount: number;
  features: string[];
  isActive: boolean;
  createdAt: Date;
}

export interface PaymentMethod {
  id: string;
  userId: string;
  provider: string;
  providerId: string;
  type: PaymentMethodType;
  last4: string | null;
  brand: string | null;
  expMonth: number | null;
  expYear: number | null;
  isDefault: boolean;
  createdAt: Date;
}

export interface Subscription {
  id: string;
  userId: string;
  planId: string;
  paymentMethodId: string | null;
  provider: string;
  providerId: string | null;
  status: SubscriptionStatus;
  currentPeriodStart: Date;
  currentPeriodEnd: Date;
  cancelAtPeriodEnd: boolean;
  cancelledAt: Date | null;
  metadata: Record<string, unknown>;
  createdAt: Date;
  updatedAt: Date;
}

export interface Invoice {
  id: string;
  subscriptionId: string | null;
  userId: string;
  providerId: string | null;
  status: InvoiceStatus;
  amountCents: number;
  taxCents: number;
  currency: string;
  dueDate: Date | null;
  paidAt: Date | null;
  createdAt: Date;
}

export interface InvoiceItem {
  id: string;
  invoiceId: string;
  description: string;
  quantity: number;
  unitAmountCents: number;
  createdAt: Date;
}
