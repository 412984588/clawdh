# Subscription Billing Schema

Plans, subscriptions, invoices, and payment methods. Designed to mirror Stripe's data model for easy sync.

## Tables

| Table | Purpose |
|-------|---------|
| `plans` | Subscription plan definitions |
| `payment_methods` | Saved payment methods per user |
| `subscriptions` | Active/past subscriptions |
| `invoices` | Billing invoices |
| `invoice_items` | Line items on invoices |

## Design Decisions

**Provider mirroring**: `provider_id` fields store Stripe/PayPal IDs. Treat the provider as source of truth; sync to local DB via webhooks.

**Status as string**: `active | past_due | cancelled | paused` — matches Stripe's status vocabulary.

**Invoice separate from subscription**: One-off charges can create invoices without a subscription.

## Common Queries

```sql
-- Active subscriptions expiring soon (renewal reminders)
SELECT * FROM subscriptions
WHERE status = 'active'
  AND current_period_end BETWEEN now() AND now() + interval '3 days';

-- MRR calculation
SELECT sum(p.price_cents) / 100.0 AS mrr
FROM subscriptions s
JOIN plans p ON p.id = s.plan_id
WHERE s.status = 'active' AND p.interval = 'month';
```
