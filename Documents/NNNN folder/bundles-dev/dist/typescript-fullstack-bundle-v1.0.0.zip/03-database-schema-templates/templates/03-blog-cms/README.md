# Blog CMS Schema

Posts, authors, categories, tags, comments, and media. Standard content management model.

## Tables

| Table | Purpose |
|-------|---------|
| `authors` | Content writers |
| `posts` | Blog posts with status lifecycle |
| `categories` | Single-level post categories |
| `tags` | Many-to-many post labels |
| `post_tags` | Join table for posts ↔ tags |
| `comments` | Threaded comments with moderation |
| `media` | Uploaded file registry |

## Design Decisions

**Threaded comments**: `parent_id` self-reference. Limit nesting to 2 levels in application logic.

**Post status**: `draft | published | archived`. `published_at` is set when status changes to published.

**Slugs**: `UNIQUE NOT NULL`. Generate from title, handle conflicts with suffix.

## Common Queries

```sql
-- Published posts with author and tags
SELECT p.*, a.name as author_name, array_agg(t.name) as tags
FROM posts p
JOIN authors a ON a.id = p.author_id
LEFT JOIN post_tags pt ON pt.post_id = p.id
LEFT JOIN tags t ON t.id = pt.tag_id
WHERE p.status = 'published'
GROUP BY p.id, a.name
ORDER BY p.published_at DESC;
```
