// Blog CMS — TypeScript types

export type PostStatus = 'draft' | 'published' | 'archived';

export interface Author {
  id: string;
  name: string;
  email: string;
  bio: string | null;
  avatarUrl: string | null;
  createdAt: Date;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  createdAt: Date;
}

export interface Tag {
  id: string;
  name: string;
  slug: string;
  createdAt: Date;
}

export interface Post {
  id: string;
  authorId: string;
  categoryId: string | null;
  title: string;
  slug: string;
  excerpt: string | null;
  content: string;
  coverImage: string | null;
  status: PostStatus;
  publishedAt: Date | null;
  metadata: Record<string, unknown>;
  createdAt: Date;
  updatedAt: Date;
}

export interface PostTag {
  postId: string;
  tagId: string;
}

export interface Comment {
  id: string;
  postId: string;
  parentId: string | null;
  authorName: string;
  authorEmail: string;
  content: string;
  isApproved: boolean;
  createdAt: Date;
}

export interface Media {
  id: string;
  filename: string;
  url: string;
  mimeType: string;
  sizeBytes: number;
  altText: string | null;
  createdAt: Date;
}

// With relations
export interface PostWithRelations extends Post {
  author: Author;
  category: Category | null;
  tags: Tag[];
  comments: Comment[];
}
