// RBAC — TypeScript types

export type PermissionAction = 'read' | 'create' | 'update' | 'delete' | 'export' | string;

export interface Resource {
  id: string;
  name: string;
  description: string | null;
  createdAt: Date;
}

export interface Permission {
  id: string;
  resourceId: string;
  action: PermissionAction;
  description: string | null;
  createdAt: Date;
}

export interface Role {
  id: string;
  name: string;
  description: string | null;
  isSystem: boolean;
  createdAt: Date;
}

export interface RolePermission {
  roleId: string;
  permissionId: string;
  grantedAt: Date;
}

export interface UserRole {
  userId: string;
  roleId: string;
  tenantId: string | null;
  grantedBy: string | null;
  grantedAt: Date;
  expiresAt: Date | null;
}

// Resolved permission entry from the view
export interface UserPermission {
  userId: string;
  tenantId: string | null;
  roleName: string;
  resource: string;
  action: PermissionAction;
}

// Permission check helper
export function hasPermission(
  permissions: UserPermission[],
  resource: string,
  action: PermissionAction,
  tenantId?: string
): boolean {
  return permissions.some(
    p => p.resource === resource &&
         p.action === action &&
         (tenantId === undefined || p.tenantId === tenantId || p.tenantId === null)
  );
}
