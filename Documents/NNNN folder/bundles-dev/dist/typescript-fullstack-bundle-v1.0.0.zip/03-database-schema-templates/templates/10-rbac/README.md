# RBAC Schema (Role-Based Access Control)

Resources, permissions, roles, and user role assignments. Supports tenant-scoped roles and time-limited grants.

## Tables

| Table | Purpose |
|-------|---------|
| `resources` | Things that can be accessed (users, invoices, reports) |
| `permissions` | resource + action pairs (invoices.read, invoices.delete) |
| `roles` | Named permission bundles (admin, billing_manager, viewer) |
| `role_permissions` | Which permissions belong to which roles |
| `user_roles` | Which roles users have (optionally scoped to tenant + expiry) |

## Design Decisions

**System roles**: `is_system = true` prevents accidental deletion of built-in roles.

**Tenant scoping**: `tenant_id` on `user_roles` — same role can have different scope (global admin vs tenant-level admin).

**Time-limited grants**: `expires_at` on user_roles — temporary permission grants without manual cleanup.

**Permission check view**: `user_permissions` view for ad-hoc queries. Cache the result in application memory for hot paths.

## Common Queries

```sql
-- Check if user has permission
SELECT 1 FROM user_permissions
WHERE user_id = $1 AND resource = 'invoices' AND action = 'delete'
LIMIT 1;

-- All permissions for a user in a tenant
SELECT resource, action FROM user_permissions
WHERE user_id = $1 AND (tenant_id = $2 OR tenant_id IS NULL);
```
