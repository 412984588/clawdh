# Search Index Schema

Full-text search with PostgreSQL's native `tsvector` — no Elasticsearch required.

## Tables

| Table | Purpose |
|-------|---------|
| `search_documents` | Indexed content with generated `tsvector` column |
| `search_queries` | Every search logged for analytics and no-result tracking |
| `search_suggestions` | Autocomplete suggestions, weighted and trigram-indexed |
| `search_analytics` | Daily roll-up aggregates per index |

## Key Design Decisions

### Generated `search_vector` Column
`TSVECTOR GENERATED ALWAYS AS ... STORED` — PostgreSQL recomputes the vector on every insert/update. No manual sync needed.

### Weighted Fields
- Title: weight `A` (highest relevance)
- Body: weight `B`

Use `ts_rank(search_vector, plainto_tsquery('english', $1))` for relevance ordering.

### `pg_trgm` for Autocomplete
`GIN (suggestion gin_trgm_ops)` powers `ILIKE '%partial%'` queries at scale without full sequential scan.

### Multi-Index Support
Each document has an `index_name` — one schema serves "products", "articles", "help-docs" etc.

## Common Queries

### Full-Text Search
```sql
SELECT
  id, index_name, document_id, title,
  ts_headline('english', body, query, 'MaxFragments=2') AS headline,
  ts_rank(search_vector, query) AS rank
FROM search_documents,
     plainto_tsquery('english', $1) query
WHERE index_name = $2
  AND search_vector @@ query
ORDER BY rank DESC
LIMIT 20;
```

### Autocomplete Suggestions
```sql
SELECT suggestion, weight
FROM search_suggestions
WHERE index_name = $1
  AND active = true
  AND suggestion ILIKE $2 || '%'
ORDER BY weight DESC, query_count DESC
LIMIT 10;
```

### Zero-Result Queries (last 30 days)
```sql
SELECT normalized_query, COUNT(*) AS occurrences
FROM search_queries
WHERE index_name = $1
  AND result_count = 0
  AND created_at > now() - INTERVAL '30 days'
GROUP BY normalized_query
ORDER BY occurrences DESC
LIMIT 20;
```

## Requirements
- PostgreSQL 14+ with `pg_trgm` extension
- Prisma 5+
- TypeScript 5+
