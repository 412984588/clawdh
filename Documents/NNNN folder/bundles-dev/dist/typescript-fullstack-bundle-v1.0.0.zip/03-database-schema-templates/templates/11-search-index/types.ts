// Search Index — TypeScript Types
// PostgreSQL 14+ · Prisma 5+ · TypeScript 5+

export type Language =
  | 'english'
  | 'spanish'
  | 'french'
  | 'german'
  | 'portuguese'
  | 'italian'
  | 'simple';

// ─── Search Documents ──────────────────────────────────────────────────────

export interface SearchDocument {
  id: string;
  indexName: string;
  documentId: string;
  title: string;
  body: string | null;
  metadata: Record<string, unknown>;
  tags: string[];
  language: Language;
  // search_vector is generated — not mapped to runtime type
  boost: number;
  publishedAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

export type CreateSearchDocument = Omit<
  SearchDocument,
  'id' | 'createdAt' | 'updatedAt'
> & {
  id?: string;
  language?: Language;
  boost?: number;
  metadata?: Record<string, unknown>;
  tags?: string[];
};

export type UpdateSearchDocument = Partial<
  Pick<SearchDocument, 'title' | 'body' | 'metadata' | 'tags' | 'boost' | 'publishedAt'>
>;

// ─── Search Queries ────────────────────────────────────────────────────────

export interface SearchQuery {
  id: string;
  indexName: string;
  query: string;
  normalizedQuery: string;
  resultCount: number;
  clickedDocumentId: string | null;
  sessionId: string | null;
  userId: string | null;
  filters: Record<string, unknown>;
  durationMs: number | null;
  createdAt: Date;
}

export type LogSearchQuery = Omit<SearchQuery, 'id' | 'createdAt'> & {
  id?: string;
  resultCount?: number;
  filters?: Record<string, unknown>;
};

// ─── Search Suggestions ────────────────────────────────────────────────────

export interface SearchSuggestion {
  id: string;
  indexName: string;
  suggestion: string;
  weight: number;
  queryCount: number;
  clickCount: number;
  isManual: boolean;
  active: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export type CreateSearchSuggestion = Omit<
  SearchSuggestion,
  'id' | 'queryCount' | 'clickCount' | 'createdAt' | 'updatedAt'
> & {
  id?: string;
  weight?: number;
  isManual?: boolean;
  active?: boolean;
};

// ─── Search Analytics ──────────────────────────────────────────────────────

export interface TopQuery {
  query: string;
  count: number;
}

export interface SearchAnalytics {
  id: string;
  indexName: string;
  date: Date;
  totalSearches: number;
  uniqueQueries: number;
  zeroResultSearches: number;
  avgResultCount: number | null;
  avgDurationMs: number | null;
  topQueries: TopQuery[];
  createdAt: Date;
  updatedAt: Date;
}

// ─── Search Result (runtime, not persisted) ────────────────────────────────

export interface SearchResult {
  document: SearchDocument;
  rank: number;      // ts_rank result
  headline: string | null; // ts_headline snippet
}

export interface SearchResponse {
  results: SearchResult[];
  totalCount: number;
  query: string;
  indexName: string;
  durationMs: number;
}

// ─── Search Filters ────────────────────────────────────────────────────────

export interface SearchFilters {
  tags?: string[];
  language?: Language;
  publishedAfter?: Date;
  publishedBefore?: Date;
  metadata?: Record<string, unknown>;
}

// ─── Helper ────────────────────────────────────────────────────────────────

/** Normalizes a raw query string for storage / suggestion matching */
export function normalizeQuery(query: string): string {
  return query.trim().toLowerCase().replace(/\s+/g, ' ');
}
