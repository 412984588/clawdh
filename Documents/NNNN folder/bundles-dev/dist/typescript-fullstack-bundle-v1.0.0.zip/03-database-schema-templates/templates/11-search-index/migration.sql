-- Search Index Schema
-- PostgreSQL 14+
-- Full-text search with suggestions and analytics

CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- Search documents (the main indexed content)
CREATE TABLE search_documents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    index_name TEXT NOT NULL,                   -- e.g. "products", "articles"
    document_id TEXT NOT NULL,                  -- FK to external entity
    title TEXT NOT NULL,
    body TEXT,
    metadata JSONB NOT NULL DEFAULT '{}',       -- extra filterable fields
    tags TEXT[] NOT NULL DEFAULT '{}',
    language TEXT NOT NULL DEFAULT 'english',
    search_vector TSVECTOR GENERATED ALWAYS AS (
        setweight(to_tsvector(language::regconfig, coalesce(title, '')), 'A') ||
        setweight(to_tsvector(language::regconfig, coalesce(body, '')), 'B')
    ) STORED,
    boost FLOAT NOT NULL DEFAULT 1.0,
    published_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (index_name, document_id)
);

CREATE INDEX idx_search_documents_index ON search_documents (index_name);
CREATE INDEX idx_search_documents_vector ON search_documents USING GIN (search_vector);
CREATE INDEX idx_search_documents_tags ON search_documents USING GIN (tags);
CREATE INDEX idx_search_documents_metadata ON search_documents USING GIN (metadata);
CREATE INDEX idx_search_documents_published ON search_documents (index_name, published_at DESC)
    WHERE published_at IS NOT NULL;

-- Search queries log (for analytics and suggestions)
CREATE TABLE search_queries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    index_name TEXT NOT NULL,
    query TEXT NOT NULL,
    normalized_query TEXT NOT NULL,            -- lowercased, trimmed
    result_count INTEGER NOT NULL DEFAULT 0,
    clicked_document_id TEXT,                  -- first click after search
    session_id TEXT,
    user_id UUID,
    filters JSONB NOT NULL DEFAULT '{}',
    duration_ms INTEGER,                        -- query execution time
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_search_queries_index ON search_queries (index_name, created_at DESC);
CREATE INDEX idx_search_queries_normalized ON search_queries (index_name, normalized_query);
CREATE INDEX idx_search_queries_no_results ON search_queries (index_name, created_at DESC)
    WHERE result_count = 0;

-- Search suggestions (autocomplete)
CREATE TABLE search_suggestions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    index_name TEXT NOT NULL,
    suggestion TEXT NOT NULL,
    weight INTEGER NOT NULL DEFAULT 1,          -- higher = shown first
    query_count INTEGER NOT NULL DEFAULT 0,     -- times this suggestion was searched
    click_count INTEGER NOT NULL DEFAULT 0,     -- times suggestion led to click
    is_manual BOOLEAN NOT NULL DEFAULT false,   -- manually curated vs auto-generated
    active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (index_name, suggestion)
);

CREATE INDEX idx_search_suggestions_index ON search_suggestions (index_name, weight DESC)
    WHERE active = true;
CREATE INDEX idx_search_suggestions_trgm ON search_suggestions
    USING GIN (suggestion gin_trgm_ops);

-- Search analytics aggregates (daily roll-ups)
CREATE TABLE search_analytics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    index_name TEXT NOT NULL,
    date DATE NOT NULL,
    total_searches INTEGER NOT NULL DEFAULT 0,
    unique_queries INTEGER NOT NULL DEFAULT 0,
    zero_result_searches INTEGER NOT NULL DEFAULT 0,
    avg_result_count FLOAT,
    avg_duration_ms FLOAT,
    top_queries JSONB NOT NULL DEFAULT '[]',   -- [{query, count}]
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (index_name, date)
);

CREATE INDEX idx_search_analytics_index ON search_analytics (index_name, date DESC);

-- Triggers for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_search_documents_updated
    BEFORE UPDATE ON search_documents
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_search_suggestions_updated
    BEFORE UPDATE ON search_suggestions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_search_analytics_updated
    BEFORE UPDATE ON search_analytics
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
