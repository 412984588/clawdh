-- Message Queue Schema
-- PostgreSQL 14+
-- Reliable job/message queue with dead-letter support

-- Queues definition
CREATE TABLE queues (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT UNIQUE NOT NULL,
    description TEXT,
    max_delivery_attempts INTEGER NOT NULL DEFAULT 5,
    visibility_timeout_seconds INTEGER NOT NULL DEFAULT 30,  -- lock duration
    retention_seconds INTEGER NOT NULL DEFAULT 604800,       -- 7 days
    dlq_id UUID REFERENCES queues(id) ON DELETE SET NULL,    -- dead-letter queue
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_queues_name ON queues (name) WHERE is_active = true;

-- Messages
CREATE TYPE message_status AS ENUM (
    'pending',
    'processing',
    'completed',
    'failed',
    'dead_lettered'
);

CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    queue_id UUID NOT NULL REFERENCES queues(id) ON DELETE CASCADE,
    payload JSONB NOT NULL,
    attributes JSONB NOT NULL DEFAULT '{}',      -- metadata (source, trace-id, etc.)
    status message_status NOT NULL DEFAULT 'pending',
    priority INTEGER NOT NULL DEFAULT 0,          -- higher = processed first
    delivery_attempts INTEGER NOT NULL DEFAULT 0,
    max_delivery_attempts INTEGER NOT NULL DEFAULT 5,
    first_delivery_at TIMESTAMPTZ,
    last_delivery_at TIMESTAMPTZ,
    visible_after TIMESTAMPTZ NOT NULL DEFAULT now(),  -- schedule / backoff
    locked_by TEXT,                               -- consumer identifier
    locked_until TIMESTAMPTZ,
    scheduled_at TIMESTAMPTZ,                     -- future scheduling
    expires_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_messages_queue_pending ON messages (queue_id, priority DESC, created_at ASC)
    WHERE status = 'pending' AND visible_after <= now();
CREATE INDEX idx_messages_queue_status ON messages (queue_id, status);
CREATE INDEX idx_messages_locked_until ON messages (locked_until)
    WHERE status = 'processing';
CREATE INDEX idx_messages_scheduled ON messages (scheduled_at)
    WHERE scheduled_at IS NOT NULL AND status = 'pending';
CREATE INDEX idx_messages_expires ON messages (expires_at)
    WHERE expires_at IS NOT NULL;

-- Dead-letter messages (copy of failed messages, enriched with failure info)
CREATE TABLE dead_letter_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    original_message_id UUID NOT NULL,           -- original messages.id
    queue_id UUID NOT NULL REFERENCES queues(id) ON DELETE CASCADE,
    payload JSONB NOT NULL,
    attributes JSONB NOT NULL DEFAULT '{}',
    delivery_attempts INTEGER NOT NULL,
    last_error TEXT,
    last_error_at TIMESTAMPTZ,
    dead_lettered_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    requeued_at TIMESTAMPTZ,                     -- if manually re-queued
    requeued_message_id UUID
);

CREATE INDEX idx_dlq_queue ON dead_letter_messages (queue_id, dead_lettered_at DESC);
CREATE INDEX idx_dlq_original ON dead_letter_messages (original_message_id);

-- Consumers registration (optional — for monitoring)
CREATE TABLE consumers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    queue_id UUID NOT NULL REFERENCES queues(id) ON DELETE CASCADE,
    consumer_id TEXT NOT NULL,                   -- e.g. hostname:pid
    label TEXT,
    last_heartbeat_at TIMESTAMPTZ,
    messages_processed INTEGER NOT NULL DEFAULT 0,
    messages_failed INTEGER NOT NULL DEFAULT 0,
    registered_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (queue_id, consumer_id)
);

CREATE INDEX idx_consumers_queue ON consumers (queue_id);
CREATE INDEX idx_consumers_heartbeat ON consumers (last_heartbeat_at);

-- Triggers for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_queues_updated
    BEFORE UPDATE ON queues
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_messages_updated
    BEFORE UPDATE ON messages
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
