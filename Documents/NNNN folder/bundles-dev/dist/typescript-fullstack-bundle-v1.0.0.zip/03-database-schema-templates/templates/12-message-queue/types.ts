// Message Queue — TypeScript Types
// PostgreSQL 14+ · Prisma 5+ · TypeScript 5+

export type MessageStatus =
  | 'pending'
  | 'processing'
  | 'completed'
  | 'failed'
  | 'dead_lettered';

// ─── Queue ─────────────────────────────────────────────────────────────────

export interface Queue {
  id: string;
  name: string;
  description: string | null;
  maxDeliveryAttempts: number;
  visibilityTimeoutSeconds: number;
  retentionSeconds: number;
  dlqId: string | null;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export type CreateQueue = Omit<Queue, 'id' | 'createdAt' | 'updatedAt'> & {
  id?: string;
  maxDeliveryAttempts?: number;
  visibilityTimeoutSeconds?: number;
  retentionSeconds?: number;
  isActive?: boolean;
};

// ─── Message ───────────────────────────────────────────────────────────────

export interface Message<T = unknown> {
  id: string;
  queueId: string;
  payload: T;
  attributes: Record<string, unknown>;
  status: MessageStatus;
  priority: number;
  deliveryAttempts: number;
  maxDeliveryAttempts: number;
  firstDeliveryAt: Date | null;
  lastDeliveryAt: Date | null;
  visibleAfter: Date;
  lockedBy: string | null;
  lockedUntil: Date | null;
  scheduledAt: Date | null;
  expiresAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

export type EnqueueMessage<T = unknown> = {
  queueId: string;
  payload: T;
  attributes?: Record<string, unknown>;
  priority?: number;
  scheduledAt?: Date;
  expiresAt?: Date;
  delaySeconds?: number;  // converted to visibleAfter
};

// ─── Dead Letter ───────────────────────────────────────────────────────────

export interface DeadLetterMessage<T = unknown> {
  id: string;
  originalMessageId: string;
  queueId: string;
  payload: T;
  attributes: Record<string, unknown>;
  deliveryAttempts: number;
  lastError: string | null;
  lastErrorAt: Date | null;
  deadLetteredAt: Date;
  requeuedAt: Date | null;
  requeuedMessageId: string | null;
}

// ─── Consumer ──────────────────────────────────────────────────────────────

export interface Consumer {
  id: string;
  queueId: string;
  consumerId: string;
  label: string | null;
  lastHeartbeatAt: Date | null;
  messagesProcessed: number;
  messagesFailed: number;
  registeredAt: Date;
}

export type RegisterConsumer = Omit<
  Consumer,
  'id' | 'messagesProcessed' | 'messagesFailed' | 'registeredAt' | 'lastHeartbeatAt'
>;

// ─── Helpers ───────────────────────────────────────────────────────────────

/** Calculates exponential backoff delay in seconds for a given attempt */
export function backoffSeconds(attempt: number, baseSeconds = 5): number {
  return Math.min(baseSeconds * Math.pow(2, attempt - 1), 3600);
}

/** Returns the visibility cutoff for re-locking stale messages */
export function staleLockCutoff(visibilityTimeoutSeconds: number): Date {
  const cutoff = new Date();
  cutoff.setSeconds(cutoff.getSeconds() - visibilityTimeoutSeconds);
  return cutoff;
}
