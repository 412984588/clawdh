# Message Queue Schema

PostgreSQL-backed reliable message queue with visibility locking, dead-letter queues, scheduling, and consumer tracking.

## Tables

| Table | Purpose |
|-------|---------|
| `queues` | Queue definitions with DLQ pointers and retention settings |
| `messages` | Messages with status, priority, visibility window, and lock state |
| `dead_letter_messages` | Failed messages moved here after exhausting delivery attempts |
| `consumers` | Optional consumer registration for monitoring |

## Key Design Decisions

### Visibility Locking (Competing Consumers)
`visible_after` + `locked_until` implement optimistic locking. A consumer SELECTs and UPDATEs in a single `FOR UPDATE SKIP LOCKED` transaction:

```sql
UPDATE messages SET
  status = 'processing',
  locked_by = $consumer_id,
  locked_until = now() + INTERVAL '30 seconds',
  delivery_attempts = delivery_attempts + 1,
  first_delivery_at = COALESCE(first_delivery_at, now()),
  last_delivery_at = now()
WHERE id = (
  SELECT id FROM messages
  WHERE queue_id = $queue_id
    AND status = 'pending'
    AND visible_after <= now()
  ORDER BY priority DESC, created_at ASC
  LIMIT 1
  FOR UPDATE SKIP LOCKED
)
RETURNING *;
```

### Dead-Letter Queue
When `delivery_attempts >= max_delivery_attempts`, the message moves to `dead_letter_messages` and its status becomes `dead_lettered`. The `dlq_id` on a queue can point to another queue for automatic re-routing.

### Scheduled Messages
Set `scheduled_at` and the worker won't pick up the message until that time. Combine with `visible_after` for delayed retries.

### Stale Lock Recovery
A background job should periodically reset messages whose `locked_until < now()` back to `pending`:

```sql
UPDATE messages SET status = 'pending', locked_by = NULL, locked_until = NULL
WHERE status = 'processing' AND locked_until < now();
```

## Common Queries

### Enqueue
```sql
INSERT INTO messages (queue_id, payload, priority)
VALUES ($1, $2, $3)
RETURNING id;
```

### Acknowledge (complete)
```sql
UPDATE messages SET status = 'completed', updated_at = now()
WHERE id = $1 AND locked_by = $2;
```

### NACK with Backoff
```sql
UPDATE messages SET
  status = 'pending',
  locked_by = NULL,
  locked_until = NULL,
  visible_after = now() + ($backoff_seconds || ' seconds')::INTERVAL
WHERE id = $1;
```

## Requirements
- PostgreSQL 14+
- Prisma 5+
- TypeScript 5+
