// Multi-tenant — TypeScript types

export type TenantPlan = 'free' | 'starter' | 'pro' | 'enterprise';
export type MemberRole = 'owner' | 'admin' | 'member';

export interface Tenant {
  id: string;
  name: string;
  slug: string;
  plan: TenantPlan;
  settings: Record<string, unknown>;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface User {
  id: string;
  email: string;
  name: string;
  passwordHash: string | null;
  createdAt: Date;
}

export interface TenantMember {
  id: string;
  tenantId: string;
  userId: string;
  role: MemberRole;
  joinedAt: Date;
}

export interface TenantInvitation {
  id: string;
  tenantId: string;
  email: string;
  role: MemberRole;
  tokenHash: string;
  invitedBy: string;
  expiresAt: Date;
  acceptedAt: Date | null;
  createdAt: Date;
}

export interface TenantApiKey {
  id: string;
  tenantId: string;
  name: string;
  keyHash: string;
  lastUsedAt: Date | null;
  expiresAt: Date | null;
  createdBy: string;
  createdAt: Date;
}

// Context object for tenant-scoped requests
export interface TenantContext {
  tenant: Tenant;
  member: TenantMember;
  user: User;
}
