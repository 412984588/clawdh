# Multi-tenant Schema

Tenant isolation with member roles, invitations, and API key management.

## Tables

| Table | Purpose |
|-------|---------|
| `tenants` | Organization accounts |
| `users` | User identities (shared across tenants) |
| `tenant_members` | User ↔ Tenant membership with role |
| `tenant_invitations` | Email invitations with token |
| `tenant_api_keys` | Per-tenant API keys |

## Design Decisions

**Shared user table**: One user account can belong to multiple tenants. `tenant_members` is the join table.

**Row-Level Security**: Add `tenant_id` to every tenant-scoped table and enable RLS. See the comment in `migration.sql`.

**API key storage**: Store SHA-256 hash, never plaintext. Return the raw key only once at creation.

## Common Queries

```sql
-- All tenants for a user
SELECT t.* FROM tenants t
JOIN tenant_members tm ON tm.tenant_id = t.id
WHERE tm.user_id = $1 AND t.is_active = true;

-- Members of a tenant with their roles
SELECT u.email, u.name, tm.role, tm.joined_at
FROM tenant_members tm
JOIN users u ON u.id = tm.user_id
WHERE tm.tenant_id = $1;
```
