// Social Feed — TypeScript types

export type NotificationType = 'like' | 'reply' | 'follow' | 'mention';

export interface User {
  id: string;
  username: string;
  email: string;
  displayName: string;
  bio: string | null;
  avatarUrl: string | null;
  isPrivate: boolean;
  createdAt: Date;
}

export interface Follow {
  followerId: string;
  followingId: string;
  createdAt: Date;
}

export interface Post {
  id: string;
  userId: string;
  content: string;
  mediaUrls: string[];
  replyToId: string | null;
  likeCount: number;
  replyCount: number;
  isDeleted: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface Like {
  userId: string;
  postId: string;
  createdAt: Date;
}

export interface Hashtag {
  id: string;
  tag: string;
  postCount: number;
}

export interface PostHashtag {
  postId: string;
  hashtagId: string;
}

export interface Notification {
  id: string;
  userId: string;
  type: NotificationType;
  actorId: string | null;
  postId: string | null;
  isRead: boolean;
  createdAt: Date;
}

// Feed item (post with user info)
export interface FeedPost extends Post {
  user: Pick<User, 'id' | 'username' | 'displayName' | 'avatarUrl'>;
  isLikedByMe?: boolean;
}
