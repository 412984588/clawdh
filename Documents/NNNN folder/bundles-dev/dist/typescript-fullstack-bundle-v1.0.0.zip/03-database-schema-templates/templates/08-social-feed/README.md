# Social Feed Schema

Users, posts, follows, likes, hashtags, and notifications. Twitter/Mastodon-style feed model.

## Tables

| Table | Purpose |
|-------|---------|
| `users` | User profiles |
| `follows` | Follower graph |
| `posts` | Content with threading support |
| `likes` | Post likes (deduped) |
| `hashtags` | Tag registry with counts |
| `post_hashtags` | Post ↔ Hashtag join |
| `notifications` | Activity notifications |

## Design Decisions

**Denormalized counts**: `like_count` and `reply_count` on posts avoid expensive COUNT queries on feed render. Update via trigger or application code.

**Soft delete**: `is_deleted = true` preserves thread structure when a parent post is deleted.

**Feed query**: Use follower graph + time-based cursor pagination. Avoid OFFSET for large feeds.

## Common Queries

```sql
-- Home feed: posts from followed users
SELECT p.* FROM posts p
WHERE p.user_id IN (
  SELECT following_id FROM follows WHERE follower_id = $1
) AND p.is_deleted = false
ORDER BY p.created_at DESC
LIMIT 20;
```
