// Audit Log — TypeScript types

export type ActorType = 'user' | 'service' | 'system';
export type AuditSeverity = 'info' | 'warning' | 'critical';
export type AuditAction = 'create' | 'update' | 'delete' | 'login' | 'logout' | 'export' | 'view' | string;

export interface AuditLog {
  id: string;
  actorType: ActorType;
  actorId: string | null;
  actorName: string | null;
  action: AuditAction;
  resourceType: string;
  resourceId: string | null;
  resourceName: string | null;
  changes: Record<string, [unknown, unknown]> | null; // {field: [old, new]}
  metadata: {
    requestId?: string;
    ipAddress?: string;
    userAgent?: string;
    [key: string]: unknown;
  };
  severity: AuditSeverity;
  createdAt: Date;
}

export interface ResourceVersion {
  id: string;
  resourceType: string;
  resourceId: string;
  version: number;
  snapshot: Record<string, unknown>;
  changedBy: string | null;
  changeReason: string | null;
  createdAt: Date;
}

// Helper for creating audit log entries
export type CreateAuditLog = Omit<AuditLog, 'id' | 'createdAt'>;

// Diff helper: compute changes object from old and new rows
export function diffRows<T extends Record<string, unknown>>(
  oldRow: T,
  newRow: T
): Record<string, [unknown, unknown]> {
  const changes: Record<string, [unknown, unknown]> = {};
  const allKeys = new Set([...Object.keys(oldRow), ...Object.keys(newRow)]);
  for (const key of allKeys) {
    if (JSON.stringify(oldRow[key]) !== JSON.stringify(newRow[key])) {
      changes[key] = [oldRow[key], newRow[key]];
    }
  }
  return changes;
}
