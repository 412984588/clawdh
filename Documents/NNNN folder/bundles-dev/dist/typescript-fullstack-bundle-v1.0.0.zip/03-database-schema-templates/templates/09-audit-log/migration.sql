-- Audit Log Schema
-- PostgreSQL 14+ | Immutable audit trail

CREATE TABLE audit_logs (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_type    TEXT NOT NULL,                 -- user | service | system
  actor_id      TEXT,                          -- NULL for system actions
  actor_name    TEXT,                          -- denormalized for readability after actor deleted
  action        TEXT NOT NULL,                 -- create | update | delete | login | export | etc.
  resource_type TEXT NOT NULL,                 -- users | orders | invoices | etc.
  resource_id   TEXT,
  resource_name TEXT,
  changes       JSONB,                         -- {field: [old_value, new_value]}
  metadata      JSONB NOT NULL DEFAULT '{}',   -- request_id, ip, user_agent
  severity      TEXT NOT NULL DEFAULT 'info',  -- info | warning | critical
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Audit logs are append-only — no UPDATE/DELETE
REVOKE UPDATE, DELETE ON audit_logs FROM PUBLIC;

CREATE TABLE resource_versions (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  resource_type TEXT NOT NULL,
  resource_id   TEXT NOT NULL,
  version       INTEGER NOT NULL,
  snapshot      JSONB NOT NULL,               -- full row snapshot at this version
  changed_by    TEXT,
  change_reason TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (resource_type, resource_id, version)
);

-- Indexes (on immutable data — reads only)
CREATE INDEX idx_audit_logs_actor ON audit_logs(actor_type, actor_id, created_at DESC);
CREATE INDEX idx_audit_logs_resource ON audit_logs(resource_type, resource_id, created_at DESC);
CREATE INDEX idx_audit_logs_action ON audit_logs(action, created_at DESC);
CREATE INDEX idx_audit_logs_severity ON audit_logs(severity, created_at DESC) WHERE severity IN ('warning','critical');
CREATE INDEX idx_resource_versions ON resource_versions(resource_type, resource_id, version);
