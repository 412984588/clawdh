# Audit Log Schema

Immutable audit trail with actor tracking, change diffs, and resource versioning.

## Tables

| Table | Purpose |
|-------|---------|
| `audit_logs` | Every significant action, append-only |
| `resource_versions` | Point-in-time snapshots of any resource |

## Design Decisions

**Immutable**: `REVOKE UPDATE, DELETE ON audit_logs FROM PUBLIC`. Never modify audit records — that defeats the purpose.

**Denormalized actor info**: `actor_name` stored at log time. If the user is later deleted, the audit trail stays readable.

**Changes as diff**: `changes JSONB` stores `{field: [old_value, new_value]}` — human-readable and queryable.

**Resource versioning**: Separate from audit logs — stores the full row snapshot at each version for point-in-time recovery.

## Common Queries

```sql
-- Full history for a resource
SELECT * FROM audit_logs
WHERE resource_type = 'users' AND resource_id = $1
ORDER BY created_at DESC;

-- All actions by a specific user
SELECT * FROM audit_logs
WHERE actor_id = $1
ORDER BY created_at DESC LIMIT 100;

-- Recent critical events
SELECT * FROM audit_logs
WHERE severity = 'critical' AND created_at > now() - interval '24 hours'
ORDER BY created_at DESC;
```
