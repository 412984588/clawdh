// Inventory — TypeScript types

export type PoStatus = 'draft' | 'sent' | 'partial' | 'received' | 'cancelled';
export type TransferStatus = 'pending' | 'in_transit' | 'completed' | 'cancelled';

export interface Warehouse {
  id: string;
  name: string;
  code: string;
  address: Record<string, unknown>;
  isActive: boolean;
  createdAt: Date;
}

export interface Product {
  id: string;
  sku: string;
  name: string;
  description: string | null;
  unit: string;
  metadata: Record<string, unknown>;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface StockLevel {
  id: string;
  productId: string;
  warehouseId: string;
  qtyOnHand: number;
  qtyReserved: number;
  reorderPoint: number;
  updatedAt: Date;
}

export interface Supplier {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  address: Record<string, unknown>;
  createdAt: Date;
}

export interface PurchaseOrder {
  id: string;
  supplierId: string;
  warehouseId: string;
  status: PoStatus;
  notes: string | null;
  expectedAt: Date | null;
  receivedAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface PurchaseOrderItem {
  id: string;
  poId: string;
  productId: string;
  qtyOrdered: number;
  qtyReceived: number;
  unitCostCents: number;
  createdAt: Date;
}

export interface StockTransfer {
  id: string;
  fromWarehouseId: string;
  toWarehouseId: string;
  productId: string;
  quantity: number;
  status: TransferStatus;
  notes: string | null;
  createdAt: Date;
}
