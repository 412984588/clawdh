# Inventory Schema

Multi-warehouse inventory with stock levels, purchase orders, and transfers.

## Tables

| Table | Purpose |
|-------|---------|
| `warehouses` | Physical storage locations |
| `products` | Product master data |
| `stock_levels` | Current stock per product per warehouse |
| `suppliers` | Vendor/supplier accounts |
| `purchase_orders` | Inbound orders from suppliers |
| `purchase_order_items` | Line items per PO |
| `stock_transfers` | Inter-warehouse movements |

## Design Decisions

**qty_on_hand vs qty_reserved**: `qty_on_hand` is physical stock; `qty_reserved` is committed to orders. Available = `qty_on_hand - qty_reserved`.

**Reorder point**: Alert when `qty_on_hand <= reorder_point`. Implement as a scheduled query or trigger.

## Common Queries

```sql
-- Products below reorder point
SELECT p.sku, p.name, sl.qty_on_hand, sl.reorder_point, w.name as warehouse
FROM stock_levels sl
JOIN products p ON p.id = sl.product_id
JOIN warehouses w ON w.id = sl.warehouse_id
WHERE sl.qty_on_hand <= sl.reorder_point;
```
