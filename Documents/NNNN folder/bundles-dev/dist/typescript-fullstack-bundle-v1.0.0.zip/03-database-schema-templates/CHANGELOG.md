# Changelog

## [1.0.0] — 2026-03-21

### Added
- 13 PostgreSQL schema templates across 3 tiers ($19/$39/$59)
- Each template: migration.sql + types.ts + schema.prisma + README.md
- Starter (4): SaaS Auth, E-commerce, Blog CMS, Analytics
- Pro (8): + Multi-tenant, Subscription Billing, Inventory, Social Feed
- Complete (13): + Audit Log, RBAC, Search Index, Message Queue, Workflow Engine
- All schemas use PostgreSQL 14+ features (UUID, JSONB, generated columns)
- TypeScript types match schemas exactly (no drift)
- Prisma schemas ready for `prisma migrate dev`
