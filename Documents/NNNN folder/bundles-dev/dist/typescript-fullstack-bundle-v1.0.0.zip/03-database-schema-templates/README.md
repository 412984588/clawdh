# Database Schema Templates

**13 production-ready PostgreSQL schemas — SQL migration + TypeScript types + Prisma schema + README per template.**

Stop designing your database from scratch. Each template is a battle-tested schema for a common product pattern, ready to adapt in minutes.

## What's Inside

Every schema includes 4 files:
- `migration.sql` — PostgreSQL DDL with indexes, constraints, and comments
- `types.ts` — TypeScript interfaces matching the schema exactly
- `schema.prisma` — Prisma schema ready to use with `prisma migrate`
- `README.md` — table descriptions, design decisions, and common queries

## Schemas by Tier

### Starter ($19) — 4 schemas
| Schema | Use Case |
|--------|----------|
| `01-saas-auth` | Users, sessions, OAuth, password reset, email verification |
| `02-ecommerce` | Products, orders, customers, payments, addresses |
| `03-blog-cms` | Posts, categories, tags, comments, media, authors |
| `04-analytics` | Events, sessions, pageviews, funnels, conversions |

### Pro ($39) — 8 schemas
Everything in Starter, plus:
| Schema | Use Case |
|--------|----------|
| `05-multi-tenant` | Tenants, members, invitations, per-tenant settings |
| `06-subscription-billing` | Plans, subscriptions, invoices, payment methods |
| `07-inventory` | Products, warehouses, stock levels, purchase orders |
| `08-social-feed` | Posts, follows, likes, comments, notifications |

### Complete ($59) — 13 schemas
Everything in Pro, plus:
| Schema | Use Case |
|--------|----------|
| `09-audit-log` | Immutable audit trail, resource versioning |
| `10-rbac` | Roles, permissions, user roles, resource-level access |
| `11-search-index` | Search documents, suggestions, analytics |
| `12-message-queue` | Queues, messages, dead-letter, consumers |
| `13-workflow-engine` | Workflow definitions, instances, step execution |

## Quick Start

### Using SQL Migrations
```bash
psql $DATABASE_URL < templates/01-saas-auth/migration.sql
```

### Using Prisma
```bash
cp templates/01-saas-auth/schema.prisma prisma/schema.prisma
npx prisma migrate dev --name init
```

### Using TypeScript Types
```typescript
import type { User, Session } from './templates/01-saas-auth/types';
```

## Requirements
- PostgreSQL 14+
- Prisma 5+ (for Prisma schemas)
- TypeScript 5+ (for type files)
