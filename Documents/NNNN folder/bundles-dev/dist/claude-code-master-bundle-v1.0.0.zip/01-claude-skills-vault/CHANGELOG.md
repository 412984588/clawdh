# Changelog

## [1.0.0] - 2026-03-20

### Added
- Initial Claude Skills Vault release with `solo-cto` and `ship-fast` role packs
- Root installer `install.sh` for role-based installation into Claude Code
- Validation tooling and bundle packaging for Starter and Pro ZIP releases
- Release documentation files for distribution packaging
