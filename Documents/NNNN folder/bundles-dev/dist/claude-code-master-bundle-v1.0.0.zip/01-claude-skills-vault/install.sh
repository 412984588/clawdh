#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(CDPATH= cd -- "$(dirname "$0")" && pwd)"
CLAUDE_DIR="${CLAUDE_DIR:-$HOME/.claude}"
REQUESTED_ROLE="${1:-}"

if [ -z "$REQUESTED_ROLE" ]; then
  echo "Usage: bash install.sh <role>"
  echo "Available roles: solo-cto | ship-fast | all"
  exit 1
fi

available_roles=()
for role_path in "$PROJECT_ROOT"/roles/*; do
  [ -d "$role_path" ] || continue
  available_roles+=("$(basename "$role_path")")
done

if [ "${#available_roles[@]}" -eq 0 ]; then
  echo "No roles available under $PROJECT_ROOT/roles"
  exit 1
fi

install_role() {
  local role="$1"
  bash "$PROJECT_ROOT/shared/utils/install-role.sh" "$role" "$PROJECT_ROOT" "$CLAUDE_DIR"
}

if [ "$REQUESTED_ROLE" = "all" ]; then
  for role in "${available_roles[@]}"; do
    install_role "$role"
  done
else
  role_found=0
  for role in "${available_roles[@]}"; do
    if [ "$role" = "$REQUESTED_ROLE" ]; then
      role_found=1
      break
    fi
  done

  if [ "$role_found" -ne 1 ]; then
    echo "Unknown role: $REQUESTED_ROLE"
    echo "Available roles: ${available_roles[*]}"
    exit 1
  fi

  install_role "$REQUESTED_ROLE"
fi

echo ""
echo "Installed into $CLAUDE_DIR"
echo "Restart Claude Code to load the updated role."
