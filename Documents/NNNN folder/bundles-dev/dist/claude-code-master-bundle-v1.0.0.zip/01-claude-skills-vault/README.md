# Claude Skills Vault

Role-based Claude Code starter bundle with ready-to-install `CLAUDE.md`, local skills, hooks, and examples.

## Included Roles

- `solo-cto` — product-minded solo founder workflow with architecture, TDD, security, and deploy skills
- `ship-fast` — shipping-focused workflow for rapid MVP delivery and feedback loops

## Quick Start

```bash
./install.sh solo-cto
./install.sh ship-fast
./install.sh all
```

By default this installs into `~/.claude`. Set `CLAUDE_DIR` to target a different Claude Code directory.

## Validation

```bash
npm test
npm run validate
python3 build_bundles.py
```

## Deliverables

- `dist/claude-skills-starter-v1.0.0.zip`
- `dist/claude-skills-pro-v1.0.0.zip`

## License

Released under the MIT License. See `LICENSE`.
