# Ship Fast 角色 — 极速上线引擎

> 适合人群：想在周末把想法变成上线产品的独立开发者

## 什么是 Ship Fast？

Ship Fast 给 Claude Code 注入"先上线"的思维方式。它会：
- 优先选择能最快跑通的方案（Supabase > 自建认证）
- 阻止你过度设计（没有 1000 用户不做缓存层）
- 给你完整的上线检查清单
- 帮你集成支付、认证、反馈收集等 SaaS 必备功能

## 快速安装

```bash
# 从仓库根目录运行
bash install.sh ship-fast
```

安装后重启 Claude Code，角色立即生效。

## 包含的 Skills

| Skill | 功能 | 何时用 |
|-------|------|--------|
| `landing-page` | 生成高转化落地页 | 产品需要对外展示 |
| `stripe-setup` | Stripe 支付 5 步集成 | 需要收钱 |
| `auth-quick` | 5 分钟认证（Supabase/Clerk） | 需要用户系统 |
| `ship-checklist` | 上线前必检清单 | 准备发布 |
| `mvp-scaffold` | 项目脚手架一键初始化 | 新项目从零开始 |
| `feedback-loop` | 用户反馈收集系统 | 上线后收集意见 |

## 包含的 Hook

| Hook | 触发时机 | 功能 |
|------|---------|------|
| `pre-push` | `git push` 前 | 类型检查 + 构建检查 + 硬编码 URL 检测 |

## 演示项目

`examples/weekend-saas/` — AI 写作助手 SaaS 完整示例

这个演示项目展示了 Ship Fast 角色如何在 48 小时内从想法到上线：
- 使用了哪些 Skills（每一步标注）
- 实际花了多长时间
- 遇到了什么坑

## 技术栈

- **框架**：Next.js 14 App Router
- **样式**：Tailwind CSS + shadcn/ui
- **数据库**：Supabase（PostgreSQL + Auth）
- **支付**：Stripe Checkout
- **部署**：Vercel
- **邮件**：Resend

## 卸载 / 切换角色

```bash
# 切换到 Solo CTO
bash install.sh solo-cto

# 恢复备份（安装时自动备份）
cp ~/.claude/CLAUDE.md.backup.[timestamp] ~/.claude/CLAUDE.md
```
