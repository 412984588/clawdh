# Weekend SaaS — AI 写作助手上线全程记录

> 目标：48 小时内，从想法到可收费产品

## 产品简介

**WriteFlash** — 帮自由撰稿人克服写作空白页恐惧的 AI 写作助手

- 用户粘贴主题 → AI 生成 3 个开头选项 → 用户选一个继续写
- 定价：$9/月，7 天免费试用
- 技术：Next.js + Supabase + Stripe + Vercel

## 时间线（实际记录）

| 时间 | 做了什么 | 用了哪个 Skill |
|------|---------|--------------|
| Day 1 · 09:00 | 用 `mvp-scaffold` 搭好项目骨架 | `mvp-scaffold` |
| Day 1 · 10:30 | 用 `auth-quick` 加好 Supabase Auth + Google OAuth | `auth-quick` |
| Day 1 · 14:00 | 核心 AI 功能：OpenAI API 调用 + 流式输出 | — |
| Day 1 · 17:00 | 用 `stripe-setup` 加 $9/月订阅 | `stripe-setup` |
| Day 2 · 09:00 | 用 `landing-page` 生成落地页文案 + 代码 | `landing-page` |
| Day 2 · 11:00 | 加 `feedback-loop` 收集用户反馈 | `feedback-loop` |
| Day 2 · 14:00 | 用 `ship-checklist` 逐项检查 | `ship-checklist` |
| Day 2 · 16:00 | 部署到 Vercel，绑定域名，上线！ | — |

**总计：约 16 小时有效工作时间**

## 跑坑记录

1. **Stripe Webhook 本地测试**：用 `stripe listen --forward-to localhost:3000/api/webhooks/stripe`
2. **Supabase Row Level Security**：别忘了给 `feedback` 表加 RLS policy，否则任何人都能读
3. **OG 图忘了**：分享到 Twitter 显示空白，花 15 分钟用 Figma 生成了一张
4. **环境变量上 Vercel 时少了一个**：`pre-push` hook 提前警告了，但我忽略了

## 文件结构

```
weekend-saas/
├── README.md              ← 你在这里
├── .env.example           ← 所有需要的环境变量
├── app/
│   ├── page.tsx           ← 落地页（landing-page Skill 生成）
│   ├── dashboard/
│   │   └── page.tsx       ← 主功能页面
│   └── api/
│       ├── generate/      ← AI 写作接口
│       ├── checkout/      ← Stripe Checkout（stripe-setup Skill）
│       └── webhooks/
│           └── stripe/    ← Stripe Webhook
├── components/
│   └── feedback-widget.tsx ← 反馈收集（feedback-loop Skill）
└── supabase/
    └── migrations/        ← 数据库 schema
```

## 快速启动

```bash
# 1. 安装依赖
npm install

# 2. 配置环境变量
cp .env.example .env.local
# 填入 Supabase + Stripe + OpenAI 的 API Key

# 3. 初始化数据库
npx supabase db push

# 4. 启动开发服务器
npm run dev
```
