---
name: deploy-one-click
description: "当产品准备从本地走向公网时，用最小配置生成部署步骤、环境变量清单和回滚路径，优先选择单命令上线。"
---

# Deploy One Click

## 触发条件
- MVP 功能已经可用，准备给真实用户访问
- 需要把项目部署到 Vercel、Railway 或 Docker
- 团队希望减少手工配置和上线遗漏

## 工作流程
1. 明确运行环境、构建命令和必要环境变量。
2. 选择最简单的部署目标，不为未来规模提前复杂化。
3. 生成可复制的部署步骤和 smoke test。
4. 定义失败回滚动作和最小监控项。
5. 把部署文档和 `.env.example` 一起交付。

## 输出规范
- 至少包含部署平台、构建命令、环境变量和验证 URL
- 要说明上线后第一条人工检查动作
- 若有第三方服务，必须写清需要先配置什么

## 示例
- 输入：`把 TaskFlow SaaS 部署到 Vercel`
- 输出：
  - 构建命令 `next build`
  - 环境变量：`NEXT_PUBLIC_SUPABASE_URL`、`NEXT_PUBLIC_SUPABASE_ANON_KEY`
  - 上线后先访问 `/api/tasks` 做 smoke test，再登录页面验证任务列表
  - 回滚方式是恢复上一个 Vercel deployment
