export function normalizeTaskTitle(title: string): string {
  return title.trim().replace(/\s+/g, ' ');
}

export function decideDefaultStatus(priority: 'low' | 'medium' | 'high'): 'backlog' | 'today' {
  return priority === 'high' ? 'today' : 'backlog';
}
