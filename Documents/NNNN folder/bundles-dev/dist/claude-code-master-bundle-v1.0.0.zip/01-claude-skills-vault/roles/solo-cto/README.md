# Solo CTO

面向独立开发者、技术创始人和小团队主程的 Claude Code 角色系统。目标是用一套能落地的 Skill 组合，覆盖从需求收敛、建模、开发、部署到复盘的完整闭环。

## 包含内容

- `CLAUDE.md`：角色化系统提示词，约束决策优先级和工作方式
- `skills/`：8 个可独立使用的工程技能
- `hooks/pre-commit.sh`：提交前跑 lint、类型检查和安全检查
- `hooks/post-task.sh`：任务完成后自动写入 `progress.md`
- `examples/todo-saas/`：Todo SaaS MVP 演示项目，展示各个 Skill 的协同方式

## 技能清单

- `tdd-flow`：把一个需求切成一条条红绿重构循环
- `mvp-architect`：为 MVP 画清楚用户流、数据流和依赖边界
- `debug-detective`：从日志、假设和复现实验定位问题
- `api-designer`：设计 RESTful API、契约和错误格式
- `db-modeler`：输出表结构、迁移和索引建议
- `security-check`：上线前安全扫描和配置检查
- `deploy-one-click`：生成最小可部署方案和脚本
- `code-review-self`：交付前做自我 code review

## 演示项目

`examples/todo-saas/` 不是占位 README，而是一套可以直接拿去继续开发的 Next.js + Supabase MVP 骨架：

- `app/page.tsx`：产品首页
- `app/api/tasks/route.ts`：任务 API 路由
- `lib/`：任务策略和数据入口
- `supabase/migrations/`：建表 SQL
- `.env.example`：环境变量模板

## 安装

在仓库根目录运行：

```bash
bash install.sh solo-cto
```

重复执行是安全的；安装脚本只会覆盖当前角色的 `CLAUDE.md`、对应 Skills 和 Hooks。
