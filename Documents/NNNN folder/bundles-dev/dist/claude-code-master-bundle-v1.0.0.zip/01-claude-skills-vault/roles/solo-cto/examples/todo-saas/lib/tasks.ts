import { decideDefaultStatus, normalizeTaskTitle } from './task-policy';

export interface Task {
  id: string;
  title: string;
  priority: 'low' | 'medium' | 'high';
  status: 'backlog' | 'today' | 'done';
}

export function getSampleTasks(): Task[] {
  return [
    {
      id: 'task-1',
      title: 'Write launch copy',
      priority: 'high',
      status: 'today',
    },
    {
      id: 'task-2',
      title: 'Review Supabase RLS',
      priority: 'medium',
      status: 'backlog',
    },
  ];
}

export function createTask(input: {
  title: string;
  priority: 'low' | 'medium' | 'high';
}): Task {
  return {
    id: `task-${Date.now()}`,
    title: normalizeTaskTitle(input.title),
    priority: input.priority,
    status: decideDefaultStatus(input.priority),
  };
}
