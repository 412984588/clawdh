# Todo SaaS MVP

这个演示项目用最小的 Next.js + Supabase 结构演示 Solo CTO 角色如何工作。它不是一堆“空壳模板”，而是一条从需求到部署的参考实现路径。

## 场景

目标用户是需要一个多设备同步待办工具的独立顾问。核心需求：

- 创建、查看、完成任务
- 为任务打优先级和截止日期
- 保留简单、可快速部署的架构

## Skill 使用路径

1. `mvp-architect`：把功能收敛到任务 CRUD + 轻量认证
2. `db-modeler`：输出 `tasks` 表和索引
3. `api-designer`：定义 `/api/tasks` 的 GET / POST 合同
4. `tdd-flow`：先写任务状态策略测试，再写实现
5. `security-check`：检查 RLS、密钥暴露和输入校验
6. `deploy-one-click`：给出 Vercel + Supabase 的上线步骤

## 启动方式

```bash
npm install
npm run dev
```

## 文件说明

- `app/page.tsx`：首页与任务列表骨架
- `app/api/tasks/route.ts`：API 路由示例
- `lib/tasks.ts`：任务对象与读写入口
- `lib/task-policy.ts`：任务状态策略
- `supabase/migrations/001_create_tasks.sql`：数据库迁移
- `.env.example`：本地环境变量模板
