#!/usr/bin/env bash
set -euo pipefail

find_repo_root() {
  if git rev-parse --show-toplevel >/dev/null 2>&1; then
    git rev-parse --show-toplevel
  else
    pwd
  fi
}

repo_root="$(find_repo_root)"
progress_file="${CLAUDE_PROGRESS_FILE:-$repo_root/progress.md}"
task_label="${1:-${CLAUDE_TASK_NAME:-Task completed}}"
timestamp="$(date '+%Y-%m-%d %H:%M:%S %Z')"
tmp_file="$(mktemp "${TMPDIR:-/tmp}/progress.XXXXXX")"

if [ -f "$progress_file" ]; then
  cat "$progress_file" > "$tmp_file"
else
  printf '# Progress\n\n' > "$tmp_file"
fi

printf -- '- %s — %s\n' "$timestamp" "$task_label" >> "$tmp_file"
mv "$tmp_file" "$progress_file"

echo "Updated $progress_file"
