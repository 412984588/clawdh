import { getSampleTasks } from '../lib/tasks';

export default function HomePage(): JSX.Element {
  const tasks = getSampleTasks();

  return (
    <main className="mx-auto max-w-3xl px-6 py-12">
      <section className="space-y-3">
        <p className="text-sm font-medium uppercase tracking-[0.2em] text-slate-500">
          Todo SaaS MVP
        </p>
        <h1 className="text-4xl font-semibold text-slate-900">
          Ship a focused task manager before the weekend ends.
        </h1>
        <p className="text-base leading-7 text-slate-600">
          This demo keeps the product surface deliberately narrow: one shared inbox, one today view,
          and one API route that a solo founder can reason about.
        </p>
      </section>

      <section className="mt-10 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold text-slate-900">Today</h2>
          <span className="rounded-full bg-slate-100 px-3 py-1 text-sm text-slate-600">
            {tasks.length} tasks
          </span>
        </div>
        <ul className="mt-6 space-y-3">
          {tasks.map((task) => (
            <li key={task.id} className="rounded-2xl border border-slate-200 px-4 py-3">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="font-medium text-slate-900">{task.title}</p>
                  <p className="text-sm text-slate-500">{task.priority} priority</p>
                </div>
                <span className="text-sm text-slate-500">{task.status}</span>
              </div>
            </li>
          ))}
        </ul>
      </section>
    </main>
  );
}
