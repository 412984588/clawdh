import { NextRequest, NextResponse } from 'next/server';
import { createTask, getSampleTasks } from '../../../lib/tasks';

export async function GET(): Promise<NextResponse> {
  return NextResponse.json({ data: getSampleTasks() });
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  const body = (await request.json()) as {
    title?: string;
    priority?: 'low' | 'medium' | 'high';
  };

  const task = createTask({
    title: body.title ?? '',
    priority: body.priority ?? 'medium',
  });

  return NextResponse.json({ data: task }, { status: 201 });
}
