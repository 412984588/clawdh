---
name: tdd-flow
description: "当你要新增功能、修 Bug 或重构时，先把需求压成一个最小失败测试，再按 red-green-refactor 推进，直到可验证交付。"
---

# TDD Flow

## 触发条件
- 新增功能但需求还容易飘
- 修复线上问题，需要锁住回归测试
- 重构一段逻辑，想确保行为不变

## 工作流程
1. 先把需求改写成一个最小可验证行为，只测一件事。
2. 写失败测试并运行，确认它因为“功能缺失”而失败，不是因为拼写或环境错误。
3. 写最小实现让测试变绿，不顺手扩 scope。
4. 重新跑局部测试和相关全量测试，确认没有回归。
5. 最后才做轻量重构，并记录接下来要写的下一个测试。

## 输出规范
- 先给出测试名和被验证行为
- 明确展示红灯证据和绿灯证据
- 说明当前 cycle 没覆盖的风险点

## 示例
- 输入：`给 TaskFlow API 增加 high priority 任务自动进 today 列表`
- 输出：
  - 先写 `task-policy.test.ts`，断言 `high` 优先级默认状态是 `today`
  - 跑测试看到 `decideDefaultStatus` 缺失或返回错误
  - 再补 `decideDefaultStatus('high') => 'today'`
  - 重新跑测试确认变绿，再继续写 medium/low 的下一条测试
