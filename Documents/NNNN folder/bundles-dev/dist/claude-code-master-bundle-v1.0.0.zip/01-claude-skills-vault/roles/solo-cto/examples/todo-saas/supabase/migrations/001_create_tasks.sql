create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  priority text not null check (priority in ('low', 'medium', 'high')),
  status text not null check (status in ('backlog', 'today', 'done')),
  due_at timestamptz,
  created_at timestamptz not null default timezone('utc', now())
);

create index if not exists tasks_status_priority_idx
  on public.tasks (status, priority, created_at desc);
