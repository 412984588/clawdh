#!/usr/bin/env bash
set -euo pipefail

find_repo_root() {
  if git rev-parse --show-toplevel >/dev/null 2>&1; then
    git rev-parse --show-toplevel
  else
    pwd
  fi
}

has_npm_script() {
  local package_json="$1"
  local script_name="$2"

  node -e 'const fs = require("fs"); const pkg = JSON.parse(fs.readFileSync(process.argv[1], "utf8")); process.exit(pkg.scripts && pkg.scripts[process.argv[2]] ? 0 : 1);' \
    "$package_json" \
    "$script_name"
}

run_script_if_present() {
  local repo_root="$1"
  local package_json="$2"
  local script_name="$3"

  if has_npm_script "$package_json" "$script_name"; then
    echo "→ npm run $script_name"
    (cd "$repo_root" && npm run "$script_name")
  fi
}

repo_root="$(find_repo_root)"
package_json="$repo_root/package.json"

if [ ! -f "$package_json" ]; then
  echo "pre-commit: package.json not found, skipping Node checks."
  exit 0
fi

if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "pre-commit: node/npm unavailable, cannot run project checks."
  exit 1
fi

run_script_if_present "$repo_root" "$package_json" "lint"
run_script_if_present "$repo_root" "$package_json" "typecheck"
run_script_if_present "$repo_root" "$package_json" "test"

if has_npm_script "$package_json" "security:check"; then
  echo "→ npm run security:check"
  (cd "$repo_root" && npm run security:check)
elif [ -f "$repo_root/package-lock.json" ]; then
  echo "→ npm audit --omit=dev --audit-level=high"
  (cd "$repo_root" && npm audit --omit=dev --audit-level=high)
else
  echo "pre-commit: no security:check script or package-lock.json, skipping package audit."
fi
