#!/usr/bin/env bash
set -euo pipefail

ROLE_NAME="${1:?missing role name}"
PROJECT_ROOT="${2:?missing project root}"
CLAUDE_DIR="${3:?missing Claude target directory}"

ROLE_ROOT="$PROJECT_ROOT/roles/$ROLE_NAME"
SKILLS_DIR="$CLAUDE_DIR/skills"
HOOKS_DIR="$CLAUDE_DIR/hooks"
BACKUP_DIR="$CLAUDE_DIR/backups"

if [ ! -d "$ROLE_ROOT" ]; then
  echo "Role directory not found: $ROLE_ROOT"
  exit 1
fi

mkdir -p "$CLAUDE_DIR" "$SKILLS_DIR" "$HOOKS_DIR" "$BACKUP_DIR"

SOURCE_CLAUDE_MD="$ROLE_ROOT/CLAUDE.md"
TARGET_CLAUDE_MD="$CLAUDE_DIR/CLAUDE.md"

if [ -f "$TARGET_CLAUDE_MD" ] && ! cmp -s "$TARGET_CLAUDE_MD" "$SOURCE_CLAUDE_MD"; then
  cp "$TARGET_CLAUDE_MD" "$BACKUP_DIR/CLAUDE.$ROLE_NAME.backup.md"
fi

cp "$SOURCE_CLAUDE_MD" "$TARGET_CLAUDE_MD"

for skill_path in "$ROLE_ROOT"/skills/*; do
  [ -d "$skill_path" ] || continue
  skill_name="$(basename "$skill_path")"
  rm -rf "$SKILLS_DIR/$skill_name"
  cp -R "$skill_path" "$SKILLS_DIR/$skill_name"
done

for hook_path in "$ROLE_ROOT"/hooks/*.sh; do
  [ -f "$hook_path" ] || continue
  hook_name="$(basename "$hook_path")"
  cp "$hook_path" "$HOOKS_DIR/$hook_name"
  chmod +x "$HOOKS_DIR/$hook_name"
done

printf '%s\n' "$ROLE_NAME" > "$CLAUDE_DIR/active-role"

echo "Installed role: $ROLE_NAME"
