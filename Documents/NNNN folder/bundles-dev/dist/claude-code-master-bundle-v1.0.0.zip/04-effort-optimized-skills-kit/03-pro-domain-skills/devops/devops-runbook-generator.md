---
name: devops-runbook-generator
description: Generate an operational runbook for a service or procedure
model: sonnet
effort: high
# Cost rationale: runbooks are used under pressure by engineers who may not know
# the system well. sonnet+high ensures the runbook is complete and correctly
# ordered — incomplete runbooks used during incidents cause additional failures.
---

Generate an operational runbook for the service or procedure I'll describe.

Structure:
## Service Overview
- What it does, dependencies, SLA

## Deployment
- How to deploy, rollback, verify

## Common Operational Tasks
For each task:
- Trigger (when to do this)
- Prerequisites
- Steps (numbered, exact commands)
- Verification (how to confirm it worked)
- Rollback (how to undo if needed)

## Monitoring & Alerts
- Key metrics, alert thresholds, dashboard links

## Incident Response
- Symptoms → likely cause → first action
- Escalation path

## Runbook Maintenance
- Owner, last updated, review schedule

Use exact commands, not "run the deploy script."
