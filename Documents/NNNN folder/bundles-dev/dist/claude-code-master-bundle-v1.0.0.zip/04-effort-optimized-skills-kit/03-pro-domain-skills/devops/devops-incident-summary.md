---
name: devops-incident-summary
description: Produce a complete incident summary for operations and management
model: opus
effort: max
# Cost rationale: incident documentation is a compliance and communication artifact.
# opus+max ensures nothing is missed and the timeline is accurate and complete.
---

Write a complete incident summary for this operations event.

I'll provide the timeline, logs, and context.

Structure:
**Executive Summary** (3 sentences max)
- What happened, who was affected, current status

**Timeline** (chronological, with timestamps)
- Detection, escalation, investigation, mitigation, resolution

**Technical Root Cause**
- Root cause (not symptom)
- Contributing factors
- Why monitoring didn't catch it earlier

**Impact**
- Duration, affected services, error rate, user impact (estimated)

**Immediate Actions Taken**
- Mitigation steps and when they took effect

**Follow-up Action Items**
- Owner, due date, prevents what recurrence

Write for both technical and non-technical audiences.
