---
name: devops-dockerfile-audit
description: Audit a Dockerfile for security, performance, and best practice issues
model: sonnet
effort: high
# Cost rationale: Dockerfile issues lead to bloated images, security vulnerabilities,
# and slow CI. sonnet+high provides the reasoning depth to catch layer caching
# problems and security misconfigurations that sonnet+low misses.
---

Audit this Dockerfile for issues.

Check:
**Security**
- Running as root? (should be non-root user)
- Secrets in ENV or ARG instructions?
- Base image: specific version pinned or `:latest`?
- Attack surface: unnecessary packages installed?

**Performance**
- Layer order: frequently-changing files copied late? (cache invalidation)
- Multi-stage build used? (is it needed?)
- .dockerignore present and comprehensive?

**Size**
- Package manager cache cleared in same RUN layer?
- Debug tools excluded from production image?

**Correctness**
- HEALTHCHECK defined?
- ENTRYPOINT vs CMD used correctly?
- Signal handling for graceful shutdown?

Format: finding, severity, line number, fix.
