---
name: devops-k8s-config
description: Review Kubernetes manifests for security and correctness
model: opus
effort: high
# Cost rationale: Kubernetes misconfiguration leads to data exposure, cluster compromise,
# and outages. opus+high provides the analysis depth for RBAC, network policy,
# and resource limit reasoning that sonnet misses.
---

Review these Kubernetes manifests.

I'll provide the YAML files. Check:

**Security**
- Containers running as root?
- Privileged containers?
- hostNetwork or hostPID enabled?
- Capabilities added unnecessarily?
- Secrets managed correctly (not in ConfigMap, not in env vars from literals)
- Network policies defined? (default deny?)
- RBAC: service accounts with minimum necessary permissions?

**Reliability**
- Resource requests AND limits defined?
- Readiness and liveness probes configured?
- PodDisruptionBudget for critical workloads?
- Anti-affinity rules to spread replicas?

**Correctness**
- Image versions pinned (not :latest)?
- Environment-specific values via ConfigMap/Secret, not hardcoded?

Format: category, severity, manifest/line, finding, fix.
