---
name: devops-ci-review
description: Review a CI/CD pipeline configuration for correctness and security
model: sonnet
effort: medium
# Cost rationale: CI review is broad scanning of configuration — medium effort
# provides enough depth for pipeline review without opus pricing.
---

Review this CI/CD pipeline configuration.

I'll provide the pipeline file (GitHub Actions, GitLab CI, CircleCI, etc.).

Check:
**Security**
- Secrets passed correctly (not hardcoded, not echoed in logs)
- Pull request workflows: can a fork exfiltrate secrets?
- Third-party actions: version pinned with SHA?

**Correctness**
- Test step runs before deploy step
- Build artifacts cached and shared between jobs correctly
- Timeout configured on long-running jobs

**Reliability**
- Retry on flaky tests?
- Notification on failure?
- Rollback step if deploy fails?

**Performance**
- Jobs parallelized where possible?
- Expensive steps cached (npm install, etc.)?

Flag security issues first.
