---
name: data-quality-checklist
description: Quick data quality scan for a dataset or table
model: sonnet
effort: low
# Cost rationale: data quality scanning is structural checking — row counts,
# null rates, value distribution. Pattern work, not reasoning. sonnet+low.
---

Run a quick data quality check on this dataset or table.

I'll describe the schema and provide sample data or query results.

Check:
- **Completeness** — which columns have high null rates? (>5% is notable)
- **Uniqueness** — are columns that should be unique actually unique?
- **Consistency** — are categorical values consistent? (e.g., "US" vs "USA" vs "United States")
- **Range validity** — are numeric values in expected ranges? (negative ages, future dates in past fields)
- **Referential integrity** — foreign key values that don't exist in the referenced table

Output as a checklist. Flag anything above threshold.
