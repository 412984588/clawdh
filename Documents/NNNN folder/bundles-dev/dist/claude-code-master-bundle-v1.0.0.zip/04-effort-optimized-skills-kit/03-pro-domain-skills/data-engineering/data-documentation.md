---
name: data-documentation
description: Generate a data dictionary for a database schema or data model
model: sonnet
effort: medium
# Cost rationale: data dictionary generation is structured documentation extraction.
# medium effort provides enough depth to generate meaningful descriptions without
# opus pricing. The value is in coverage, not analytical depth.
---

Generate a data dictionary for this schema.

I'll provide the DDL, ORM models, or migration files.

For each table:
- **Purpose** — what real-world entity does this represent?
- **Key relationships** — how does it relate to other tables?

For each column:
- **Description** — what does this value represent?
- **Type** — data type and constraints
- **Valid values** — if enum or constrained
- **Notes** — nullable? default? when would it be null?

Format as Markdown tables. One table per database table.
