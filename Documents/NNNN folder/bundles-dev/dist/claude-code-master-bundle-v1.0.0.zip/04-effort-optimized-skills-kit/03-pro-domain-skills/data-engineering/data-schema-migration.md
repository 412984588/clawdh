---
name: data-schema-migration
description: Review a data schema migration for safety, correctness, and rollback plan
model: opus
effort: high
# Cost rationale: data schema migrations on production databases are irreversible if
# done wrong. opus+high to reason about locking, data loss, and rollback completeness.
---

Review this data schema migration for safety.

I'll provide the migration script.

Check:
**Data loss risk**
- Does this DROP or ALTER anything that could lose data?
- Is data backed up before the migration runs?
- What's the recovery path if this fails halfway?

**Locking and performance**
- Does this take an exclusive table lock? For how long?
- Can this run in a transaction? Should it?
- For large tables: is an online DDL approach needed?

**Rollback**
- Is there a down migration? Is it correct?
- If the migration fails at step N, what state is the DB in?

**Correctness**
- Are indexes created before or after data is loaded? (matters for performance)
- Are constraints added correctly (NOT VALID + VALIDATE pattern for Postgres)?
- Are sequences/auto-increment reset correctly?

**Application compatibility**
- Can the application run against both old and new schema? (zero-downtime requirement)
- Are old column names kept during transition?

Flag anything that could cause data loss or extended downtime.
