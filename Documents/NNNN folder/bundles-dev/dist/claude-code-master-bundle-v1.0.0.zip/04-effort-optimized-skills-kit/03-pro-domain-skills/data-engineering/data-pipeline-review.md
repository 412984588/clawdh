---
name: data-pipeline-review
description: Review a data pipeline (ETL/ELT) for correctness, reliability, and performance
model: opus
effort: high
# Cost rationale: data pipeline bugs silently corrupt downstream analytics.
# opus+high for the depth needed to catch data quality issues and failure modes
# that cause silent data loss without raising errors.
---

Review this data pipeline for issues.

I'll provide the pipeline code or description.

Check:
**Data correctness**
- Deduplication: can records be processed twice?
- Schema evolution: what happens when upstream schema changes?
- Null handling: are nulls handled explicitly or silently propagated?
- Type coercions: implicit conversions that could lose data?

**Reliability**
- Idempotency: is it safe to re-run on failure?
- Checkpointing: where does it resume after failure?
- Late data: how is data arriving after the window handled?

**Performance**
- Full table scans that could be incremental?
- Shuffles that could be avoided?
- Partition strategy appropriate for the query patterns?

**Monitoring**
- Row count validation between stages?
- Data freshness SLA monitored?

Report findings with severity and fix recommendation.
