---
name: data-query-optimizer
description: Analyze SQL queries for performance issues and suggest optimizations
model: sonnet
effort: high
# Cost rationale: query optimization requires understanding query plans, index usage,
# and data distribution. sonnet+high provides the reasoning depth to suggest
# meaningful optimizations, not just "add an index."
---

Optimize these SQL queries.

I'll provide the queries and (if available) EXPLAIN ANALYZE output.

For each query:
1. **Identify the bottleneck** — sequential scan, sort, hash join, index miss?
2. **Suggest indexes** — composite indexes, partial indexes, covering indexes
3. **Rewrite opportunities** — CTEs that prevent optimization, unnecessary subqueries
4. **Estimated improvement** — rough order of magnitude

Also check:
- N+1 query patterns (queries in loops)
- Missing LIMIT clauses on unbounded queries
- Cartesian products (missing JOIN conditions)

Output the optimized query with an explanation of each change.
