---
name: fintech-error-handling
description: Review error handling in financial code paths for correctness and safety
model: sonnet
effort: high
# Cost rationale: financial error handling requires understanding partial failure modes.
# sonnet+high is the right balance — deep enough to reason about transaction
# rollback completeness, cheap enough to run on every feature.
---

Review error handling in this financial code path.

Check:
**Transaction integrity**
- If an error occurs mid-transaction, is the state consistent?
- Are partial writes rolled back completely?
- Are compensating transactions implemented where needed?

**Idempotency on retry**
- If this operation is retried after a network error, is it safe?
- Can money be double-charged?

**Error messages**
- Do error messages leak internal details (account IDs, stack traces)?
- Are errors logged with enough context for debugging without exposing PII?

**Timeout handling**
- What happens when the payment gateway times out?
- Is the user's state clear? (pending vs failed vs unknown)

Report findings with the exact code path and recommended fix.
