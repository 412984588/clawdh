---
name: fintech-compliance-check
description: Scan financial code for regulatory compliance issues (PCI, AML, KYC patterns)
model: opus
effort: max
# Cost rationale: regulatory violations in fintech carry fines and license revocation.
# No token budget cap for compliance review. Run before each release touching payments.
---

Perform a compliance scan on this financial code.

Check for:
**PCI DSS**
- Cardholder data stored beyond necessity
- PAN displayed or logged anywhere
- CVV/CVV2 stored after authorization

**AML/KYC**
- User identification data handling
- Transaction monitoring thresholds properly implemented
- Suspicious activity flagging present

**Data protection**
- Sensitive financial data encrypted at rest
- Audit trail for all financial transactions
- Data retention limits respected

**Regulatory patterns**
- Idempotency keys on payment operations
- Transaction rollback completeness
- Reconciliation data integrity

Format: finding, regulatory reference, file:line, severity, fix.
