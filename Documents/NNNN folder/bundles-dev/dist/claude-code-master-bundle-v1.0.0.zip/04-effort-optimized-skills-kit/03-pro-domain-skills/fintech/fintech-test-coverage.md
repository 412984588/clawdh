---
name: fintech-test-coverage
description: Assess test coverage for financial code with compliance-relevant scenarios
model: sonnet
effort: high
# Cost rationale: compliance requires demonstrable test coverage for financial flows.
# sonnet+high to reason about coverage gaps in business logic, not just line coverage.
---

Assess test coverage for this financial feature.

Look at the code and existing tests. Identify missing test cases for:

**Happy path**
- Standard transaction flow from start to completion
- All supported payment methods

**Financial edge cases**
- Zero amount, maximum amount, precision edge cases
- Concurrent transactions on the same account
- Insufficient funds

**Failure scenarios**
- Payment gateway unavailable
- Network timeout during processing
- Database write failure after external success

**Regulatory scenarios**
- Transaction at AML reporting threshold
- International transaction with currency conversion
- Refund to a different payment method than charge

Output a list of missing test cases with priority (P0/P1/P2).
