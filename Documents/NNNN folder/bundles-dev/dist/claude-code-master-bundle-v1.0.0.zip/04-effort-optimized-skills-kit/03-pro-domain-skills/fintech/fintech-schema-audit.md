---
name: fintech-schema-audit
description: Audit financial database schemas for PCI relevance and data integrity
model: opus
effort: high
# Cost rationale: financial schema errors cause data loss and compliance failures.
# opus+high to catch cascade rules, precision issues, and audit trail gaps.
---

Audit this financial database schema.

Check:
**Data types**
- Monetary amounts: DECIMAL(19,4) not FLOAT (floating point is wrong for money)
- Timestamps: timezone-aware, not naive

**Constraints**
- Non-negative constraints on amounts
- Foreign key constraints on all relationships
- Unique constraints on transaction IDs

**PCI relevance**
- Tables storing card data: are they isolated?
- Are PAN columns masked/tokenized?

**Audit trail**
- Every financial transaction: created_at, updated_at, created_by, status history
- Immutable records where required (no UPDATE on completed transactions)

**Migration safety**
- Is this migration safe on a live financial system?
- Rollback plan?

Flag anything that could cause financial data loss or regulatory issues.
