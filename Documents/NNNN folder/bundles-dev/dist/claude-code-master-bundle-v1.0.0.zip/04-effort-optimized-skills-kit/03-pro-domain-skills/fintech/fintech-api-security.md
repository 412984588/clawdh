---
name: fintech-api-security
description: Security audit for financial APIs — payment endpoints, account access, transfers
model: opus
effort: high
# Cost rationale: financial API vulnerabilities directly enable fraud.
# opus+high for the analysis depth needed to catch authorization gaps and
# business logic flaws that standard security scanners miss.
---

Audit this financial API for security vulnerabilities.

Focus on:
**Authorization**
- Can user A see or modify user B's account data?
- Amount validation — can negative amounts be submitted?
- Can completed transactions be modified?

**Idempotency**
- Are payment endpoints idempotent? What happens on retry?
- Is there a replay attack window?

**Rate limiting**
- Are sensitive endpoints rate-limited? (login, transfers, balance inquiry)

**Input validation**
- Currency amounts — precision handling, overflow
- Account identifiers — IDOR via enumerable IDs

**Webhook security**
- Signature verification on incoming payment webhooks
- HTTPS enforcement

Report: severity, endpoint, attack scenario, fix.
