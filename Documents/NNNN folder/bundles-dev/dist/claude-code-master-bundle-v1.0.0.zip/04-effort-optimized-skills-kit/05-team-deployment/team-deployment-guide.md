# Team Deployment Guide — Effort-Optimized Skills Kit

## Overview

This guide covers deploying the Effort-Optimized Skills Kit for a team using shared Claude Code settings.

---

## Deployment Options

### Option A: Per-Developer Installation (Recommended for small teams)

Each developer runs `install.sh` on their own machine:

```bash
# Install all 25 skills
bash templates/01-skills-core/install.sh

# Install only specific profiles
bash templates/01-skills-core/install.sh scout
bash templates/01-skills-core/install.sh workhorse
```

Skills land in `~/.claude/skills/effort-kit/` and are immediately available.

### Option B: Project-Level Installation (Shared codebase)

Check in selected skills to the project's `.claude/skills/` directory:

```bash
# Project-level skills (committed to repo)
mkdir -p .claude/skills/effort-kit
cp -r templates/01-skills-core/scout-profile/*.md .claude/skills/effort-kit/
cp -r templates/01-skills-core/workhorse-profile/*.md .claude/skills/effort-kit/
```

Note: Pro-tier Burst and Deep Work skills are typically personal, not project-level.

---

## Team Settings Configuration

Copy `team-settings-template.json` to `~/.claude/settings.json`:

```bash
cp templates/05-team-deployment/team-settings-template.json ~/.claude/settings.json
```

Edit:
1. Remove the `_comment`, `_replace`, `_effort_profiles_note`, `_env_overrides` keys
2. Update hook paths to your actual hook locations
3. Adjust `defaultEffort` if needed (default: `medium`)

---

## Per-Developer Overrides (Without Breaking Team Defaults)

Developers can override team settings without modifying the shared file:

### Project-level override
Create `.claude/settings.json` in the project root:
```json
{
  "defaultEffort": "high",
  "_note": "This project requires higher effort defaults due to complexity"
}
```

### Session-level override
```bash
# Force low effort for this session (cost-saving mode)
CLAUDE_CODE_EFFORT_LEVEL=low claude

# Force high effort for this session
CLAUDE_CODE_EFFORT_LEVEL=high claude
```

### Precedence (highest to lowest)
1. `CLAUDE_CODE_EFFORT_LEVEL` environment variable
2. Project `.claude/settings.json`
3. User `~/.claude/settings.json`
4. Skill frontmatter `effort:` field
5. Session default

---

## Cost Tracking for Teams

Use a PostToolUse hook to log all skill invocations with their effort levels:

```bash
# ~/.claude/hooks/log-skill-cost.sh
#!/bin/bash
INPUT=$(cat)
TOOL=$(echo "$INPUT" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('tool_name',''))" 2>/dev/null)
if [ "$TOOL" = "skill_invocation" ] || echo "$TOOL" | grep -q "skill"; then
  echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) SKILL $INPUT" >> ~/.claude/skill-usage.log
fi
```

Aggregate with: `cat ~/.claude/skill-usage.log | python3 -c "import sys,json; [print(json.loads(l.split(' SKILL ')[1]).get('tool_name','')) for l in sys.stdin if ' SKILL ' in l]"`

---

## Onboarding New Team Members

```bash
# 1. Clone and install
git clone <this-repo> effort-skills
cd effort-skills

# 2. Install skills
bash templates/01-skills-core/install.sh

# 3. Copy settings
cp templates/05-team-deployment/team-settings-template.json ~/.claude/settings.json
# Edit to remove _comment keys

# 4. Verify
claude --version
ls ~/.claude/skills/effort-kit/ | wc -l  # Should be 25

# 5. Test a Scout skill
echo "test commit" | git commit -F - --allow-empty 2>/dev/null
# Then run: /commit-message
```

---

## Quarterly Update Process

When a new version of the kit is released:

```bash
# Pull latest
git pull

# Re-install to pick up new/updated skills
bash templates/01-skills-core/install.sh

# Review CHANGELOG.md for breaking changes
cat CHANGELOG.md | head -50
```
