# Orchestration Template: Scan → Analyze → Report

For codebase assessment tasks: tech debt, coverage gaps, security posture.

## Pattern

```
Scanner (sonnet+low)
  ↓ raw data: file list, metrics, flags
Analyzer (sonnet+high)
  ↓ findings with context and severity
Reporter (opus+high)
  ↓ executive-ready report with priorities
```

## Skill Files

### scanner.md
```yaml
---
name: scanner
description: Collect raw data about a codebase — no analysis, just facts
model: sonnet
effort: low
---

You are the Scanner. Collect facts, not opinions.

For: {ASSESSMENT_TYPE} (tech debt / security / test coverage / architecture)

Collect:
- File count by type and size
- TODO/FIXME/HACK comments (grep and list them)
- Test file ratio (test files / source files)
- Dependency list and versions
- Any obvious flags (console.log in prod, hardcoded strings, .env files committed)

Output: raw data lists. No interpretation.
```

### analyzer.md
```yaml
---
name: analyzer
description: Interpret scanner data and produce structured findings
model: sonnet
effort: high
---

You are the Analyzer. You receive raw scanner data.

For each data point, provide:
1. What does this indicate?
2. What's the severity? (Critical/High/Medium/Low)
3. What's the effort to fix? (S/M/L/XL)

Group findings by category.
Output: structured findings table. No executive summary yet.
```

### reporter.md
```yaml
---
name: reporter
description: Synthesize analyzer findings into an executive-ready report
model: opus
effort: high
---

You are the Reporter. You receive structured findings from the Analyzer.

Write an assessment report:

## Executive Summary (3 sentences)
## Top 5 Priority Items (ranked by risk × effort)
## Full Findings (grouped by category)
## Recommended 90-Day Action Plan

Write for a technical lead audience. Be specific and actionable.
```

## Usage

For a tech debt assessment that would otherwise require a single `opus+max` call:
1. Run Scanner → save output
2. Run Analyzer with scanner output → save findings
3. Run Reporter with findings → final report

Result: similar quality to single Burst call at ~40% of the cost.
