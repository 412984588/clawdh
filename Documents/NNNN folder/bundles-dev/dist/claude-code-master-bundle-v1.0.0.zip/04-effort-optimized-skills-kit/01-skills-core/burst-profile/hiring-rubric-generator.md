---
name: hiring-rubric-generator
description: Generate a structured hiring rubric for a technical role
model: opus
effort: max
# Cost rationale: hiring rubrics are used for many candidates over months.
# A rubric that misses key competencies means systematic mis-hiring.
# opus+max ensures the rubric is comprehensive and well-calibrated.
# One-shot investment that pays off across multiple hiring decisions.
---

Generate a structured hiring rubric for the role I'll describe.

I'll provide: job title, team context, required skills, nice-to-have skills.

Structure:
## Role Overview
- What this person will own, what success looks like in 6 months

## Evaluation Dimensions
For each dimension:
- **Name** — what we're measuring
- **Why it matters** — the business reason
- **Level 1 (Not Yet)** — concrete description
- **Level 2 (Developing)** — concrete description
- **Level 3 (Strong)** — concrete description
- **Level 4 (Exceptional)** — concrete description
- **Interview questions** — 2-3 questions that probe this dimension
- **Red flags** — answers that should concern us

## Scoring
- How to combine dimension scores
- Minimum bar per dimension (if any)
- Final recommendation rubric (Strong Yes / Yes / No / Strong No)

Be specific and behavioral. Avoid vague criteria like "strong communicator."
