---
name: codebase-summary
description: Produce a comprehensive summary of what this codebase does and how it's structured
model: opus
effort: max
# Cost rationale: understanding a full codebase requires reading many files and
# building a complete mental model. max effort means no token cap on output —
# the summary can be as complete as needed. Use once when onboarding to a codebase,
# not as a daily tool.
---

Produce a comprehensive summary of this codebase.

Read: README.md, package.json/requirements.txt, directory tree (run `find . -type f | head -200`), and key entry point files.

Cover:
1. **What it does** — what problem does this software solve?
2. **Architecture** — how is it structured? What are the main components?
3. **Data flow** — how does data move through the system?
4. **Key files** — which files are most important to understand?
5. **External dependencies** — what does it depend on? (databases, APIs, services)
6. **Test coverage** — what's tested? What isn't?
7. **Known issues** — any TODO/FIXME/HACK comments that signal problems?
8. **Entry points** — how do you run it? How do you run tests?

Be comprehensive. This is a one-time investment in understanding.
