---
name: security-audit-critical
description: Full security audit for production-critical code — no token budget cap
model: opus
effort: max
# Cost rationale: PRODUCTION SECURITY. This is the canonical case for opus+max.
# No token cap means the model will not cut corners to stay within budget.
# Use for: auth systems, payment processing, PII handling, crypto implementations.
# Do NOT use daily — this is a one-shot audit for critical components.
# Cost: ~$0.15-$0.50/call. Worth every cent for production security review.
---

Perform a comprehensive security audit. This is a critical system. Be exhaustive.

I'll provide the code. Leave nothing unchecked.

**Authentication & session management**
- Token generation, storage, expiry, revocation
- Session fixation, hijacking, replay attacks

**Authorization**
- Every endpoint: who can call it? Can they call it on behalf of others?
- Horizontal and vertical privilege escalation paths

**Input handling**
- Every external input path: injection, traversal, deserialization
- File uploads, URL parameters, headers, cookies, WebSocket messages

**Cryptography**
- Algorithm choices, key management, IV reuse, timing attacks
- Password hashing algorithm and parameters

**Data exposure**
- What can an unauthenticated attacker learn?
- What can a low-privilege authenticated user learn about others?

**Dependencies**
- Any CVE-affected packages in this code path?

**Business logic**
- Race conditions, TOCTOU, transaction integrity
- What happens if an operation is retried? Replayed?

Format: CRITICAL / HIGH / MEDIUM, file:line, description, exploit scenario, fix.
Order by severity. Miss nothing.
