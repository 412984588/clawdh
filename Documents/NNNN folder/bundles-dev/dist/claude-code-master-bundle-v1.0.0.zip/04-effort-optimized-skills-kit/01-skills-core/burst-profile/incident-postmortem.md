---
name: incident-postmortem
description: Write a thorough incident postmortem with root cause analysis
model: opus
effort: max
# Cost rationale: a postmortem's value is in its completeness and accuracy.
# A shallow postmortem that misses a contributing cause means the incident recurs.
# opus+max ensures the contributing factor chain is traced fully, not truncated.
---

Write a thorough incident postmortem.

I'll provide: what happened, timeline, what we did to fix it.

Structure:
## Incident Summary
- Date, duration, severity, services affected

## Timeline
- Chronological sequence with timestamps

## Root Cause
- The fundamental cause (not the symptom)
- Contributing factors (what made this possible?)
- Why existing safeguards didn't prevent it

## Impact
- Who was affected, how many users, business impact

## What Went Well
- Detection, communication, mitigation speed

## What Went Poorly
- Gaps in monitoring, process, tooling

## Action Items
- Concrete follow-ups with owner and due date
- Address root cause AND each contributing factor

Write for a technical audience. Be honest about what failed.
