---
name: tech-debt-assessment
description: Comprehensive tech debt assessment with prioritized remediation plan
model: opus
effort: max
# Cost rationale: tech debt assessment is a strategic input to quarterly planning.
# It requires reading broadly across the codebase AND reasoning about business impact.
# opus+max is appropriate for a one-time comprehensive assessment that informs
# months of prioritization decisions. Not for weekly use.
---

Perform a comprehensive technical debt assessment.

Scan the codebase systematically:

1. **Code quality**
   - Duplication, dead code, overly complex functions
   - Missing abstractions, leaky abstractions
   - Inconsistent patterns within the same layer

2. **Architecture debt**
   - Coupling that should be loose, cohesion that should be high
   - Missing service boundaries, monolith sprawl
   - Database schema issues

3. **Test debt**
   - Coverage gaps (run test coverage if possible)
   - Tests that don't actually test the right thing
   - Missing integration tests for critical paths

4. **Dependency debt**
   - Outdated major versions, abandoned packages
   - Over-dependency (can we remove some?)

5. **Documentation debt**
   - Undocumented APIs, unclear README, missing runbooks

For each item: severity (Critical/High/Medium/Low), estimated effort to fix (S/M/L/XL), and recommended priority.

Output a prioritized backlog, not just a list of problems.
