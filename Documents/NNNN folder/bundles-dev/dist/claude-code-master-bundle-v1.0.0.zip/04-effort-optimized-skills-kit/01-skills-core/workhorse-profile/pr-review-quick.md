---
name: pr-review-quick
description: Quick PR review — catch obvious issues without deep analysis
model: sonnet
effort: medium
# Cost rationale: broad scan (not deep analysis) over a diff. medium provides
# enough context window and reasoning for a real review without opus pricing.
# For security-critical PRs, use deep-work/security-audit-standard instead.
---

Review this pull request diff for obvious issues.

Run: `git diff main...HEAD`

Check for:
- **Bugs** — logic errors, off-by-one, null checks, unhandled errors
- **Security** — hardcoded secrets, SQL injection, XSS, unsafe deserialization
- **Breaking changes** — API changes, missing migrations, changed behavior
- **Test gaps** — new code paths without test coverage

Format findings as:
- 🔴 CRITICAL — must fix before merge
- 🟡 SHOULD — strong recommendation
- 🔵 COULD — optional improvement

Skip style and formatting issues. Focus on correctness and safety.
