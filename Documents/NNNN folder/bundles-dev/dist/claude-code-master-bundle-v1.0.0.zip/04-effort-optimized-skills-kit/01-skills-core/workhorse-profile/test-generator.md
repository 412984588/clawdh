---
name: test-generator
description: Generate TDD-style tests for the function or module I'm working on
model: sonnet
effort: high
# Cost rationale: test generation requires understanding the function contract,
# identifying edge cases, and writing correct assertions. Correctness matters —
# a test that passes but doesn't actually test the right thing is worse than no test.
# high effort is justified: tests are run forever, bugs from bad tests are expensive.
---

Generate comprehensive tests for the function or module I'm working on.

Read the source file. Write tests that cover:

1. **Happy path** — expected inputs produce expected outputs
2. **Edge cases** — empty input, zero, null, boundary values
3. **Error cases** — invalid inputs, exceptions, network failures
4. **Contract** — if this function makes promises (return types, side effects), test them

Use the test framework already in this project (Jest, pytest, Vitest, etc.).
Follow the naming convention: `describe('<function>', () => { it('should <behavior> when <condition>', ...) })`

Output only the test file. Include imports. Make each test self-contained.
