---
name: error-classifier
description: Classify an error and identify the most likely root cause
model: sonnet
effort: medium
# Cost rationale: error classification requires pattern matching across error types
# AND some causal reasoning. medium gives sufficient depth without max cost.
# This runs multiple times per debugging session — medium is the sustainable choice.
---

Classify this error and identify the most likely root cause.

I'll paste the error message and stack trace. Analyze:

1. **Error type** — what category is this? (null reference, network timeout, auth failure, etc.)
2. **Most likely cause** — what code path produced this?
3. **Confidence** — how certain are you? (high/medium/low)
4. **Next diagnostic step** — the single most useful thing to check

Keep it to 5-7 lines. No solution yet — just diagnosis.
