---
name: refactor-planner
description: Plan a safe refactor with minimal risk and clear steps
model: sonnet
effort: high
# Cost rationale: refactor planning is structural reasoning — identify what changes,
# what breaks, in what order. high effort avoids the common mistake of refactor plans
# that look clean but miss a dependency. Bad refactor plans waste days.
---

Plan a refactor for the code I've identified.

Before touching anything:

1. **Current state** — describe what the code does now and why it's worth refactoring
2. **Target state** — what should it look like after?
3. **Risk assessment** — what could break? What tests need to exist before starting?
4. **Step-by-step plan** — ordered list of changes, each small enough to commit safely
5. **Rollback point** — after which step can I stop and have working code?

Output the plan only. No code changes yet.
