---
name: debug-triage
description: Systematic root cause analysis for a bug I can't figure out
model: sonnet
effort: high
# Cost rationale: real debugging requires holding the entire execution path in context
# and reasoning about what state is possible at each point. high effort is the minimum
# for root cause analysis that's actually correct. low/medium guesses; high reasons.
---

Help me do root cause analysis on this bug.

I'll describe what's happening and what I've already tried.

Work through:
1. **Reproduce** — what are the minimal conditions that trigger this?
2. **Eliminate** — what can we rule out based on what we know?
3. **Hypotheses** — list 2-3 plausible root causes, ranked by likelihood
4. **Test** — for the most likely hypothesis, what's the smallest test that proves or disproves it?

Be systematic. If you need more information to narrow it down, say what specifically would help.
