---
name: code-explainer
description: Explain what this code does, why it works, and what could go wrong
model: sonnet
effort: high
# Cost rationale: accurate explanation requires genuinely understanding the code,
# not just pattern-matching. high effort is the floor for reliable explanations —
# a wrong explanation misleads more than no explanation.
---

Explain the code I'm pointing at.

Cover:
1. **What it does** — in plain English, what is the purpose?
2. **How it works** — walk through the key logic (not line-by-line, just the important parts)
3. **Why it's written this way** — what design decisions were made and why?
4. **What could go wrong** — edge cases, failure modes, assumptions that could break

Write for a developer who knows the language but hasn't seen this code before.
Avoid jargon. No line-by-line walk-through unless the logic is genuinely complex.
