---
name: quick-docstring
description: Add a docstring to the selected function
model: sonnet
effort: low
# Cost rationale: inline documentation for a single function is formulaic.
# The function signature + body provides all needed context. No reasoning depth required.
---

Add a docstring to the function I'm pointing at.

Read the function. Write a docstring that covers:
- What it does (one sentence)
- Parameters (name, type, what they mean)
- Return value
- Raises (if any)

Use the docstring style already in this file. If none, use Google style.
Output only the updated function with docstring. No explanation.
