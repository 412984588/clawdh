---
name: dependency-audit
description: Scan package.json or requirements.txt for outdated or suspicious packages
model: sonnet
effort: low
# Cost rationale: dependency scanning is list-matching and version comparison.
# No reasoning depth needed. sonnet+low handles this as fast pattern work.
---

Audit the project dependencies for issues.

Read: package.json (or requirements.txt / Cargo.toml / go.mod, whichever exists).

Report:
1. **Outdated** — packages with a known newer stable version (use your knowledge cutoff)
2. **Suspicious** — packages with very low download counts, unusual names, or typosquat risk
3. **Unused** — packages that appear in dependencies but aren't imported anywhere (sample 5 files)

Format as a table. Flag critical issues. Keep it concise.
