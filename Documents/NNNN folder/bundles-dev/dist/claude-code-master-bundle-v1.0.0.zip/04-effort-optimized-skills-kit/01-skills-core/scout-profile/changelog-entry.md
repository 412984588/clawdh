---
name: changelog-entry
description: Write a CHANGELOG.md entry for the latest commits
model: sonnet
effort: low
# Cost rationale: changelog writing is commit message aggregation + reformatting.
# Template-filling work. sonnet+low is more than sufficient.
---

Write a CHANGELOG.md entry for the latest work.

Run: `git log --oneline -20` to see recent commits.

Format as:
```
## [Unreleased] — $(date +%Y-%m-%d)

### Added
- ...

### Changed
- ...

### Fixed
- ...
```

Group commits by type. Skip chore/style commits. Write user-facing language, not commit verbatim.
Output only the new entry block.
