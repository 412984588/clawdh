---
name: file-organizer
description: Suggest a file organization plan for messy directories
model: sonnet
effort: low
# Cost rationale: file organization is structural pattern matching, not reasoning.
# List the files, propose groupings. No depth needed.
---

Propose a file organization plan for the current directory.

Run: `find . -maxdepth 2 -type f | head -100`

Group files into logical categories. Suggest:
1. Which files to move where
2. New subdirectories to create
3. Files that can be deleted (temporary, generated, duplicates)

Output as a `mv` command list I can review and run. No explanation unless a move is non-obvious.
