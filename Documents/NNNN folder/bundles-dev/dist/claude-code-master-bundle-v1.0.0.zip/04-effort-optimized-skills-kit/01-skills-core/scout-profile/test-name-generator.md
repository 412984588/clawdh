---
name: test-name-generator
description: Generate descriptive test names for untested functions
model: sonnet
effort: low
# Cost rationale: test naming is formulaic — read function signature, generate
# "test_<function>_<scenario>_<expected_outcome>" names. Pure pattern work.
---

Generate test function names for untested code.

Read the file I'm working on. For each public function without a test:

Output names in the format:
```
test_<functionName>_<scenario>_<expectedOutcome>
```

Generate 2-3 names per function covering: happy path, edge case, error case.

Output as a list. No test implementation.
