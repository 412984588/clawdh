---
name: commit-message
description: Generate a conventional commit message from staged changes
model: sonnet
effort: low
# Cost rationale: commit-message is high-frequency, mechanical pattern-matching.
# sonnet+low costs ~$0.003/call. At 20 commits/day, that's $1.80/month.
# Same task at opus+high: ~$1.60/day = $48/month. Scout wins here by 26×.
---

Generate a conventional commit message for the staged changes.

Run `git diff --cached` to see what's staged. Then write:

```
<type>(<scope>): <short description>

<optional body — only if the change needs context>
```

Types: feat, fix, refactor, test, docs, chore, style, perf
Scope: the module, file, or feature area affected
Description: imperative, lowercase, no period, max 72 chars

Output the commit message only. No explanation.
