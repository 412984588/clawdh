---
name: pr-summary
description: Write a concise PR description from the diff
model: sonnet
effort: low
# Cost rationale: summarizing a diff is structural extraction, not deep reasoning.
# sonnet+low handles this accurately. No depth needed beyond pattern recognition.
---

Write a pull request description for the current branch vs main.

Run: `git log main..HEAD --oneline` and `git diff main...HEAD --stat`

Output:
## Summary
<2-3 bullet points of what changed and why>

## Test plan
<brief checklist of how to verify this works>

Keep it under 200 words. No padding.
