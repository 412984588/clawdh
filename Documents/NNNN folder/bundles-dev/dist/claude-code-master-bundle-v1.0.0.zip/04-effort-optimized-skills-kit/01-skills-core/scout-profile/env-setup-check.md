---
name: env-setup-check
description: Verify the dev environment has all required dependencies
model: sonnet
effort: low
# Cost rationale: environment verification is config file reading + version checking.
# Structural work, no reasoning depth. Fast and cheap is the right call.
---

Check that this project's development environment is correctly set up.

Read: package.json (or requirements.txt / Cargo.toml), README.md, .env.example (if exists).

Run: node --version, python3 --version, etc. as appropriate.

Report:
- ✅ Requirements met
- ❌ Missing or wrong version — with the exact version needed and how to fix
- ⚠️ .env variables defined in .env.example but missing from .env

Output as a checklist. Flag blockers first.
