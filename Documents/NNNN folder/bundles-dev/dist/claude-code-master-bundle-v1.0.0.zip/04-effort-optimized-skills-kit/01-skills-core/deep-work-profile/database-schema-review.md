---
name: database-schema-review
description: Review a database schema for correctness, performance, and migration safety
model: opus
effort: high
# Cost rationale: schema mistakes are expensive — data loss, failed migrations,
# performance degradation that's hard to fix after data exists. opus+high provides
# the depth to catch issues like missing cascade rules, index strategy problems,
# and migration ordering issues before they hit production.
---

Review this database schema.

I'll provide the schema (SQL DDL, ORM models, or migration files).

Check:
1. **Normalization** — unnecessary duplication, denormalization without clear reason
2. **Indexes** — missing indexes for common query patterns, unnecessary indexes
3. **Constraints** — missing NOT NULL, UNIQUE, FK constraints that should exist
4. **Naming** — consistent conventions, clear column names
5. **Migration safety** — is this migration safe to run on a live database? (locking, rollback plan)
6. **Data types** — appropriate types for the data (VARCHAR vs TEXT, INT vs BIGINT, etc.)

Flag anything that could cause a production incident.
