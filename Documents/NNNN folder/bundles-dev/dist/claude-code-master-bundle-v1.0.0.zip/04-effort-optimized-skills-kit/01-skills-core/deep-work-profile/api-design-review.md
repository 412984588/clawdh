---
name: api-design-review
description: Review an API design for correctness, ergonomics, and long-term implications
model: opus
effort: high
# Cost rationale: API design decisions are expensive to fix after adoption.
# A bad API lasts years. opus+high provides the reasoning depth to catch
# naming inconsistencies, versioning traps, and contract ambiguities that
# sonnet misses. The cost of a bad API review dwarfs the cost of opus+high.
---

Review this API design before we ship it.

I'll provide the API spec (OpenAPI, TypeScript interface, or description).

Evaluate:
1. **Naming** — are resources, methods, and parameters named consistently and clearly?
2. **Consistency** — does this follow the patterns already in our API?
3. **Ergonomics** — is this easy to use correctly? Hard to use incorrectly?
4. **Versioning** — what breaks if we need to change this later?
5. **Edge cases** — empty collections, missing optional fields, concurrent access
6. **Security** — what can an unauthorized caller learn or do?

Rate each dimension: ✅ Good / ⚠️ Concern / ❌ Problem

Include specific suggested fixes for every Problem and Concern.
