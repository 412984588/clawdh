---
name: performance-bottleneck
description: Identify performance bottlenecks in a code path or system
model: opus
effort: high
# Cost rationale: performance analysis requires reading full execution paths,
# understanding data flow, and reasoning about algorithmic complexity.
# opus+high is needed to catch non-obvious bottlenecks (N+1 queries, lock contention,
# GC pressure). sonnet+low produces surface-level findings that miss the real problems.
---

Identify performance bottlenecks in the code or system I'll describe.

Read the relevant code. Analyze:

1. **Algorithmic complexity** — O(n²) where O(n) is possible, etc.
2. **Database** — N+1 queries, missing indexes, full table scans, unnecessary joins
3. **I/O** — synchronous where async is possible, missing batching, chatty APIs
4. **Memory** — unnecessary object creation, large allocations in hot paths, leaks
5. **Concurrency** — blocking operations, lock contention, starvation

For each finding: location (file:line), estimated impact (High/Med/Low), fix recommendation.
Flag the highest-impact bottleneck first.
