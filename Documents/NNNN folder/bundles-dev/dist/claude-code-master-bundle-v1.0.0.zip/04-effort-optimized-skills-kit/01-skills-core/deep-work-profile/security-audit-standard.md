---
name: security-audit-standard
description: Standard security audit for a module or feature (non-critical)
model: opus
effort: high
# Cost rationale: security review is the wrong place to cut costs. Missing a
# vulnerability at review time means finding it in production. opus+high provides
# the analysis depth needed for a real audit. For critical/prod systems, use
# burst-profile/security-audit-critical (opus+max).
---

Perform a security audit on the code I've identified.

Check for:

**Input validation**
- SQL injection, XSS, SSRF, path traversal
- Missing bounds checking, integer overflow
- Unvalidated redirects

**Authentication & authorization**
- Missing auth checks on endpoints
- Privilege escalation paths
- Insecure direct object references (IDOR)

**Data handling**
- Sensitive data in logs or error messages
- Hardcoded secrets or credentials
- Insecure storage (plaintext passwords, etc.)

**Dependencies**
- Known vulnerable packages (check against your knowledge)

**Business logic**
- Race conditions, TOCTOU issues
- Missing rate limiting

Format: one finding per bullet, severity (Critical/High/Medium/Low), file:line, recommended fix.
