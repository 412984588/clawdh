---
name: architecture-review
description: Review a system architecture for scalability, maintainability, and failure modes
model: opus
effort: high
# Cost rationale: architecture decisions have compounding long-term consequences.
# opus+high for architecture review is the minimum viable depth — shortcuts here
# produce confident-sounding but shallow analysis that misses systemic risks.
---

Review this system architecture.

I'll describe the architecture or provide diagrams/docs.

Evaluate:
1. **Scalability** — where are the bottlenecks? What breaks first under load?
2. **Single points of failure** — what takes down the whole system if it fails?
3. **Data consistency** — where can data get out of sync? How is it resolved?
4. **Operational complexity** — how hard is this to deploy, monitor, and debug?
5. **Evolution** — how hard will it be to change requirement X in 6 months?

For each concern: describe the risk, likelihood, impact, and mitigation.
Prioritize — not everything is equally important.
