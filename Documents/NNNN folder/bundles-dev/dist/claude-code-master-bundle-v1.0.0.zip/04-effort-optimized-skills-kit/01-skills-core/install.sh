#!/bin/bash
# Effort-Optimized Skills Kit — Installer
# Copies all 25 skills into ~/.claude/skills/effort-kit/
# Usage: bash install.sh [--profile scout|workhorse|deep-work|burst|all]

SKILLS_DIR="${CLAUDE_SKILLS_DIR:-$HOME/.claude/skills}"
INSTALL_DIR="$SKILLS_DIR/effort-kit"
PROFILE="${1:-all}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p "$INSTALL_DIR"

install_profile() {
  local profile_name="$1"
  local profile_dir="$SCRIPT_DIR/$profile_name-profile"
  if [ ! -d "$profile_dir" ]; then
    echo "Profile not found: $profile_dir" >&2
    return 1
  fi
  local count=0
  for skill in "$profile_dir"/*.md; do
    [ -f "$skill" ] || continue
    cp "$skill" "$INSTALL_DIR/"
    count=$((count + 1))
  done
  echo "  $profile_name: $count skills installed"
}

echo "Installing Effort-Optimized Skills Kit → $INSTALL_DIR"

case "$PROFILE" in
  scout)       install_profile scout ;;
  workhorse)   install_profile workhorse ;;
  deep-work)   install_profile deep-work ;;
  burst)       install_profile burst ;;
  all|*)
    install_profile scout
    install_profile workhorse
    install_profile deep-work
    install_profile burst
    ;;
esac

# Copy reference docs
cp "$SCRIPT_DIR/PROFILES.md" "$INSTALL_DIR/"

TOTAL=$(ls "$INSTALL_DIR"/*.md 2>/dev/null | grep -v PROFILES | wc -l | tr -d ' ')
echo ""
echo "Done. $TOTAL skills installed."
echo "Access with: /<skill-name>"
echo "Reference:   $INSTALL_DIR/PROFILES.md"
