# Effort Profiles — Quick Reference

## The 5 Profiles

### Scout — `sonnet+low`
**When:** Fast lookups, mechanical tasks, high-frequency operations
**Cost:** Near-Haiku cost with better tool support
**Skills:** commit-message, pr-summary, quick-docstring, dependency-audit, file-organizer, test-name-generator, env-setup-check, changelog-entry

### Workhorse — `sonnet+high`
**When:** Development tasks requiring reasoning; quality matters, runs multiple times/day
**Cost:** ~3-5× Scout cost; worth it for tasks with correctness requirements
**Skills:** error-classifier, pr-review-quick, test-generator, code-explainer, refactor-planner, debug-triage

### Deep Work — `opus+high`
**When:** Architecture, security, API design — decisions with long-term consequences
**Cost:** ~8-12× Scout cost; justified for decisions you make once and live with
**Skills:** api-design-review, security-audit-standard, architecture-review, dependency-vulnerability, performance-bottleneck, database-schema-review

### Burst — `opus+max`
**When:** One-shot critical analysis; cost is secondary to completeness
**Cost:** No token budget cap — use sparingly, not for daily tasks
**Skills:** security-audit-critical, codebase-summary, incident-postmortem, tech-debt-assessment, hiring-rubric-generator

### Haiku-Replacement — `sonnet+low`
**When:** Haiku tool compatibility issues in hooks (common). Nearly Haiku-cost with better tool support.
**Note:** Not a separate profile — Scout skills work as Haiku-Replacement

---

## Effort Level × Model Matrix

| | `haiku` | `sonnet` | `opus` |
|---|---------|----------|--------|
| `low` | Cheapest possible | Near-Haiku cost | Rarely useful |
| `medium` | Default | Default | Default |
| `high` | Deeper but Haiku-limited | Daily workhorse | Architecture-grade |
| `max` | N/A | N/A | No cap, Opus 4.6 only |

---

## When to Use `max`

Use `max` when:
- Running a one-time audit (security, codebase, tech debt)
- The completeness of the output directly affects a major decision
- You'd rather pay more than miss something

Don't use `max` for:
- Daily-use skills (prohibitively expensive at scale)
- Tasks where "good enough" is genuinely good enough
- Anything in Scout or Workhorse profiles

---

## Env Var Override

`CLAUDE_CODE_EFFORT_LEVEL=low` always overrides frontmatter.
Useful for: cost-capping a session, testing at lower effort, running in CI.

```bash
# Force all skills to low effort for this session
CLAUDE_CODE_EFFORT_LEVEL=low claude

# Use frontmatter defaults (normal operation)
claude
```

---

## Adding Effort Frontmatter to Your Own Skills

```yaml
---
name: my-skill
description: What this skill does
model: sonnet          # haiku | sonnet | opus
effort: low            # low | medium | high | max
---

Your skill prompt here.
```

The `effort:` field is optional. Without it, the session default is used.
The `model:` field is optional and independent of `effort:`.
