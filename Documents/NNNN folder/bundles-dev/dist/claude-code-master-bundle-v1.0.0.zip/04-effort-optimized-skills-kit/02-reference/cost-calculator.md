# Cost Calculator — Estimate Your Monthly Savings

Fill in your actual usage numbers to see the impact of effort tuning.

## Step 1: Your Skill Usage

| Skill | Profile | Calls/Day | Default effort assumed |
|-------|---------|-----------|----------------------|
| commit-message | Scout | ? | sonnet+high (session default) |
| pr-summary | Scout | ? | sonnet+high |
| test-generator | Workhorse | ? | sonnet+high |
| security-audit | Deep Work | ? | sonnet+high |
| codebase-summary | Burst | ? | sonnet+high |

## Step 2: Approximate Cost Per Call

*Costs are approximate based on typical input/output lengths.*

| Profile | Model+Effort | Approx $/call |
|---------|-------------|---------------|
| Scout | sonnet+low | ~$0.003 |
| Workhorse | sonnet+high | ~$0.015 |
| Deep Work | opus+high | ~$0.08 |
| Burst | opus+max | ~$0.20-0.50 |
| Session default | sonnet+high | ~$0.015 |

## Step 3: Monthly Cost Comparison

**Example: developer writing 20 commits/day, 20 working days/month**

| Scenario | Calls | $/call | Monthly cost |
|----------|-------|--------|-------------|
| Before (session default sonnet+high) | 400 | $0.015 | **$6.00** |
| After (Scout sonnet+low) | 400 | $0.003 | **$1.20** |
| **Savings** | | | **$4.80/month** |

**Example: developer using security-audit 5×/month**

| Scenario | Calls | $/call | Monthly cost |
|----------|-------|--------|-------------|
| Before (sonnet+high) | 5 | $0.015 | $0.08 |
| After (opus+max — it's worth it) | 5 | $0.30 | **$1.50** |
| *Difference* | | | +$1.42 (worth it for prod security) |

## The Real Win

The savings from Scout-profile skills fund the Deep Work and Burst audits.
Proper effort tuning lets you run opus+max security audits without increasing your total bill.

## Your Numbers

```
Scout calls/month: _____ × $0.003 = $_____
Workhorse calls/month: _____ × $0.015 = $_____
Deep Work calls/month: _____ × $0.08 = $_____
Burst calls/month: _____ × $0.30 = $_____

Total optimized: $_____
vs. all at session default (×$0.015): $_____
Monthly savings: $_____
```
