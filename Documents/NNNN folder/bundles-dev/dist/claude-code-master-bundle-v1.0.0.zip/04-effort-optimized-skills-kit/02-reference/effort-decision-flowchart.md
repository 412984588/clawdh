# Effort Decision Flowchart

Use this to pick the right effort profile in 30 seconds.

```
Is this a one-time critical analysis?
(security audit, codebase review, incident postmortem, major decision)
│
├─ YES → Is it for production/critical systems?
│        │
│        ├─ YES → BURST (opus+max)
│        │        Skills: security-audit-critical, codebase-summary,
│        │                incident-postmortem, tech-debt-assessment
│        │
│        └─ NO → DEEP WORK (opus+high)
│                Skills: api-design-review, architecture-review,
│                        security-audit-standard, database-schema-review
│
└─ NO → Does this require code understanding + reasoning?
         (debugging, test writing, code review, planning)
         │
         ├─ YES → WORKHORSE (sonnet+high)
         │        Skills: test-generator, debug-triage, refactor-planner,
         │                code-explainer, pr-review-quick
         │
         └─ NO → Is this mechanical / high-frequency?
                  (commit messages, file ops, summaries, scaffolding)
                  │
                  └─ YES → SCOUT (sonnet+low)
                           Skills: commit-message, pr-summary, dependency-audit,
                                   changelog-entry, file-organizer
```

## Quick Reference

| Profile | Model | Effort | Cost Index | Use For |
|---------|-------|--------|------------|---------|
| Scout | sonnet | low | 1× | Mechanical, high-frequency |
| Workhorse | sonnet | high | 5× | Development reasoning |
| Deep Work | opus | high | 15× | Architecture, security |
| Burst | opus | max | 25× | One-shot critical analysis |

*Cost index is approximate relative to Scout. Actual costs depend on input/output length.*

## When max Makes Sense

Use `max` (no token budget cap) when:
- ✅ Thoroughness directly affects a consequential decision
- ✅ You're running this once, not daily
- ✅ The cost of missing something exceeds the cost of the model call

Don't use `max` when:
- ❌ You're running this more than once a week
- ❌ "Good enough" output is genuinely good enough
- ❌ The task is in Scout or Workhorse territory

## Env Override

`CLAUDE_CODE_EFFORT_LEVEL=low` forces all skills to low effort, overriding frontmatter.
Use to cap cost in CI or testing: `CLAUDE_CODE_EFFORT_LEVEL=low claude`
