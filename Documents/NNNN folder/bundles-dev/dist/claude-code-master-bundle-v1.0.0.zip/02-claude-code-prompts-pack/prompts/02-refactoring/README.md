# 02-refactoring

Prompts for simplifying code while preserving behavior and reducing risk.

## Included Prompts

- `01-reduce-nesting.md` — Reduce Deep Nesting
- `02-extract-domain-service.md` — Extract A Domain Service
- `03-split-large-file.md` — Split A Large File Safely
- `04-remove-dead-code.md` — Remove Dead Code Without Guessing
- `05-collapse-duplication.md` — Collapse Duplication
- `06-simplify-api-surface.md` — Simplify An API Surface
- `07-improve-naming.md` — Refactor For Better Naming
- `08-untangle-side-effects.md` — Untangle Side Effects
- `09-refactor-with-tests.md` — Refactor Behind Characterization Tests
- `10-introduce-value-object.md` — Introduce A Value Object
- `11-flatten-conditionals.md` — Flatten Conditionals
- `12-boundary-cleanup.md` — Clean Up Module Boundaries
- `13-config-consolidation.md` — Consolidate Scattered Config
- `14-error-model.md` — Refactor Error Handling Model
- `15-testability-refactor.md` — Refactor For Testability
- `16-safe-migration.md` — Plan A Safe Refactor Migration
