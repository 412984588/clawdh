# 04-architecture

Prompts for planning systems, boundaries, APIs, migrations, and technical direction.

## Included Prompts

- `01-system-boundaries.md` — Define System Boundaries
- `02-api-design.md` — Design An API Contract
- `03-migration-plan.md` — Plan A Data Migration
- `04-event-flow.md` — Model An Event Flow
- `05-monolith-module.md` — Split A Monolith Module
- `06-cache-strategy.md` — Choose A Cache Strategy
- `07-authz-model.md` — Design An Authorization Model
- `08-observability-plan.md` — Plan Observability
- `09-scaling-risk.md` — Assess Scaling Risk
- `10-dependency-map.md` — Map Critical Dependencies
- `11-service-extraction.md` — Evaluate Service Extraction
- `12-failure-isolation.md` — Design Failure Isolation
- `13-backfill-plan.md` — Plan A Historical Backfill
- `14-versioning-strategy.md` — Choose A Versioning Strategy
- `15-tech-debt-order.md` — Prioritize Technical Debt
- `16-adr-draft.md` — Draft An Architecture Decision
