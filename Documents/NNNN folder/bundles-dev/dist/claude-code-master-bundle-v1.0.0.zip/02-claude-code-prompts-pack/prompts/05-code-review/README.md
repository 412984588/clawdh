# 05-code-review

Prompts for reviewing diffs with a bug-finding and regression-prevention mindset.

## Included Prompts

- `01-bug-hunt-review.md` — Review For Bugs First
- `02-regression-review.md` — Review For Behavioral Regressions
- `03-performance-review.md` — Review For Performance Regressions
- `04-security-review.md` — Review For Security Risks
- `05-test-gap-review.md` — Review For Missing Tests
- `06-api-review.md` — Review An API Design
- `07-state-management-review.md` — Review State Management Changes
- `08-database-review.md` — Review Database Changes
- `09-error-handling-review.md` — Review Error Handling
- `10-maintainability-review.md` — Review For Maintainability
- `11-configuration-review.md` — Review Config And Runtime Assumptions
- `12-diff-summary.md` — Turn A Diff Into Findings
- `13-risk-ranking.md` — Rank Change Risk
- `14-refactor-review.md` — Review A Refactor
- `15-incident-prevention.md` — Review For Incident Prevention
- `16-approval-checklist.md` — Build An Approval Checklist
