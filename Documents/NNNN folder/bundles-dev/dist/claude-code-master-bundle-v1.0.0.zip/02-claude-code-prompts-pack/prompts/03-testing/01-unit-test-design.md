# Design Focused Unit Tests

## Use When

Use when a new function or bugfix needs small, behavior-driven tests.

Use this prompt when you want Claude Code to act like a senior engineer with a narrow task, explicit evidence requirements, and a concrete output shape instead of generic advice.

## Prompt

```text
You are working inside Claude Code on a 03 testing task.

Goal:
- Design Focused Unit Tests

Instructions:
1. Start by restating the problem in one sentence.
2. Identify the smallest set of files, logs, tests, or diffs required to reason correctly.
3. Build a short hypothesis list before proposing any change.
4. If this is a bug or regression, distinguish symptom, trigger, and likely root cause.
5. If this is a design or review task, rank issues by impact and reversibility.
6. Prefer evidence from the codebase, tests, and command output over intuition.
7. Call out assumptions explicitly when the evidence is incomplete.
8. Produce the minimum viable fix or recommendation, not a broad rewrite.
9. End with concrete next actions or validation commands.

Context to fill in before sending:
- Target files:
- Failing tests or observed behavior:
- Relevant logs or screenshots:
- Constraints or deadlines:

Output format:
- Problem summary
- Key findings
- Recommended action
- Validation or follow-up
```

## Why This Prompt Works

This prompt forces Claude Code to operate with scope control, evidence-first reasoning, and a concrete delivery shape. It avoids vague "analyze this" requests, reduces over-engineering, and makes the answer easier to compare across tasks. Buyers can reuse it as-is or adapt the placeholders to their team's language, repo structure, and release workflow.
