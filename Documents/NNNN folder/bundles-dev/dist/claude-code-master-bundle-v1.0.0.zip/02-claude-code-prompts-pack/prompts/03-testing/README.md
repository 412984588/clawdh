# 03-testing

Prompts for designing stronger test suites and closing verification gaps.

## Included Prompts

- `01-unit-test-design.md` — Design Focused Unit Tests
- `02-regression-test.md` — Write A Regression Test
- `03-edge-case-matrix.md` — Generate Edge Case Matrix
- `04-integration-test.md` — Design Integration Tests
- `05-api-contract-test.md` — Write API Contract Tests
- `06-state-machine-test.md` — Test A State Machine Flow
- `07-fixture-cleanup.md` — Fix Fragile Fixtures
- `08-property-test-ideas.md` — Generate Property-Based Test Ideas
- `09-coverage-gap.md` — Find Coverage Gaps
- `10-e2e-scenario.md` — Design E2E Scenarios
- `11-mock-boundary.md` — Choose The Right Mock Boundary
- `12-failure-mode-tests.md` — Test Failure Modes
- `13-database-test.md` — Test Database Behavior
- `14-concurrency-test.md` — Design Concurrency Tests
- `15-snapshot-alternative.md` — Replace Weak Snapshot Tests
- `16-release-gate.md` — Create A Release Gate Checklist
