# 01-debugging

Prompts for reproducing bugs, isolating regressions, and proving root cause.

## Included Prompts

- `01-reproduce-bug.md` — Reproduce The Bug Reliably
- `02-isolate-regression.md` — Isolate A Regression Window
- `03-stacktrace-triage.md` — Triage A Stacktrace
- `04-async-race-hunt.md` — Find An Async Race Condition
- `05-memory-leak.md` — Debug A Memory Leak
- `06-api-timeout.md` — Debug API Timeouts
- `07-db-query.md` — Investigate A Bad Database Query
- `08-build-break.md` — Debug A Broken Build
- `09-auth-loop.md` — Debug An Auth Redirect Loop
- `10-state-desync.md` — Trace A State Desynchronization
- `11-log-cluster.md` — Cluster Logs Into Root-Cause Signals
- `12-root-cause-proof.md` — Prove The Root Cause
- `13-failing-test.md` — Explain A Failing Test
- `14-data-corruption.md` — Investigate Data Corruption
- `15-deploy-incident.md` — Debug A Post-Deploy Incident
- `16-perf-bottleneck.md` — Find The Primary Performance Bottleneck
