# Changelog

## [1.0.0] - 2026-03-20

### Added
- Initial Claude Code Prompts Pack release
- 80 prompts across debugging, refactoring, testing, architecture, and code-review workflows
- Tiered packaging for Starter (20), Pro (50), and Complete (80)
- Local verification suite and ZIP bundle builder
