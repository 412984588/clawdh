# Claude Code Prompts Pack

80 production-ready prompts for Claude Code, organized by real software delivery scenarios.

## Categories

- `01-debugging` — reproduce bugs, isolate regressions, and identify root cause
- `02-refactoring` — simplify code safely without losing behavior
- `03-testing` — write stronger tests, close coverage gaps, and harden edge cases
- `04-architecture` — plan system boundaries, migrations, APIs, and technical decisions
- `05-code-review` — review diffs for bugs, regressions, performance issues, and missing tests

## Tiers

| Tier | Price | Prompts | Included |
|------|-------|---------|----------|
| Starter | $19 | 20 | 4 prompts from each category |
| Pro | $39 | 50 | 10 prompts from each category |
| Complete | $59 | 80 | All prompts across all 5 categories |

## How To Use

1. Pick the scenario that matches your current task.
2. Open the relevant markdown file under `prompts/`.
3. Paste the prompt into Claude Code and replace any bracketed placeholders.
4. Attach the target file paths, failing tests, logs, or diff context before sending.

## Verification

```bash
cd claude-code-prompts-dev
python3 generate_prompts.py
python3 -m pytest tests/test_bundle.py -q
python3 build_bundle.py
```

## Deliverables

- `dist/claude-code-prompts-starter-v1.0.0.zip`
- `dist/claude-code-prompts-pro-v1.0.0.zip`
- `dist/claude-code-prompts-complete-v1.0.0.zip`

## License

Released under the MIT License. See `LICENSE`.
