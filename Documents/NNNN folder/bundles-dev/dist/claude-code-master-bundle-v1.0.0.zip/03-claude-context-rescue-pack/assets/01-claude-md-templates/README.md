# 01-claude-md-templates

Templates for writing stronger CLAUDE.md files so sessions start with the right boundaries, repo context, and workflow rules.

## Included Assets

- `01-generic-repo-bootstrap.md` — Generic Repo Bootstrap CLAUDE.md
- `02-strict-scope-guard.md` — Strict Scope Guard Template
- `03-monorepo-map.md` — Monorepo Context Map Template
- `04-tdd-enforcer.md` — TDD Enforcer CLAUDE.md
- `05-review-first.md` — Review-First Template
- `06-release-mode.md` — Release Mode Template
- `07-context-summary.md` — Context Summary Header Template
- `08-architecture-rules.md` — Architecture Guardrails Template
- `09-api-service.md` — API Service Template
- `10-frontend-guardrails.md` — Frontend Guardrails Template
- `11-python-backend.md` — Python Backend Template
- `12-incident-response.md` — Incident Response CLAUDE.md
