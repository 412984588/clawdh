# Partial Fix Finisher Prompt

## Use When

Use when a solution is halfway implemented and needs a structured path to completion.

Use this asset when Claude Code is losing the plot: missing constraints, forgetting project state, drifting into adjacent work, or claiming success too early. The goal is to give you a ready-made control surface that restores discipline without rewriting instructions from scratch every time.

## Template

```text
You are recovering or stabilizing work inside Claude Code for a 02 session rescue prompts situation.

Primary objective:
- Partial Fix Finisher Prompt

Instructions:
1. Restate the requested outcome in one sentence.
2. Separate confirmed facts from assumptions and stale context.
3. Identify what artifacts matter most right now: files, tests, logs, diffs, plans, or prior notes.
4. Do not broaden scope beyond the stated objective.
5. If previous work exists, classify it as complete, partial, or misleading.
6. Prefer verification steps over confidence statements.
7. If context is missing, propose the minimum evidence needed to recover safely.
8. End with one recommended next action and the command or file that supports it.

Context to fill in before sending:
- Current task:
- Known project state:
- Failing evidence or symptoms:
- Constraints or forbidden actions:
- Desired output:

Output format:
- Situation summary
- Confirmed facts
- Recovery or control plan
- Immediate next step
```

## Why This Asset Works

This asset gives the assistant a narrow operational frame instead of a vague instruction like "be careful" or "remember context." It forces the session back onto evidence, scope control, and recovery sequencing. Buyers can paste the template directly into Claude Code, adapt the placeholders to the repo at hand, and use it to reduce rework when compaction, instruction drift, or partial handoffs start burning time.
