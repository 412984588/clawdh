# 02-session-rescue-prompts

Prompts for resetting a drifting session, rebuilding context after compaction, and forcing the assistant back onto the correct task.

## Included Assets

- `01-session-reboot.md` — Session Reboot Prompt
- `02-auto-compact-recovery.md` — Auto-Compact Recovery Prompt
- `03-handoff-reconstruction.md` — Handoff Reconstruction Prompt
- `04-root-cause-reset.md` — Root Cause Reset Prompt
- `05-stale-context-check.md` — Stale Context Check Prompt
- `06-refocus-scope.md` — Refocus Scope Prompt
- `07-error-loop-breaker.md` — Error Loop Breaker Prompt
- `08-partial-fix-finisher.md` — Partial Fix Finisher Prompt
- `09-verify-before-claim.md` — Verify Before Claim Prompt
- `10-read-the-diff.md` — Read The Diff First Prompt
- `11-regression-proof.md` — Regression Proof Prompt
- `12-closing-summary.md` — Closing Summary Prompt
