# 03-context-playbooks

Operational playbooks for logging progress, handing off work, validating fixes, and recovering from common agent failure modes.

## Included Assets

- `01-daily-progress-log.md` — Daily Progress Log Playbook
- `02-task-intake-checklist.md` — Task Intake Checklist
- `03-bug-investigation.md` — Bug Investigation Playbook
- `04-feature-scope.md` — Feature Scope Playbook
- `05-release-readiness.md` — Release Readiness Playbook
- `06-pr-review.md` — PR Review Playbook
- `07-outage-response.md` — Outage Response Playbook
- `08-dependency-upgrade.md` — Dependency Upgrade Playbook
- `09-test-gap.md` — Test Gap Playbook
- `10-rollback-plan.md` — Rollback Plan Playbook
- `11-decision-log.md` — Decision Log Template
- `12-handoff-playbook.md` — Handoff Playbook
