# Changelog

## v1.0.0 - 2026-03-20

- Initial release of Claude Context Rescue Pack
- Added 36 markdown assets across 3 context-control categories
- Added Starter, Pro, and Complete tier packaging
