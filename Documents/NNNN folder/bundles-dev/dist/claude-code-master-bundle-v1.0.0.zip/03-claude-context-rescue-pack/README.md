# Claude Context Rescue Pack

36 copy-ready assets for fixing instruction drift, restoring lost context, and giving Claude Code stronger project memory.

## Included Categories

- `01-claude-md-templates`
- `02-session-rescue-prompts`
- `03-context-playbooks`

## Tiers

| Tier | Price | Asset Count |
|------|-------|-------------|
| Starter | $19 | 12 |
| Pro | $39 | 24 |
| Complete | $59 | 36 |

## Verification

```bash
cd claude-context-rescue-pack-dev
python3 generate_assets.py
python3 -m pytest tests/test_bundle.py -q
python3 build_bundle.py
```

## Deliverables

- `dist/claude-context-rescue-starter-v1.0.0.zip`
- `dist/claude-context-rescue-pro-v1.0.0.zip`
- `dist/claude-context-rescue-complete-v1.0.0.zip`

## License

Released under the MIT License. See `LICENSE`.
