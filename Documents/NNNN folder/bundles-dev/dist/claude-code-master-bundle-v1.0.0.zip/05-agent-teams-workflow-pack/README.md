# Agent Teams Workflow Pack

Ready-to-use workflow templates, agent prompts, and scripts for Claude Code Agent Teams — the multi-agent feature that lets a Lead Agent coordinate parallel Teammate Agents on large codebases.

## Tiers

| Tier | Price | Contents |
|------|-------|----------|
| Starter | $29 | Setup + prompts + 5 workflow templates |
| Pro | $49 | + tmux launch scripts + task board + troubleshooting + case studies |

## What's Included

- `01-enable-setup` — One-command Agent Teams activation + settings.json
- `02-agent-prompts` — Lead Agent and Teammate role prompt templates
- `03-feature-dev-workflow` — 1 Lead + 3 Teammates feature development
- `04-bug-hunt-workflow` — Parallel bug isolation across multiple agents
- `05-code-review-workflow` — Reviewer agent coordination
- `06-migration-workflow` — Large-scale migration with file partitioning
- `07-research-spike-workflow` — Technical research with parallel information gathering
- `08-tmux-scripts` — tmux multi-pane launcher, shared task board, token cost monitor
- `09-troubleshooting` — /resume fix, conflict resolution SOP, real-world case studies

## Requirements

- Claude Code v2.1.32+
- Environment variable: `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1`
- tmux (optional, for scripts in Pro tier)

## License

MIT — unlimited commercial use.
