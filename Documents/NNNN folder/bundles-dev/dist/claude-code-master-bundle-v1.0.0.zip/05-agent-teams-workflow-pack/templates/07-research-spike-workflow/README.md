# 07 — Research Spike Workflow

Parallel technical research: multiple Teammates investigate different options or dimensions simultaneously, Lead Agent synthesizes into a decision.

## Files

| File | Contents |
|------|----------|
| `research-spike.md` | Full workflow: research plan, Researcher Teammate prompt, Lead synthesis, ORM selection example |

## When to Use

- Technical decision with multiple competing options
- Problem with multiple independent information dimensions
- Producing an ADR (Architecture Decision Record)

## Output

Produces a structured ADR or comparison document ready to commit to the repo.
