# Research Spike Workflow — Parallel Information Gathering

**Use for:** Technical decision research where multiple options need evaluation, or a single problem has multiple information dimensions.

**Time savings vs. single agent:** 50-70% on research tasks that span multiple domains.

---

## When to Use

✅ Good fit:
- "Should we use Prisma, Drizzle, or Kysely for our ORM?"
- "How does our auth, caching, and API all need to change for this new requirement?"
- "What are the security implications, performance implications, and migration path for upgrading to X?"

❌ Bad fit:
- Single, well-defined question → single agent
- Research that requires one answer to inform the next question (sequential by nature)

---

## Phase 1: Research Plan (Lead Agent)

```
Research question: [The decision or problem]
Deadline: [When this decision needs to be made]

Research streams (assign to Teammates):
  Stream A: [Topic + what to find out]
    Key questions: [3-5 specific questions to answer]
    Sources: [docs, GitHub issues, community posts, benchmarks]

  Stream B: [Topic + what to find out]
    Key questions: [3-5 specific questions to answer]

  Stream C: [Topic + what to find out]
    Key questions: [3-5 specific questions to answer]

Integration goal: [What Lead Agent will produce from the findings — ADR? Comparison table? Recommendation?]
```

---

## Phase 2: Researcher Teammate Prompt

```
You are Research Teammate [A/B/C] investigating: [Stream topic]

Your questions to answer:
1. [Question]
2. [Question]
3. [Question]

Research approach:
- Read relevant documentation and source code
- Look for GitHub issues, community discussions, known limitations
- Note what you find AND what you couldn't find (gaps are important)

Output format:
## Research Findings — [Stream topic]

### Answers
1. [Question]: [Answer with evidence]
2. [Question]: [Answer with evidence]

### Key Tradeoffs
- [Pro/con list]

### Limitations / Unknown
- [What you couldn't determine]

### Recommendation (your opinion)
[One sentence]
```

---

## Phase 3: Lead Agent Synthesis

After all Researchers report, Lead Agent produces the final output:

```markdown
# ADR-XXX: [Decision Title]

## Context
[Problem that requires this decision]

## Options Considered

### Option A — [Name]
**From Research Stream A findings:**
- Pros: ...
- Cons: ...
- Unknown: ...

### Option B — [Name]
...

## Decision
[Chosen option + rationale]

## Consequences
[What this means for the codebase, team, and future decisions]
```

---

## Example: ORM Selection for New Service

```
Research question: Which ORM for our new microservice?

Stream A: Prisma evaluation
  - Query API ergonomics for our use cases (complex joins, bulk operations)
  - Migration tooling maturity
  - TypeScript type inference quality

Stream B: Drizzle evaluation
  - Bundle size and runtime performance vs Prisma
  - SQL-like API vs Prisma's abstraction — fits our team's SQL comfort level?
  - Ecosystem maturity (issues, release frequency)

Stream C: Raw pg + custom types
  - Performance ceiling vs ORMs
  - Type safety options (pg-typed, postgres.js)
  - What we'd lose vs. what we'd gain

Integration goal: ADR with recommendation and migration plan
```
