# Migration Workflow — File Partitioning for Parallel Execution

**Use for:** Large-scale codebase changes where the same transformation applies to many files (rename, refactor pattern, API migration, dependency upgrade).

**Time savings vs. single agent:** 60-80% — this is where Agent Teams delivers the most value.

---

## The Core Problem

Single agent migrating 200 files: runs out of context window at ~50 files, loses track of progress, produces inconsistent output.

Agent Teams solution: partition files across Teammates, each owns a non-overlapping set. No merge conflicts by design.

---

## Phase 1: Partition Planning (Lead Agent)

```
Migration: [What change is being applied — be exact]
Total scope: [N files, estimated N hours single-agent]

Partition strategy:
  Option A: By directory (apps/web → Teammate A, apps/api → Teammate B)
  Option B: By file pattern (*.service.ts → A, *.controller.ts → B)
  Option C: By feature area (auth/ → A, users/ → B, payments/ → C)

Chosen strategy: [Option X because...]

Teammate A:
  Files: [list or glob pattern — EXACT, no ambiguity]
  Count: ~N files

Teammate B:
  Files: [list or glob pattern]
  Count: ~N files

Teammate C:
  Files: [list or glob pattern]
  Count: ~N files

Shared files (Lead Agent handles AFTER all Teammates done):
  - tsconfig.json (if paths change)
  - package.json (if deps change)
  - index.ts barrel files (if exports change)
```

---

## Phase 2: Define the Transformation (Lead Agent)

Write an exact transformation spec — all Teammates must apply the SAME change:

```
Transformation:
  Before: import { foo } from '../utils/foo'
  After:  import { foo } from '@repo/utils'

  Before: const result = await db.query(sql`...`)
  After:  const result = await prisma.query(...)

Rules:
  - Replace ALL occurrences in assigned files
  - Do NOT change logic — transformation only
  - If a file has a pattern that doesn't fit, STOP and report to Lead
  - Run `pnpm typecheck` on your files before reporting done
```

---

## Phase 3: Parallel Execution (Teammates)

Each Teammate works independently on their file partition. Lead Agent monitors for:
- Files that don't fit the pattern (report, don't guess)
- Type errors that surface after transformation
- Teammate reaching the edge of their partition

---

## Phase 4: Integration (Lead Agent)

```bash
# After all Teammates done
git diff --stat          # Verify scope matches expectation
pnpm typecheck           # Check for type errors
pnpm test                # Full regression run

# Handle shared files
# tsconfig.json, package.json, barrel exports
# Do these yourself — these files are cross-cutting
```

---

## Example: Zod v3 → v4 Migration

```
Migration: Zod v3 → v4 API changes
Scope: 47 schema files across the codebase

Changes required:
  - .optional() → .optional() (no change)
  - .nullable() → .nullable() (no change)
  - z.string().nonempty() → z.string().min(1)  ← CHANGED
  - z.object().strip() → z.object() (strip is default now) ← CHANGED
  - z.infer<typeof schema> → z.infer<typeof schema> (no change)

Partition:
  Teammate A: src/schemas/auth/*.ts (12 files)
  Teammate B: src/schemas/users/*.ts, src/schemas/billing/*.ts (18 files)
  Teammate C: src/schemas/shared/*.ts, src/schemas/api/*.ts (17 files)

Shared (Lead does last): src/schemas/index.ts
```

---

## Progress Tracking

Update `.claude/tasks.jsonl` as Teammates complete files:
```json
{"agent":"teammate-a","status":"in_progress","files_done":8,"files_total":12,"last_file":"src/schemas/auth/login.ts"}
{"agent":"teammate-a","status":"done","files_done":12,"files_total":12,"errors":0}
```
