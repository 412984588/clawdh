# 06 — Migration Workflow

Large-scale codebase migrations using file partitioning to run Teammates in parallel without merge conflicts.

## Files

| File | Contents |
|------|----------|
| `migration.md` | Full workflow: partition planning, transformation spec, parallel execution, integration, Zod migration example |

## When to Use

- Same transformation applied to 20+ files
- Context window would overflow with single agent
- API migrations, dependency upgrades, rename refactors, pattern standardization

## Key Insight

File partitioning is the key. Each Teammate owns non-overlapping files. Lead Agent handles cross-cutting files (tsconfig, package.json, barrel exports) after all Teammates are done.
