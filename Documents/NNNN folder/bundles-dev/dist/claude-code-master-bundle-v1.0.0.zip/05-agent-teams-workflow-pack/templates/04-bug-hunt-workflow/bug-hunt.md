# Bug Hunt Workflow — Parallel Isolation

**Use for:** Bugs where the root cause is unclear and multiple hypotheses need testing simultaneously.

**Time savings vs. single agent:** 50-70% when bug could be in 3+ separate modules.

---

## When to Use This Workflow

✅ Good fit:
- "Users sometimes get logged out — could be session, JWT, or cookie handling"
- "Occasionally getting 500 errors — could be DB, API layer, or validation"
- "Performance regression — could be N+1 query, missing index, or frontend re-renders"

❌ Bad fit:
- Bug with a clear stacktrace pointing to one file → single agent, no overhead needed
- Intermittent bugs that require production logs → gather logs first

---

## Phase 1: Hypothesis Definition (Lead Agent)

Before spawning Teammates, Lead Agent writes a hypothesis for each:

```
Bug: [Description + error message / symptom]
Reproduction: [Steps to reproduce or frequency]

Hypotheses:
  H1: [Module A] — [why it might be here, evidence]
  H2: [Module B] — [why it might be here, evidence]
  H3: [Module C] — [why it might be here, evidence]

Teammate assignments:
  Teammate A → Investigate H1
  Teammate B → Investigate H2
  Teammate C → Investigate H3
```

Each Teammate gets **read-only access first** (no fixes yet).

---

## Phase 2: Parallel Investigation (Teammates A + B + C)

Each Teammate's task:

```
Investigate [Hypothesis N]:
1. Read the relevant code thoroughly
2. Add diagnostic logging (to local dev only — not production code)
3. Attempt to reproduce the bug in this code path
4. Report: CONFIRMED / RULED OUT / INCONCLUSIVE + evidence

Do NOT fix anything yet. Report findings to Lead Agent.
```

---

## Phase 3: Lead Agent Assessment

After all Teammates report:

```
If ONE hypothesis confirmed:
  → Assign the confirming Teammate to fix it
  → Other Teammates stop (save tokens)

If MULTIPLE confirmed:
  → Investigate interaction between them (might be two bugs)
  → Fix sequentially, not in parallel (one fix might invalidate the other)

If ALL inconclusive:
  → Widen search: gather production logs, check recent git history
  → Re-run with refined hypotheses
```

---

## Phase 4: Fix + Regression Test (single Teammate)

Once root cause is confirmed, assign ONE Teammate to:

1. Fix the bug
2. Write a regression test that fails without the fix, passes with it
3. Verify no related tests break

Lead Agent runs `pnpm test` and reviews the fix before marking done.

---

## Example: Intermittent 401 Errors

```
Bug: ~5% of authenticated API requests return 401 despite valid session

Hypotheses:
  H1: JWT token expiry check has a race condition (auth middleware)
  H2: Redis session store occasionally loses sessions (session service)
  H3: Cookie SameSite settings cause token not to be sent (frontend)

Teammate A → src/middleware/auth.ts, src/lib/jwt.ts
Teammate B → src/lib/session.ts, src/lib/redis.ts
Teammate C → src/app/api/[...route]/route.ts, frontend cookie config

Evidence to look for:
- Timing-dependent code (Date.now() comparisons without buffer)
- Missing try/catch on Redis calls
- Cookie attributes in development vs. production config
```
