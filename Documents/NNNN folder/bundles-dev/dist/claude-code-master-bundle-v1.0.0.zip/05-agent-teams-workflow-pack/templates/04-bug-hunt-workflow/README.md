# 04 — Bug Hunt Workflow

Parallel bug isolation: multiple Teammates investigate different hypotheses simultaneously, then Lead Agent merges findings.

## Files

| File | Contents |
|------|----------|
| `bug-hunt.md` | Full workflow: hypothesis definition, parallel investigation, assessment, fix + regression test |

## When to Use

- Bug with unclear root cause across multiple modules
- Multiple equally plausible hypotheses
- Intermittent bugs where you need to rule out possibilities

## Key Principle

Teammates investigate (read-only) first — no fixes until root cause is confirmed. This prevents spending tokens fixing the wrong thing.
