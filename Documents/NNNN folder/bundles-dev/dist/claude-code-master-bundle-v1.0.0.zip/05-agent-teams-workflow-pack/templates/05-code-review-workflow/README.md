# 05 — Code Review Workflow

Parallel specialist review: Security, Correctness, and Performance Reviewers run simultaneously, Lead Agent consolidates findings.

## Files

| File | Contents |
|------|----------|
| `code-review.md` | Full workflow: setup, Reviewer Teammate prompt, Lead Agent consolidation, GitHub integration |

## When to Use

- PR with >300 lines changed across multiple domains
- Security-sensitive changes (auth, payments, data access)
- Performance-critical paths (hot paths, database queries, rendering)

## Output

Produces a structured `CRITICAL / HIGH / MEDIUM / LOW` consolidated report ready to post as a PR comment.
