# Code Review Workflow — Reviewer Agent Coordination

**Use for:** PR reviews where you want parallel specialist review: security, performance, correctness.

**Time savings vs. single agent:** 30-40% on large PRs (>300 lines changed).

---

## Setup

Lead Agent reads the PR diff and assigns each Reviewer Teammate a domain:

```
PR: [Title and description]
Files changed: [list from git diff --stat]

Reviewer A — Security
  Focus: auth checks, input validation, secret handling, OWASP patterns
  Files: [subset of changed files most relevant to security]

Reviewer B — Correctness
  Focus: logic errors, edge cases, type safety, test coverage
  Files: [all changed files]

Reviewer C — Performance
  Focus: N+1 queries, missing indexes, unnecessary re-renders, bundle size
  Files: [subset relevant to performance]
```

---

## Reviewer Teammate Prompt

```
You are a [Domain] Reviewer Teammate.

Review the following files for [Domain] issues only:
[paste file list]

For each issue found, use this format:
[SEVERITY] path/to/file.ts:line — Issue description
Why: [explanation of the risk or problem]
Fix: [specific suggestion]

Severity: CRITICAL (blocks merge) | HIGH (should fix) | MEDIUM (consider) | LOW (nit)

End your review with:
REVIEW DONE — [Domain]
Issues found: X critical, Y high, Z medium, W low
```

---

## Phase 2: Lead Agent Integration

Collect all three Reviewer reports and consolidate:

```markdown
## Consolidated Review Report

### CRITICAL (must fix before merge)
- [from Security Reviewer] path/to/file:line — Missing auth check on admin endpoint
- [from Correctness Reviewer] path/to/file:line — Null dereference when user not found

### HIGH (should fix)
- ...

### MEDIUM + LOW
- ...

### Approved by reviewers
- Security: ✅ No critical security issues in [files]
- Performance: ✅ No N+1 queries detected
```

Post the consolidated report as a PR comment or save to `.claude/review-output.md`.

---

## When NOT to Use Multi-Agent Review

- Small PRs (<50 lines): overhead exceeds benefit, single agent review is faster
- Trivial changes (docs, config, deps): single agent
- When you need a conversational review: multi-agent review is one-shot, not interactive

---

## Integration with GitHub

```bash
# Post review output as PR comment
gh pr comment [PR_NUMBER] --body "$(cat .claude/review-output.md)"
```
