# 03 — Feature Dev Workflow

1 Lead + 3 Teammates workflow for building features across frontend, backend, and tests simultaneously.

## Files

| File | Contents |
|------|----------|
| `feature-dev.md` | Full workflow: pre-flight, Phase 1-4, example, common blockers |

## When to Use

- Feature spans >3 files across frontend and backend
- Writing tests alongside implementation (not after)
- Expected implementation >200 lines total

## Key Principle

Define shared interfaces BEFORE spawning Teammates. The 10-minute pre-flight prevents 2 hours of merge conflict resolution.
