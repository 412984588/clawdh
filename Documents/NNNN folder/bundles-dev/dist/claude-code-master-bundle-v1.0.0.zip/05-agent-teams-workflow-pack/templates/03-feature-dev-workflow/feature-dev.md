# Feature Development Workflow — 1 Lead + 3 Teammates

**Use for:** Building a new feature that touches frontend, backend, and tests simultaneously.

**Time savings vs. single agent:** 40-60% on features >200 lines across >5 files.

---

## Pre-Flight (Lead Agent, ~10 min)

Before spawning any Teammates, Lead Agent must complete:

```
1. Read all files the feature will touch
2. Define the shared interface:
   - TypeScript types / API response shapes
   - New environment variables
   - Database schema changes (if any)
3. Assign file ownership — no overlaps

Post to .claude/tasks.jsonl:
  { "phase": "setup", "status": "done", "shared_interface": "[summary]" }
```

**If you skip pre-flight, you WILL get merge conflicts. Do not skip.**

---

## Phase 1: Spawn Teammates (Lead Agent)

After pre-flight, start all three Teammates simultaneously:

```
Teammate A (Frontend):
  Scope: src/components/[feature]/, src/app/[route]/
  Goal: [exact UI requirement]
  Interface: [paste shared types]

Teammate B (Backend):
  Scope: src/server/routers/[feature].ts, src/lib/[feature].ts
  Goal: [exact API requirement]
  Interface: [paste request/response types]

Teammate C (Tests):
  Scope: tests/[feature]/, src/[feature].test.ts
  Goal: unit tests for backend module; integration tests after A+B done
  Wait for: Teammate B's unit-testable functions (can start unit tests now)
```

---

## Phase 2: Parallel Work (Teammates A + B simultaneously)

Lead Agent monitors `.claude/tasks.jsonl`. When a Teammate posts a blocker:
- Assess: is this a design gap (Lead decides) or a dependency (route to other Teammate)?
- Resolve within 5 minutes or the blocked Teammate pauses

Typical blockers:
- "I need the `UserProfile` type" → Lead provides it from the shared interface definition
- "The API endpoint shape changed" → Lead updates the interface doc, notifies all Teammates
- "I found a bug in existing code" → Lead decides: fix now or file for later?

---

## Phase 3: Tests (Teammate C, after A+B done)

Teammate C resumes with full implementation context:

```
Teammate B is done. Here are the function signatures: [paste]
Teammate A is done. Here are the component props: [paste]
Now write integration tests for the complete feature.
```

---

## Phase 4: Lead Agent Integration

When all Teammates report done:

```bash
# 1. Review all changes
git diff --stat

# 2. Check for type errors across the whole project
pnpm typecheck

# 3. Run full test suite
pnpm test

# 4. Fix integration issues yourself (do not re-delegate)
# Common: import path mismatches, prop type mismatches between components
```

---

## Example: Add User Profile Page

```
Feature: User profile page with edit functionality

Pre-flight decisions:
  UserProfile type: { id, name, email, avatarUrl, bio }
  API: GET /api/users/:id, PATCH /api/users/:id

Teammate A (Frontend):
  Files: src/app/profile/[id]/page.tsx, src/components/ProfileCard.tsx
  Goal: Profile page with edit modal, optimistic updates
  Type contract: UserProfile (defined above)

Teammate B (Backend):
  Files: src/server/routers/users.ts, src/lib/users.ts
  Goal: GET and PATCH endpoints with auth check (only own profile editable)
  Returns: UserProfile shape

Teammate C (Tests):
  Files: tests/users.test.ts, tests/profile.e2e.ts
  Goal: Unit tests for backend; E2E test for edit flow
```
