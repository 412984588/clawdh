# Case Study: 10,000-Line Codebase Refactor with Agent Teams

**Task:** Migrate a 10,000-line Express API to a typed tRPC + Zod architecture
**Single agent estimate:** 16-24 hours (context window overflow, progress tracking issues)
**Agent Teams actual:** 4.5 hours with 3 Teammates
**Cost:** ~$9 (vs. ~$18 estimated single agent)

---

## Setup

**Codebase:** Node.js Express API, 10,200 lines, 87 route handlers, no TypeScript
- 23 route files → typed tRPC routers
- 87 handler functions → typed procedures with Zod input validation
- 31 middleware functions → converted or replaced

**Team composition:**
- Lead Agent: planning, pre-flight, integration, testing
- Teammate A (Routes): src/routes/auth/*, src/routes/users/* (28 handlers)
- Teammate B (Routes): src/routes/billing/*, src/routes/admin/* (31 handlers)
- Teammate C (Routes): src/routes/api/*, src/routes/webhooks/* (28 handlers)

---

## Pre-Flight (Lead Agent, 45 min)

This was the most important phase. Lead Agent:

1. Read all 23 route files to understand patterns
2. Defined the tRPC router structure before Teammates started
3. Created `src/trpc/shared-types.ts` with all shared input/output types
4. Created `src/trpc/router-template.ts` as the pattern Teammates would follow
5. Defined file ownership explicitly — no overlaps

Key decision: Lead Agent wrote the "golden example" for one route handler before delegating. Teammates copied this pattern, not the old Express pattern.

---

## Execution (3 Teammates in parallel, ~2.5 hours)

Each Teammate received:
- Their specific route files (exact list, no ambiguity)
- The golden example to follow
- The shared types file (read-only — report if you need a new type)
- Instruction: run `tsc --noEmit` on your files before reporting done

**Teammate performance:**
- Teammate A: 28 handlers, reported done in 2h10m, 0 type errors
- Teammate B: 31 handlers, reported done in 2h35m, 3 type errors caught by tsc, self-fixed
- Teammate C: 28 handlers, reported done in 2h05m, 1 blocker (needed a new shared type) → reported to Lead → resolved in 5 min

**Blocker example:**
```
Teammate C: "I need a WebhookPayload type for the Stripe webhook handler.
It's not in shared-types.ts and I shouldn't add it since it's shared.
Blocking on this."

Lead Agent: Added WebhookPayload to shared-types.ts, notified Teammate C.
Teammate C: Resumed, done in 15 more minutes.
```

---

## Integration (Lead Agent, ~1 hour)

After all three Teammates reported done:

1. `tsc --noEmit` → 7 type errors across integration points
   - 5 were prop name mismatches between tRPC routers (different names for same concept)
   - 2 were missing exports in barrel files
   - Lead Agent fixed all 7 manually (did not re-delegate)

2. Full test suite: 143 tests, 12 failing (all in integration tests expecting old Express API format)
   - Updated test assertions to match new tRPC response format
   - 143/143 passing

3. Manual smoke test of 5 critical paths

---

## What Went Well

- File partitioning prevented all merge conflicts (0 conflicts across 3 Teammates)
- Golden example pattern produced consistent output
- Teammate C's blocker was handled in <5 min (clear escalation path)
- tRPC's type inference meant many bugs were caught at compile time, not runtime

## What Would Have Failed With Single Agent

- Single agent context window: ~50K tokens for a 10K-line codebase
- Would have lost context of early files by the time it reached file 50
- Inconsistent patterns across route files (common single-agent failure mode)
- Estimated context resets: 3-4, each requiring re-reading context = 2-4 extra hours

## Lessons

1. **Invest in pre-flight**: 45 min of pre-flight saved 3 hours of conflicts
2. **Golden example is essential**: Abstract instructions produce varied output; concrete example produces uniform output
3. **Narrow file scope per Teammate**: Each Teammate had ~28 files (~300 lines each) — comfortable within context window
4. **Lead Agent integration is real work**: Budget 20-25% of total time for integration
