# Troubleshooting: /resume Does Not Restore Teammates

## The Problem

Running `/resume` or `/rewind` in an Agent Teams session restores the **Lead Agent's** conversation context but does NOT restore in-progress Teammates. Teammates that were actively working when the session ended cannot be resumed — they are gone.

This is a known limitation of Agent Teams v2.1.x.

---

## Symptoms

- You run `/resume` and the Lead Agent context is back
- But Teammate A, B, C are not continuing their work
- Lead Agent may say it doesn't know what Teammates were doing

---

## Prevention (Best Practice)

**Write Teammate progress to disk before the session could end:**

Add to Lead Agent prompt:
```
At the end of each phase (every ~30 minutes), ask each Teammate to write a progress snapshot:
"Teammate A: write your current progress to .claude/teammate-a-snapshot.md"
```

Snapshot format:
```markdown
# Teammate A Progress Snapshot — 2026-03-21 14:30

## Task assigned
[original task description]

## Files completed
- src/auth/login.ts ✅
- src/auth/refresh.ts ✅

## Files in progress
- src/auth/logout.ts — 60% done, need to add token revocation

## Files remaining
- src/auth/middleware.ts
- tests/auth.test.ts

## Current context
[anything Lead Agent needs to know to re-brief a new Teammate]

## Blockers
[any open questions or blockers]
```

---

## Recovery After Session Loss

If a session ended without snapshots:

### Step 1: Reconstruct progress from git

```bash
git diff HEAD          # See what was changed before the crash
git diff --stat HEAD   # Which files were touched
git log --oneline -5   # Were there any commits?
```

### Step 2: Reconstruct from tasks.jsonl

```bash
cat .claude/tasks.jsonl
```

If Teammates logged status updates, you can see what was in progress.

### Step 3: Re-brief Teammates manually

```
Lead Agent, here is the situation:
- We were working on: [task]
- Teammate A had completed: [files from git diff]
- Teammate A was in progress on: [file that's partially changed]
- Please review the partial changes and continue from where they left off.
```

### Step 4: Run a "continuation Teammate"

```
Start a new Teammate with this context:
[paste snapshot or git diff]
Continue from where this work left off.
Start by reading the partially-changed files to understand the current state.
```

---

## Feature Request

Track this issue: Check Claude Code GitHub or changelog for `/resume` Teammate restoration support. This limitation is on the Agent Teams roadmap.
