# 09 — Troubleshooting

Known issues, workarounds, and real-world case studies for Agent Teams.

## Files

| File | Contents |
|------|----------|
| `resume-fix.md` | `/resume` does not restore Teammates — prevention via snapshots, recovery via git diff + re-briefing |
| `conflict-resolution.md` | Parallel file conflict prevention SOP, detection, and recovery steps |
| `case-study-10k-refactor.md` | Real-world: 10,000-line Express → tRPC migration — 4.5 hours with 3 Teammates vs. 16-24 hours single agent |

## Most Important Issues

1. **`/resume` loses Teammates** — Always have Teammates write progress snapshots to disk every 30 minutes
2. **Parallel file conflicts** — Assign file ownership BEFORE spawning Teammates, no exceptions
3. **Context overflow per Teammate** — Give each Teammate 20-30 files max, not the whole codebase

## Common Question: "Is Agent Teams worth it?"

From the case study: 4.5 hours vs. 16-24 hours for a 10K-line refactor. The overhead (pre-flight + integration) is real but predictable. For tasks >200 lines across >5 files, Agent Teams typically saves 40-70% of single-agent time.

For tasks <200 lines: single agent is faster (no coordination overhead).
