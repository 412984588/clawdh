# Troubleshooting: Parallel File Conflicts

## The Problem

Two Teammates edit the same file simultaneously. When Lead Agent tries to review, the file has conflicting changes. Or worse: one Teammate's write silently overwrites the other's.

This is the #1 failure mode for Agent Teams. It is **entirely preventable** with proper file ownership.

---

## Prevention (Non-Negotiable)

Follow the file ownership protocol from `02-agent-prompts/team-lead-prompt.md`:
- Each file has exactly ONE Teammate owner
- Shared files (tsconfig, package.json, barrel exports) are Lead Agent's responsibility
- Teammates stop and report if they need to touch a file outside their scope

If you skip file ownership assignment, you WILL get conflicts. The time to fix them exceeds the time saved by parallelism.

---

## Detecting a Conflict

```bash
# Check for conflict markers
grep -r "<<<<<<< " --include="*.ts" --include="*.tsx" .

# Check git status for conflicted files
git status | grep "both modified"

# See what actually changed
git diff
```

---

## Recovery: Merge Conflicts in Source Files

### Step 1: Stop all Teammates

Do not let any Teammate continue editing until the conflict is resolved. Tell them: "Stop all work — resolving merge conflict."

### Step 2: Assess which change to keep

```bash
# See both versions
git show HEAD:path/to/conflicted/file.ts  # original
cat path/to/conflicted/file.ts            # current (with markers)
```

Usually one of:
- **Teammate A's version is right, B's is wrong** → keep A, discard B, have B redo their change on top
- **Both are right, need to combine** → Lead Agent manually merges (don't delegate)
- **Both made the same change** → keep either, discard duplicate

### Step 3: Resolve manually

```bash
# Accept one version entirely
git checkout --theirs path/to/file.ts  # keep Teammate B's version
git checkout --ours path/to/file.ts    # keep Teammate A's version

# Or edit manually to combine
```

### Step 4: Verify

```bash
pnpm typecheck  # No type errors from the merge
pnpm test       # Tests still pass
```

### Step 5: Post-mortem

```
Root cause: [Which two Teammates touched the same file]
Why: [Was file ownership unclear? Or did a Teammate expand scope?]
Fix: [Add explicit file ownership to this workflow template]
```

---

## Recovery: Silent Overwrites (Worse)

If Teammate B wrote a file that Teammate A had already written, without conflict markers:

```bash
git log --all --oneline -- path/to/file.ts  # See write history
git show HEAD@{1}:path/to/file.ts           # Previous version
```

Restore what was lost manually or ask Claude to diff and re-apply missing changes.

---

## SOP: File Ownership Assignment

Add this to every workflow pre-flight:

```
BEFORE spawning Teammates, Lead Agent runs:
  find src/ -name "*.ts" | head -50   (list candidate files)
  Assign each file to exactly ONE Teammate.
  List files with no assigned Teammate → Lead Agent handles.
  Post the assignment to .claude/file-ownership.md
```

```markdown
# .claude/file-ownership.md
## Session: feat-auth — 2026-03-21

| File | Owner |
|------|-------|
| src/auth/login.ts | teammate-a |
| src/auth/middleware.ts | teammate-a |
| src/api/users.ts | teammate-b |
| tsconfig.json | lead-agent |
| package.json | lead-agent |
```
