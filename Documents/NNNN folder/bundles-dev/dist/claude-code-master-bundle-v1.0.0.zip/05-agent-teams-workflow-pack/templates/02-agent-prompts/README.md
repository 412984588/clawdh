# 02 — Agent Prompts

Lead Agent and Teammate role prompt templates for structuring multi-agent sessions.

## Files

| File | Contents |
|------|----------|
| `team-lead-prompt.md` | Lead Agent system prompt: decomposition rules, file ownership protocol, task board management, integration checklist |
| `teammate-prompt.md` | Four role templates: Frontend / Backend / Test / Docs Teammate |

## Usage

**Lead Agent prompt:** Add to your CLAUDE.md or paste at session start:
```
"Act as Lead Agent using the protocol in 02-agent-prompts/team-lead-prompt.md.
Task: [your task description]"
```

**Teammate prompts:** When starting each Teammate, paste the relevant role template with the specific file scope filled in.

## Why These Prompts Matter

Without explicit role prompts, Teammate Agents overlap, edit each other's files, and create merge conflicts. These templates enforce file ownership and structured reporting so the Lead Agent can integrate results cleanly.
