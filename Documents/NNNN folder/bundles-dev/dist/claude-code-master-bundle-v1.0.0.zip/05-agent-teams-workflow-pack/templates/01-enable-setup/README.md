# 01 — Enable Setup

One-command Agent Teams activation with settings.json and enable guide.

## Files

| File | Contents |
|------|----------|
| `settings.json` | Claude Code settings with `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1` in env block |
| `enable-guide.md` | Three activation options (per-project / global / per-session) + verification steps + current limitations |

## Quick Start

```bash
mkdir -p .claude && cp settings.json .claude/settings.json
```

Open Claude Code and type `/agents` to verify Agent Teams is active.

## What the settings.json Does

- Sets the `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1` env var automatically on project open
- Configures sensible default permissions (blocks `rm -rf`, `sudo`, force-push)
- Sets task board path to `.claude/tasks.jsonl` for use with the Pro tier scripts
