# Enabling Agent Teams

## Requirements

- Claude Code **v2.1.32 or later** — check with `claude --version`
- Environment variable `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1`

---

## Option A: Per-Project (recommended)

Copy `settings.json` from this template to `.claude/settings.json` in your project root.
The `env` block sets the feature flag automatically when Claude opens that project.

```bash
mkdir -p .claude
cp settings.json .claude/settings.json
```

Verify it's working:
```
/agents
```
If Agent Teams is enabled, you'll see the agents panel.

---

## Option B: Shell Profile (global)

Add to `~/.zshrc` or `~/.bashrc`:
```bash
export CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1
```

Then `source ~/.zshrc`. This enables Agent Teams for every project.

---

## Option C: Per-Session

```bash
CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1 claude
```

Useful for testing without committing to global or project config.

---

## Verify the Feature Is Active

Once enabled, you should be able to:
1. Open Claude Code: `claude`
2. Type `/agents` — should show agent management panel
3. Or: ask Claude directly — "Start a teammate agent to help with X"

---

## How Agent Teams Works

```
Your Input
    ↓
Lead Agent (orchestrates, holds main context)
    ├── Teammate A (task: frontend changes)
    ├── Teammate B (task: backend changes)
    └── Teammate C (task: write tests)
         ↓
Shared task board (.claude/tasks.jsonl)
         ↓
Lead Agent merges results
```

Key difference from subagents: Teammates can communicate directly, share a task board, and work in parallel on separate file areas.

---

## Current Limitations (as of v2.1.32)

- `/resume` and `/rewind` do not restore in-progress Teammates — see `09-troubleshooting/resume-fix.md`
- All Teammates use the same model as the Lead Agent
- Parallel edits to the same file cause merge conflicts — use file partitioning (see `06-migration-workflow`)
- Maximum recommended Teammates: 4 (beyond this, coordination overhead exceeds parallelism gains)
