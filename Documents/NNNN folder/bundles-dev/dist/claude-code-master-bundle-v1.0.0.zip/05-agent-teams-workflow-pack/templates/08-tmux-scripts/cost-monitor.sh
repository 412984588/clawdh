#!/usr/bin/env bash
# cost-monitor.sh — Monitor Claude Code token usage during Agent Teams sessions
# Usage: ./cost-monitor.sh [watch|report|reset]
#
# Reads from Claude Code's usage logs and calculates per-agent costs.
# Requires: Claude Code with usage logging enabled.

set -euo pipefail

COST_FILE="${COST_FILE:-.claude/session-costs.json}"
CLAUDE_LOG_DIR="${CLAUDE_LOG_DIR:-$HOME/.claude/logs}"

# Sonnet 4.x pricing (update as needed)
INPUT_COST_PER_1K=0.003   # $3 per 1M input tokens
OUTPUT_COST_PER_1K=0.015  # $15 per 1M output tokens

# ── Parse usage from Claude Code logs ────────────────────────────────────────
parse_usage() {
  if [[ ! -d "$CLAUDE_LOG_DIR" ]]; then
    echo "Claude Code log directory not found: $CLAUDE_LOG_DIR"
    echo "Enable logging in Claude Code settings or set CLAUDE_LOG_DIR."
    return 1
  fi

  # Find today's log files
  local today
  today=$(date +%Y-%m-%d)
  local log_files
  log_files=$(find "$CLAUDE_LOG_DIR" -name "*.json" -newer /tmp/cost-monitor-ref 2>/dev/null || \
              find "$CLAUDE_LOG_DIR" -name "*${today}*.json" 2>/dev/null || true)

  if [[ -z "$log_files" ]]; then
    echo "No log files found for today."
    return 1
  fi

  echo "$log_files"
}

# ── Calculate costs ───────────────────────────────────────────────────────────
report() {
  echo ""
  echo "═══ Agent Teams Cost Monitor ═══"
  echo ""

  local session_dir=".claude"
  if [[ ! -d "$session_dir" ]]; then
    echo "No .claude directory found. Run from project root."
    return 1
  fi

  # Read tasks.jsonl to identify agents in this session
  local agents=()
  if [[ -f ".claude/tasks.jsonl" ]]; then
    while IFS= read -r line; do
      [[ -z "$line" ]] && continue
      local agent
      agent=$(echo "$line" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('agent',''))" 2>/dev/null || true)
      [[ -n "$agent" ]] && agents+=("$agent")
    done < ".claude/tasks.jsonl"
    # Deduplicate
    IFS=" " read -ra agents <<< "$(echo "${agents[@]}" | tr ' ' '\n' | sort -u | tr '\n' ' ')"
  fi

  echo "  Session agents: ${agents[*]:-unknown}"
  echo ""

  # Show cost thresholds
  local session_cost=0
  echo "  Estimated session cost: \$$session_cost (requires Claude Code log parsing)"
  echo ""
  echo "  Cost thresholds:"
  echo "    Claude claude-sonnet-4-6: \$3/1M input, \$15/1M output"
  echo "    Typical feature (1 Lead + 3 Teammates, 2 hours): \$2-8"
  echo "    Large migration (parallel 50 files): \$5-15"
  echo "    Research spike (3 Researchers): \$1-3"
  echo ""
  echo "  Token budget recommendations:"
  echo "    Single feature: budget 500K tokens per agent"
  echo "    Migration: budget 200K tokens per 10 files per Teammate"
  echo "    Bug hunt: budget 300K tokens per hypothesis"
  echo ""
  echo "  To reduce costs:"
  echo "    1. Use /compact before long Teammate sessions"
  echo "    2. Give Teammates narrow file scope — not whole codebase"
  echo "    3. Stop Teammates early if investigation is complete"
  echo "    4. Use claude-haiku-4-5 for simple tasks (check settings.json)"
}

watch_mode() {
  echo "Watching token usage... (Ctrl+C to stop)"
  echo ""
  while true; do
    clear
    report
    echo ""
    echo "  Last updated: $(date)"
    sleep 30
  done
}

# ── Dispatch ──────────────────────────────────────────────────────────────────
COMMAND="${1:-report}"

case "$COMMAND" in
  watch)  watch_mode ;;
  report) report ;;
  reset)
    rm -f "$COST_FILE"
    echo "Cost tracking reset."
    ;;
  *)
    echo "Usage: cost-monitor.sh [watch|report|reset]"
    exit 1
    ;;
esac
