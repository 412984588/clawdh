#!/usr/bin/env bash
# start-team.sh — Launch Claude Code Agent Teams in a tmux multi-pane layout
# Usage: ./start-team.sh [session-name] [num-teammates]
# Example: ./start-team.sh feat-auth 3

set -euo pipefail

SESSION="${1:-agent-team}"
NUM_TEAMMATES="${2:-3}"
WORK_DIR="$(pwd)"

# ── Check dependencies ────────────────────────────────────────────────────────
if ! command -v tmux &>/dev/null; then
  echo "Error: tmux is required. Install with: brew install tmux"
  exit 1
fi

if ! command -v claude &>/dev/null; then
  echo "Error: Claude Code not found. Install with: npm install -g @anthropic-ai/claude-code"
  exit 1
fi

# ── Check Agent Teams is enabled ──────────────────────────────────────────────
if [[ "${CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS:-}" != "1" ]] && \
   ! grep -q "CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS" .claude/settings.json 2>/dev/null; then
  echo "Warning: CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS may not be enabled."
  echo "Copy 01-enable-setup/settings.json to .claude/settings.json first."
fi

# ── Create task board ─────────────────────────────────────────────────────────
mkdir -p .claude
if [[ ! -f .claude/tasks.jsonl ]]; then
  echo '{"session":"'"$SESSION"'","started":"'"$(date -u +%Y-%m-%dT%H:%M:%SZ)"'","status":"active"}' > .claude/tasks.jsonl
  echo "Created .claude/tasks.jsonl"
fi

# ── Kill existing session if running ─────────────────────────────────────────
tmux kill-session -t "$SESSION" 2>/dev/null || true

# ── Create tmux session ───────────────────────────────────────────────────────
tmux new-session -d -s "$SESSION" -x 220 -y 50 -c "$WORK_DIR"

# Pane 0: Lead Agent (top-left, largest)
tmux send-keys -t "$SESSION:0" "echo '=== LEAD AGENT ===' && claude" Enter

# Split and create Teammate panes
for i in $(seq 1 "$NUM_TEAMMATES"); do
  if [[ $i -eq 1 ]]; then
    # First teammate: split main pane vertically
    tmux split-window -t "$SESSION:0" -h -c "$WORK_DIR"
  else
    # Additional teammates: split the last teammate pane horizontally
    tmux split-window -t "$SESSION:0" -v -c "$WORK_DIR"
  fi
  tmux send-keys -t "$SESSION:0" "echo '=== TEAMMATE $i ===' && claude" Enter
done

# Bottom pane: task board monitor
tmux split-window -t "$SESSION:0" -v -l 8 -c "$WORK_DIR"
tmux send-keys -t "$SESSION:0" "watch -n 2 'cat .claude/tasks.jsonl | python3 -m json.tool 2>/dev/null || cat .claude/tasks.jsonl'" Enter

# Select Lead Agent pane
tmux select-pane -t "$SESSION:0.0"

# ── Layout ────────────────────────────────────────────────────────────────────
tmux select-layout -t "$SESSION:0" tiled

echo ""
echo "Agent team started: tmux session '$SESSION'"
echo "Panes: Lead Agent + $NUM_TEAMMATES Teammates + Task Monitor"
echo ""
echo "Attach: tmux attach -t $SESSION"
echo "Detach: Ctrl+B then D"
echo "Kill:   tmux kill-session -t $SESSION"
echo ""

# Auto-attach
tmux attach-session -t "$SESSION"
