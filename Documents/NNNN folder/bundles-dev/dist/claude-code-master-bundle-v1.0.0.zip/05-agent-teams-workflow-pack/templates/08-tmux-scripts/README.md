# 08 — tmux Scripts

Multi-pane tmux launcher, shared task board manager, and token cost monitor for Agent Teams sessions.

## Files

| File | Contents |
|------|----------|
| `start-team.sh` | Launch tmux session with Lead Agent pane + N Teammate panes + task monitor |
| `task-board.sh` | CRUD operations on `.claude/tasks.jsonl` — the shared task board |
| `cost-monitor.sh` | Token usage estimation and cost recommendations per workflow type |

## Quick Start

```bash
chmod +x *.sh

# Start a team of 3 Teammates
./start-team.sh my-feature 3

# In any pane, manage tasks
./task-board.sh list
./task-board.sh start auth-endpoint teammate-b
./task-board.sh done auth-endpoint teammate-b

# Check cost estimates
./cost-monitor.sh report
```

## tmux Layout

```
┌─────────────────────┬──────────────────┐
│   LEAD AGENT        │   TEAMMATE 1     │
│   claude            │   claude         │
│                     ├──────────────────┤
│                     │   TEAMMATE 2     │
│                     │   claude         │
│                     ├──────────────────┤
│                     │   TEAMMATE 3     │
│                     │   claude         │
├─────────────────────┴──────────────────┤
│   TASK MONITOR  (.claude/tasks.jsonl)  │
└────────────────────────────────────────┘
```

## Requirements

- tmux: `brew install tmux`
- Claude Code: `npm install -g @anthropic-ai/claude-code`
- Agent Teams enabled (see `01-enable-setup/`)
