#!/usr/bin/env bash
# task-board.sh — Manage the shared Agent Teams task board (.claude/tasks.jsonl)
# Usage: ./task-board.sh [command] [args]
#
# Commands:
#   list                    — Show all tasks with status
#   add <id> <agent> <desc> — Add a new task
#   start <id> <agent>      — Mark task as in_progress
#   done <id> <agent>       — Mark task as done
#   block <id> <reason>     — Mark task as blocked
#   clear                   — Archive completed tasks

set -euo pipefail

TASK_FILE="${TASK_FILE:-.claude/tasks.jsonl}"
ARCHIVE_FILE="${TASK_FILE%.jsonl}-archive.jsonl"

# ── Ensure task file exists ───────────────────────────────────────────────────
mkdir -p "$(dirname "$TASK_FILE")"
touch "$TASK_FILE"

# ── Commands ─────────────────────────────────────────────────────────────────

cmd_list() {
  echo ""
  echo "═══ Agent Teams Task Board ═══"
  echo ""

  if [[ ! -s "$TASK_FILE" ]]; then
    echo "  (empty — no tasks yet)"
    echo ""
    return
  fi

  local in_progress=0
  local done=0
  local blocked=0

  while IFS= read -r line; do
    [[ -z "$line" ]] && continue
    local status agent id desc
    status=$(echo "$line" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('status','?'))" 2>/dev/null || echo "?")
    agent=$(echo "$line" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('agent','?'))" 2>/dev/null || echo "?")
    id=$(echo "$line" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('id','?'))" 2>/dev/null || echo "?")
    desc=$(echo "$line" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('description','')[:60])" 2>/dev/null || echo "")

    case "$status" in
      in_progress) echo "  ⏳ [$agent] $id — $desc"; in_progress=$((in_progress+1)) ;;
      done)        echo "  ✅ [$agent] $id — $desc"; done=$((done+1)) ;;
      blocked)     echo "  🚫 [$agent] $id — $desc"; blocked=$((blocked+1)) ;;
      *)           echo "  ○  [$agent] $id — $desc" ;;
    esac
  done < "$TASK_FILE"

  echo ""
  echo "  Summary: $in_progress in progress, $done done, $blocked blocked"
  echo ""
}

cmd_add() {
  local id="$1"
  local agent="$2"
  local desc="$3"
  local ts
  ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  echo "{\"id\":\"$id\",\"agent\":\"$agent\",\"status\":\"pending\",\"description\":\"$desc\",\"created\":\"$ts\"}" >> "$TASK_FILE"
  echo "Added: $id → $agent"
}

cmd_start() {
  local id="$1"
  local agent="$2"
  local ts
  ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  echo "{\"id\":\"$id\",\"agent\":\"$agent\",\"status\":\"in_progress\",\"started\":\"$ts\"}" >> "$TASK_FILE"
  echo "Started: $id by $agent"
}

cmd_done() {
  local id="$1"
  local agent="$2"
  local ts
  ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  echo "{\"id\":\"$id\",\"agent\":\"$agent\",\"status\":\"done\",\"completed\":\"$ts\"}" >> "$TASK_FILE"
  echo "Done: $id by $agent"
}

cmd_block() {
  local id="$1"
  local reason="${2:-unspecified}"
  local ts
  ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  echo "{\"id\":\"$id\",\"status\":\"blocked\",\"reason\":\"$reason\",\"blocked_at\":\"$ts\"}" >> "$TASK_FILE"
  echo "Blocked: $id — $reason"
}

cmd_clear() {
  # Archive done tasks, keep active ones
  grep '"status":"done"' "$TASK_FILE" >> "$ARCHIVE_FILE" 2>/dev/null || true
  grep -v '"status":"done"' "$TASK_FILE" > "${TASK_FILE}.tmp" && mv "${TASK_FILE}.tmp" "$TASK_FILE"
  echo "Cleared completed tasks → $ARCHIVE_FILE"
}

# ── Dispatch ──────────────────────────────────────────────────────────────────
COMMAND="${1:-list}"
shift || true

case "$COMMAND" in
  list)  cmd_list ;;
  add)   cmd_add "$1" "$2" "${3:-no description}" ;;
  start) cmd_start "$1" "${2:-unknown}" ;;
  done)  cmd_done "$1" "${2:-unknown}" ;;
  block) cmd_block "$1" "${2:-unspecified}" ;;
  clear) cmd_clear ;;
  *)
    echo "Unknown command: $COMMAND"
    echo "Usage: task-board.sh [list|add|start|done|block|clear]"
    exit 1
    ;;
esac
