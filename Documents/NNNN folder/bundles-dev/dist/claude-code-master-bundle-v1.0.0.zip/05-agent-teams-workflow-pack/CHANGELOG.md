# Changelog

## [1.0.0] - 2026-03-21

### Added
- `01-enable-setup`: settings.json + CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS enable guide
- `02-agent-prompts`: Lead Agent system prompt + Teammate role prompts (frontend/backend/test/docs)
- `03-feature-dev-workflow`: 1 Lead + 3 Teammates feature development workflow with task coordination
- `04-bug-hunt-workflow`: Parallel bug isolation workflow — multiple agents reproducing independently
- `05-code-review-workflow`: Reviewer agent coordination with structured handoff protocol
- `06-migration-workflow`: Large-scale migration with file partitioning to prevent merge conflicts
- `07-research-spike-workflow`: Technical research with parallel information gathering across agents
- `08-tmux-scripts`: start-team.sh (multi-pane launcher), task-board.sh (tasks.jsonl manager), cost-monitor.sh (token cost tracker)
- `09-troubleshooting`: /resume fix for Teammate restoration, conflict resolution SOP, 10K-line refactor case study, monorepo migration case study
