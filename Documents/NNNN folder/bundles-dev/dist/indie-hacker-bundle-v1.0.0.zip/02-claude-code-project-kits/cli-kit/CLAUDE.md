# CLI Tool Kit — Claude Code Project Instructions

## Product Context
- This project is a starter for terminal tools built with Python, Click, and Rich.
- The default user is a solo founder or product engineer who needs a production-shaped CLI skeleton without spending the first day on packaging and DX wiring.
- The starter must stay installable with `pip install -e .` and must expose a working `myapp` command immediately.

## Architecture Guardrails
- `pyproject.toml` is the single source of truth for the package metadata and console entrypoint.
- `src/myapp/cli.py` owns command wiring; keep business logic small and move parsing/config helpers into `src/myapp/config.py`.
- Commands should render clear human-readable output, but the defaults must remain deterministic for tests.
- Environment loading must stay side-effect free at import time.

## Commands
- Create venv: `python3 -m venv .venv`
- Install deps: `PATH="$PWD/.venv/bin:$PATH" python -m pip install -e .[dev]`
- Run tests: `PATH="$PWD/.venv/bin:$PATH" pytest`
- Show help: `PATH="$PWD/.venv/bin:$PATH" myapp --help`
- Run status: `PATH="$PWD/.venv/bin:$PATH" myapp status`

## Working Rules
- Review `.claude/skills/tdd-flow` before adding or changing commands.
- Review `.claude/skills/debug-detective` before chasing packaging, import, or terminal-rendering bugs.
- Review `.claude/skills/code-review-self` before shipping new options, environment variables, or release packaging.
- Prefer small command functions, typed helpers, and stable output markers that tests can assert.

## Definition Of Done
- `pip install -e .[dev]` completes successfully from the project root.
- `myapp --help` returns exit 0 and shows the command list.
- `pytest` proves help output and `status` behavior.
- README and `.env.example` are sufficient for a new user to run the CLI locally.

## Claude Assets
- Project-local skills live under `.claude/skills/`.
- Project-local hooks live under `.claude/hooks/`.
