# CLI Tool Kit

`CLI Tool Kit` is Kit #3 in `Claude Code Project Kits`. It is a Python + Click + Rich starter for teams shipping maintainable terminal workflows with Claude Code guidance embedded from day one.

## Runtime Requirement
- Python 3.11+

## Includes
- Editable-install Python package with a `myapp` console script
- Click command group with a real `status` command
- Rich-powered terminal rendering for structured output
- Project-level `CLAUDE.md`
- Local Claude Code skills for TDD, debugging, and self-review
- Local hooks for test and command verification

## Quick Start
```bash
python3 -m venv .venv
PATH="$PWD/.venv/bin:$PATH" python -m pip install -e .[dev]
cp .env.example .env
PATH="$PWD/.venv/bin:$PATH" myapp --help
PATH="$PWD/.venv/bin:$PATH" myapp status
```

## Windows (PowerShell)
```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[dev]"
Copy-Item .env.example .env
.\.venv\Scripts\python.exe -m myapp.cli --help
.\.venv\Scripts\python.exe -m myapp.cli status
```

If PowerShell is your main shell, run the bundled hooks with `bash .claude/hooks/pre-commit.sh` after creating the virtualenv.

## Environment
The starter reads these variables:
- `MYAPP_ENV`
- `MYAPP_API_BASE_URL`
- `MYAPP_LOG_LEVEL`

Defaults are safe for local development, so `myapp --help` and `myapp status` work even before editing `.env`.

## Project Layout
- `pyproject.toml` defines the editable-install package and `myapp` entrypoint
- `src/myapp/cli.py` contains the Click command group
- `src/myapp/config.py` stores typed environment loading
- `tests/test_cli.py` proves help text and status output
- `.claude/skills/` contains CLI-specific guidance

## Claude Code Workflow
- Read `CLAUDE.md` before adding commands, environment flags, or release steps.
- Use `.claude/skills/tdd-flow` before adding subcommands or changing command output.
- Use `.claude/skills/debug-detective` when CLI behavior or packaging breaks.
- Use `.claude/skills/code-review-self` before shipping new flags, config, or release packaging.

## Verification
```bash
PATH="$PWD/.venv/bin:$PATH" pytest
PATH="$PWD/.venv/bin:$PATH" myapp --help
PATH="$PWD/.venv/bin:$PATH" myapp status
```

Keep `CLAUDE.md` and `.env.example` in sync whenever the command surface changes.
