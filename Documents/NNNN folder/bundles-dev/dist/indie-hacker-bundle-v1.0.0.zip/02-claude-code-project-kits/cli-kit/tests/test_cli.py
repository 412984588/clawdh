from __future__ import annotations

from click.testing import CliRunner

from myapp.cli import main


def test_help_command_lists_available_subcommands() -> None:
    runner = CliRunner()

    result = runner.invoke(main, ['--help'])

    assert result.exit_code == 0
    assert 'status' in result.output
    assert 'hello' in result.output


def test_status_command_renders_environment_values(monkeypatch) -> None:
    runner = CliRunner()
    monkeypatch.setenv('MYAPP_ENV', 'staging')
    monkeypatch.setenv('MYAPP_API_BASE_URL', 'https://api.example.com')
    monkeypatch.setenv('MYAPP_LOG_LEVEL', 'DEBUG')

    result = runner.invoke(main, ['status'])

    assert result.exit_code == 0
    assert 'CLI Kit Status' in result.output
    assert 'staging' in result.output
    assert 'https://api.example.com' in result.output
    assert 'DEBUG' in result.output
