#!/usr/bin/env bash
set -euo pipefail

# PowerShell compatibility: call this with `bash .claude/hooks/pre-push.sh` from PowerShell.
# The command checks still expect the local virtualenv to be present.

PYTHON_BIN="${PYTHON_BIN:-python3}"
if [ -x ".venv/bin/python" ]; then
  PYTHON_BIN=".venv/bin/python"
fi

PYTHONPATH=src "$PYTHON_BIN" -m pytest
PYTHONPATH=src "$PYTHON_BIN" -m myapp.cli --help >/dev/null
