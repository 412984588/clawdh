#!/usr/bin/env bash
set -euo pipefail

# PowerShell compatibility: run via `bash .claude/hooks/pre-commit.sh` after activating `.venv`.
# Ensure `.venv/Scripts` or `.venv/bin` is on PATH before executing.

PYTHON_BIN="${PYTHON_BIN:-python3}"
if [ -x ".venv/bin/python" ]; then
  PYTHON_BIN=".venv/bin/python"
fi

PYTHONPATH=src "$PYTHON_BIN" -m pytest
