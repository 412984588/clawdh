---
name: code-review-self
description: "Use when a CLI change is complete and you want a self-review pass for correctness, maintenance, performance, and safety before handoff."
---

# Code Review Self

## 触发条件
- 准备提交、开 PR 或交付 QA
- 刚完成一批修改，担心遗漏边界条件
- 需要用统一清单做自我复盘

## 工作流程
1. 先对照需求，确认有没有漏功能或偷偷扩 scope。
2. 检查测试覆盖、失败路径、错误提示和日志质量。
3. 再看命名、重复逻辑、隐藏耦合和未来维护成本。
4. 最后做一轮性能与安全扫视：多余查询、敏感信息、无意义依赖。
5. 输出必须修改项和可后续优化项。

## 输出规范
- 按严重级别列问题：critical / medium / low
- 每条问题指出文件、风险和建议动作
- 如果没有发现问题，也要写残余风险和未覆盖区域

## 示例
- 输入：`评审 TaskFlow SaaS 的任务创建改动`
- 输出：
  - medium：`app/api/tasks/route.ts` 还没对空白 title 做拒绝
  - low：`lib/tasks.ts` 的 sample data 和生产逻辑混在一起，后续应拆分
  - residual risk：还没有覆盖重复提交和速率限制
