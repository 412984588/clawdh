---
name: debug-detective
description: "Use when the CLI is failing, behaving strangely, or regressing and you need a reproducible debugging workflow instead of guesswork."
---

# Debug Detective

## 触发条件
- 接到报错截图、日志或异常行为描述
- 某个接口偶发失败，根因不清楚
- 某次改动之后测试或构建突然红了

## 工作流程
1. 先把现象翻译成可复现步骤和期望行为。
2. 收集最短证据链：报错日志、输入样本、最近改动点。
3. 提出 2-3 个根因假设，按验证成本从低到高排序。
4. 一次只验证一个假设，记录排除结果。
5. 根因确认后，再写修复和回归测试。

## 输出规范
- 输出里要分清“现象”“假设”“验证结果”“最终根因”
- 不允许把猜测包装成结论
- 修复建议必须附带防回归手段

## 示例
- 输入：`任务创建接口偶发 500`
- 输出：
  - 现象：POST `/api/tasks` 在 title 为空格时返回 500
  - 假设 A：输入未 trim，校验漏掉空字符串
  - 假设 B：数据库约束未命中时异常没被捕获
  - 先用空格标题复现，确认 `normalizeTaskTitle` 后得到空字符串，再补输入校验和测试
