from __future__ import annotations

from dataclasses import dataclass
import os


@dataclass(frozen=True)
class AppConfig:
    environment: str
    api_base_url: str
    log_level: str

    @classmethod
    def from_env(cls) -> 'AppConfig':
        return cls(
            environment=os.getenv('MYAPP_ENV', 'development'),
            api_base_url=os.getenv('MYAPP_API_BASE_URL', 'http://localhost:8000'),
            log_level=os.getenv('MYAPP_LOG_LEVEL', 'INFO'),
        )
