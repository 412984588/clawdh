from __future__ import annotations

from typing import Final

import click
from rich.console import Console
from rich.table import Table

from myapp.config import AppConfig

APP_NAME: Final[str] = 'myapp'
console = Console()


@click.group(help='Production-shaped CLI starter with Claude Code guidance.')
def main() -> None:
    """Entrypoint for the CLI Tool Kit starter."""


@main.command()
def status() -> None:
    """Render the current local configuration and starter health."""
    config = AppConfig.from_env()
    table = Table(title='CLI Kit Status')
    table.add_column('Field', style='cyan')
    table.add_column('Value', style='green')
    table.add_row('App', APP_NAME)
    table.add_row('Environment', config.environment)
    table.add_row('API Base URL', config.api_base_url)
    table.add_row('Log Level', config.log_level)
    table.add_row('Commands', 'status')
    console.print(table)


@main.command()
@click.argument('name', required=False, default='builder')
def hello(name: str) -> None:
    """Print a starter greeting for quick smoke tests."""
    console.print(f'Hello, {name}. {APP_NAME} is ready.')


if __name__ == '__main__':
    main()
