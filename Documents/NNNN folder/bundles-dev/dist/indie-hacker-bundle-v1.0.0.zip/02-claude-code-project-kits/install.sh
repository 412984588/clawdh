#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KITS_ROOT="$PROJECT_ROOT/kits"
KITS=("saas-kit" "api-kit" "cli-kit" "chrome-ext-kit" "landing-kit")
EXCLUDES=(
  "--exclude=.git"
  "--exclude=.DS_Store"
  "--exclude=node_modules"
  "--exclude=.venv"
  "--exclude=.next"
  "--exclude=dist"
  "--exclude=__pycache__"
  "--exclude=.pytest_cache"
)

choose_kit() {
  echo "Select a kit to initialize:"
  select kit in "${KITS[@]}"; do
    if [[ -n "${kit:-}" ]]; then
      printf '%s\n' "$kit"
      return 0
    fi
  done
}

validate_kit() {
  local kit="$1"
  for candidate in "${KITS[@]}"; do
    if [[ "$candidate" == "$kit" ]]; then
      return 0
    fi
  done
  echo "Unknown kit: $kit" >&2
  echo "Available kits: ${KITS[*]}" >&2
  return 1
}

kit="${1:-}"
target_dir="${2:-}"

if [[ -z "$kit" ]]; then
  kit="$(choose_kit)"
fi

validate_kit "$kit"

if [[ -z "$target_dir" ]]; then
  target_dir="../$kit"
fi

source_dir="$KITS_ROOT/$kit/"

if [[ ! -d "$source_dir" ]]; then
  echo "Missing source kit directory: $source_dir" >&2
  exit 1
fi

mkdir -p "$target_dir"
if [[ -n "$(find "$target_dir" -mindepth 1 -maxdepth 1 2>/dev/null)" ]]; then
  echo "Target directory is not empty: $target_dir" >&2
  exit 1
fi

rsync -a "${EXCLUDES[@]}" "$source_dir" "$target_dir/"

echo "Initialized $kit in $target_dir"
case "$kit" in
  saas-kit|chrome-ext-kit|landing-kit)
    echo "Next steps: cd \"$target_dir\" && npm install"
    ;;
  api-kit|cli-kit)
    echo "Next steps: cd \"$target_dir\" && python3 -m venv .venv"
    ;;
esac
