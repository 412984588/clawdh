import type { MDXComponents } from 'mdx/types';

export function useMDXComponents(components: MDXComponents): MDXComponents {
  return {
    h1: (props) => <h1 className="text-4xl font-bold tracking-tight text-ink" {...props} />,
    h2: (props) => <h2 className="mt-10 text-2xl font-semibold text-ink" {...props} />,
    p: (props) => <p className="mt-4 text-base leading-7 text-stone-700" {...props} />,
    ul: (props) => <ul className="mt-4 list-disc space-y-2 pl-6 text-stone-700" {...props} />,
    li: (props) => <li className="leading-7" {...props} />,
    a: (props) => <a className="font-medium text-pine-500 underline underline-offset-4" {...props} />,
    strong: (props) => <strong className="font-semibold text-ink" {...props} />,
    code: (props) => (
      <code
        className="rounded-md bg-stone-900 px-1.5 py-0.5 font-mono text-sm text-amber-100"
        {...props}
      />
    ),
    ...components,
  };
}
