import Link from 'next/link';

export interface CtaButtonProps {
  href: string;
  label: string;
  variant?: 'primary' | 'secondary';
}

export function CtaButton({ href, label, variant = 'primary' }: CtaButtonProps) {
  const classes =
    variant === 'primary'
      ? 'bg-accent-500 text-white shadow-soft hover:bg-accent-700'
      : 'border border-stone-400/60 bg-white/70 text-ink hover:bg-white';

  return (
    <Link
      className={`inline-flex items-center justify-center rounded-full px-5 py-3 text-sm font-semibold transition ${classes}`}
      href={href}
    >
      {label}
    </Link>
  );
}
