import { CtaButton } from '@/components/cta-button';
import { siteCopy } from '@/lib/site-copy';

export default function LandingPage() {
  return (
    <main className="page-shell gap-8">
      <section className="surface-panel grid gap-8 overflow-hidden px-6 py-8 sm:px-10 sm:py-12 lg:grid-cols-[1.3fr,0.7fr]">
        <div className="space-y-6">
          <span className="eyebrow">{siteCopy.hero.eyebrow}</span>
          <h1 className="max-w-3xl text-5xl font-semibold tracking-tight text-ink sm:text-6xl">
            {siteCopy.hero.title}
          </h1>
          <p className="max-w-2xl text-lg leading-8 text-stone-700">
            {siteCopy.hero.description}
          </p>
          <div className="flex flex-wrap gap-3">
            <CtaButton href="#pricing" label={siteCopy.hero.primaryCta} />
            <CtaButton href="/guide" label={siteCopy.hero.secondaryCta} variant="secondary" />
          </div>
        </div>

        <div className="rounded-panel bg-stone-950 px-6 py-6 text-amber-50">
          <p className="eyebrow text-accent-100">Launch snapshot</p>
          <div className="mt-4 space-y-4">
            {siteCopy.proofPoints.map((proofPoint) => (
              <div className="rounded-2xl border border-white/10 px-4 py-4" key={proofPoint}>
                <p className="text-sm leading-6 text-stone-200">{proofPoint}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="grid gap-4 lg:grid-cols-3">
        {siteCopy.features.map((feature) => (
          <article className="surface-panel px-6 py-6" key={feature.title}>
            <h2 className="text-xl font-semibold text-ink">{feature.title}</h2>
            <p className="mt-3 text-sm leading-7 text-stone-700">{feature.description}</p>
          </article>
        ))}
      </section>

      <section className="surface-panel px-6 py-8 sm:px-10" id="pricing">
        <div className="max-w-2xl">
          <span className="eyebrow">Pricing that matches launch speed</span>
          <h2 className="mt-3 text-3xl font-semibold text-ink sm:text-4xl">
            Sell the page, then reuse the system.
          </h2>
        </div>
        <div className="mt-8 grid gap-4 lg:grid-cols-3">
          {siteCopy.pricing.map((tier) => (
            <article className="rounded-panel bg-stone-950 px-6 py-6 text-stone-100" key={tier.name}>
              <p className="text-sm uppercase tracking-[0.18em] text-accent-100">{tier.name}</p>
              <p className="mt-4 text-4xl font-semibold">{tier.price}</p>
              <p className="mt-3 text-sm leading-7 text-stone-300">{tier.description}</p>
              <ul className="mt-4 space-y-2 text-sm text-stone-200">
                {tier.bullets.map((bullet) => (
                  <li key={bullet}>• {bullet}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </section>

      <section className="grid gap-4 lg:grid-cols-[0.95fr,1.05fr]">
        <div className="surface-panel px-6 py-8">
          <span className="eyebrow">FAQ</span>
          <div className="mt-5 space-y-5">
            {siteCopy.faqs.map((faq) => (
              <article key={faq.question}>
                <h3 className="text-lg font-semibold text-ink">{faq.question}</h3>
                <p className="mt-2 text-sm leading-7 text-stone-700">{faq.answer}</p>
              </article>
            ))}
          </div>
        </div>

        <div className="surface-panel flex flex-col justify-between gap-6 bg-pine-700 px-6 py-8 text-white">
          <div>
            <span className="eyebrow text-accent-100">Final CTA</span>
            <h2 className="mt-3 text-3xl font-semibold sm:text-4xl">
              Keep the homepage focused and move the deep explanation into MDX.
            </h2>
            <p className="mt-4 max-w-xl text-sm leading-7 text-emerald-50/90">
              Use this starter when you need a launch page today and a content engine tomorrow.
              The homepage sells. The `/guide` route explains.
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            <CtaButton href="/guide" label="Read the launch guide" />
            <CtaButton href="#pricing" label="Review pricing" variant="secondary" />
          </div>
        </div>
      </section>
    </main>
  );
}
