# Landing Kit — Claude Code Project Instructions

## Product Context
- This project is a starter for landing pages built with Next.js, Tailwind CSS, and MDX.
- The default user is a solo founder or launch-minded product engineer who needs a polished public-facing page without rebuilding a marketing system from scratch.
- The starter must remain readable on mobile first and boot cleanly with `npm run dev`.

## Architecture Guardrails
- `app/page.tsx` owns the main marketing narrative and should stay easy to edit in one pass.
- `app/guide/page.mdx` is the long-form content surface for launch notes, onboarding, or SEO entries.
- Shared copy and pricing data should live in `lib/site-copy.ts`, not be duplicated across sections.
- Tailwind styling should feel intentional; avoid default gray-on-white scaffolding.

## Commands
- Install deps: `npm install`
- Run tests: `npm test`
- Run typecheck: `npm run typecheck`
- Start dev server: `npm run dev`
- Build for production: `npm run build`

## Working Rules
- Review `.claude/skills/landing-page` before reshaping the homepage sections or copy hierarchy.
- Review `.claude/skills/feedback-loop` before adding forms, surveys, or in-page product feedback capture.
- Review `.claude/skills/ship-checklist` before publishing, shipping metadata, or marketing assets.
- Keep every new CTA grounded in an explicit user action and avoid filler copy.

## Definition Of Done
- `npm test` passes from the project root.
- `npm run dev` serves the landing page and `/guide` MDX route successfully.
- `npm run build` succeeds without extra setup.
- README is sufficient for a new user to start the site locally.

## Claude Assets
- Project-local skills live under `.claude/skills/`.
- Project-local hooks live under `.claude/hooks/`.
