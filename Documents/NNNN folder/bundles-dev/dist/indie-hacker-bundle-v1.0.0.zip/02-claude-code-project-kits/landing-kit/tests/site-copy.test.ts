import assert from 'node:assert/strict';
import test from 'node:test';

import { siteCopy } from '../lib/site-copy.ts';

test('site copy exposes the full landing page structure', () => {
  assert.equal(siteCopy.features.length, 3);
  assert.equal(siteCopy.pricing.length, 3);
  assert.equal(siteCopy.faqs.length, 3);
});

test('hero copy keeps both CTA labels available', () => {
  assert.match(siteCopy.hero.title, /Launch a landing page/i);
  assert.ok(siteCopy.hero.primaryCta.length > 0);
  assert.ok(siteCopy.hero.secondaryCta.length > 0);
});
