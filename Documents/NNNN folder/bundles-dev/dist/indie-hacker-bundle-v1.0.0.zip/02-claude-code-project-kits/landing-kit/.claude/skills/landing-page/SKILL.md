---
name: landing-page
description: "Use when you need to structure or rewrite a high-conviction landing page with hero, proof, pricing, FAQ, and CTA sections."
---

# Landing Page — 快速生成高转化落地页

## 触发条件
- 用户说"帮我做落地页"、"生成首页"、"做个 landing page"
- 产品需要对外展示，还没有公开页面
- 需要把产品卖出去，需要介绍页面

## 工作流程
1. **收集信息**：产品名、一句话描述、3 个核心功能、目标用户、定价
2. **生成结构**：Hero → Problem → Solution → Features → Pricing → FAQ → CTA
3. **写文案**：聚焦用户痛点，不写功能列表，写用户得到的结果
4. **生成代码**：Next.js + Tailwind + shadcn/ui，直接可运行
5. **检查转化**：确保每屏都有 CTA，主按钮颜色对比度足够

## 输出规范
- 完整的 `app/page.tsx` 文件
- 所有 section 都在一个文件（Landing Page 不需要拆组件）
- 移动端优先（sm: breakpoint）
- 包含 `<meta>` SEO 标签
