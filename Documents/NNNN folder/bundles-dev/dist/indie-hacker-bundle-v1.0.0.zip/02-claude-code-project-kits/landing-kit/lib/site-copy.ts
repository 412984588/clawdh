export interface LandingFeature {
  title: string;
  description: string;
}

export interface PricingTier {
  name: string;
  price: string;
  description: string;
  bullets: string[];
}

export interface FaqItem {
  question: string;
  answer: string;
}

export interface SiteCopy {
  hero: {
    eyebrow: string;
    title: string;
    description: string;
    primaryCta: string;
    secondaryCta: string;
  };
  proofPoints: string[];
  features: LandingFeature[];
  pricing: PricingTier[];
  faqs: FaqItem[];
}

export const siteCopy: SiteCopy = {
  hero: {
    eyebrow: 'Next.js + Tailwind + MDX starter',
    title: 'Launch a landing page that explains the product before the demo even starts.',
    description:
      'Landing Kit gives solo builders a premium homepage, opinionated section flow, and an MDX route for deeper launch content without burning a day on framework wiring.',
    primaryCta: 'Start your launch sprint',
    secondaryCta: 'Open the launch guide',
  },
  proofPoints: [
    'Hero-to-FAQ structure ready for direct copy swaps',
    'MDX route ready for launch notes and SEO-friendly explainers',
    'Tailwind styling tuned for a warm editorial aesthetic instead of generic SaaS chrome',
  ],
  features: [
    {
      title: 'Copy-first sections',
      description: 'Every homepage block is written for positioning, proof, and conversion, not placeholder lorem.',
    },
    {
      title: 'MDX-native long-form content',
      description: 'Add launch essays, onboarding guides, or product notes in `/guide` without building a CMS.',
    },
    {
      title: 'Local Claude workflow',
      description: 'Landing-page, feedback, and ship-checklist skills live inside the repo so edits stay consistent.',
    },
  ],
  pricing: [
    {
      name: 'Starter',
      price: '$19',
      description: 'Single landing page for a single launch moment.',
      bullets: ['One homepage', 'One MDX guide', 'Local Claude assets'],
    },
    {
      name: 'Growth',
      price: '$39',
      description: 'Add supporting pages and iterate without losing the narrative.',
      bullets: ['Reusable section system', 'Launch checklist', 'Feedback workflow hooks'],
    },
    {
      name: 'Studio',
      price: '$79',
      description: 'Ship multiple product angles from one strong base.',
      bullets: ['Multi-campaign reuse', 'Editorial MDX workflow', 'Lifetime starter updates'],
    },
  ],
  faqs: [
    {
      question: 'Why include MDX in a landing-page starter?',
      answer:
        'Because launch pages rarely live alone. Founders need a homepage plus deeper guides, changelogs, and announcements that stay easy to edit.',
    },
    {
      question: 'Can I use this without a design system?',
      answer:
        'Yes. The starter includes an intentional visual baseline, reusable CTA styling, and section spacing that stays coherent from mobile to desktop.',
    },
    {
      question: 'What does Claude Code add here?',
      answer:
        'Project-local guidance for landing-page structure, feedback capture, and ship readiness reduces drift when you iterate under time pressure.',
    },
  ],
};
