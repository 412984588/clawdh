# Landing Kit

`Landing Kit` is Kit #5 in `Claude Code Project Kits`. It is a Next.js + Tailwind + MDX starter for teams shipping high-conviction marketing pages, launch narratives, and changelog-style content with Claude Code guidance embedded from day one.

## Runtime Requirement
- Node 18+

## Includes
- App Router landing page with hero, proof, features, pricing, FAQ, and CTA sections
- Tailwind styling tuned for a premium editorial landing page
- MDX route at `/guide` for launch playbooks, product notes, or longer-form sales content
- Project-level `CLAUDE.md`
- Local Claude Code skills for landing-page copy, feedback capture, and launch readiness
- Local hooks for test, typecheck, and build verification

## Quick Start
```bash
npm install
npm test
npm run typecheck
npm run dev
```

Open `http://127.0.0.1:3000` for the landing page and `http://127.0.0.1:3000/guide` for the MDX route.

## Environment
The starter exposes these variables:
- `NEXT_PUBLIC_SITE_URL`
- `NEXT_PUBLIC_PRIMARY_CTA`

Defaults are safe for local development, so the landing page boots even before copying `.env.example`.

## Project Layout
- `app/page.tsx` contains the primary landing page
- `app/guide/page.mdx` proves MDX authoring works out of the box
- `lib/site-copy.ts` stores reusable copy blocks and pricing data
- `components/cta-button.tsx` centralizes CTA styling
- `.claude/skills/` contains project-local workflow guidance

## Claude Code Workflow
- Read `CLAUDE.md` before changing page structure, CTA hierarchy, or SEO copy.
- Use `.claude/skills/landing-page` before restructuring hero, features, pricing, or FAQ sections.
- Use `.claude/skills/feedback-loop` before wiring waitlists, support forms, or user feedback widgets.
- Use `.claude/skills/ship-checklist` before publishing or handing off the build.

## Verification
```bash
npm test
npm run typecheck
npm run build
npm run dev
```

Expected result:
- `GET /` returns the landing page headline
- `GET /guide` renders the MDX playbook
- `CLAUDE.md` and `.env.example` remain aligned with the page structure and CTAs
