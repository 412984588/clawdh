/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{ts,tsx,mdx}',
    './components/**/*.{ts,tsx}',
    './mdx-components.tsx',
  ],
  theme: {
    extend: {
      colors: {
        canvas: '#f7f3ea',
        ink: '#1c1b18',
        accent: {
          100: '#f4d58d',
          300: '#e6b54a',
          500: '#d08c22',
          700: '#945915',
        },
        pine: {
          100: '#dcebe3',
          500: '#295f4a',
          700: '#17392d',
        },
      },
      boxShadow: {
        soft: '0 22px 50px rgba(28, 27, 24, 0.12)',
      },
      borderRadius: {
        panel: '1.75rem',
      },
    },
  },
  plugins: [],
};
