# API Kit

`API Kit` is Kit #2 in `Claude Code Project Kits`. It is a FastAPI + PostgreSQL + Docker starter for teams shipping JSON APIs with project-local Claude Code guidance embedded from day one.

## Runtime Requirement
- Python 3.11+

## Includes
- FastAPI app with `/health` endpoint
- SQLAlchemy session bootstrap for PostgreSQL
- Dockerfile + `docker-compose.yml` for local API + database boot
- Project-level `CLAUDE.md`
- Local Claude Code skills for API design, schema modeling, and security review
- Local hooks for test and syntax validation

## Quick Start
```bash
python3 -m venv .venv
PATH="$PWD/.venv/bin:$PATH" python -m pip install -r requirements.txt
cp .env.example .env
PATH="$PWD/.venv/bin:$PATH" python -m uvicorn main:app --reload
```

## Windows (PowerShell)
```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
.\.venv\Scripts\python.exe -m uvicorn main:app --reload
```

PowerShell users can also run the bash hooks with `bash .claude/hooks/pre-commit.sh` after the virtualenv is created.

The API will start on `http://127.0.0.1:8000`. Check `GET /health` first.

## Docker
```bash
docker compose up --build
```

This brings up:
- `api` on port `8000`
- `postgres` on port `5432`

The included `docker-compose.yml` reads `.env.example` by default, so the stack can boot for first-run validation without a manual env copy step.

## Project Layout
- `main.py` exposes the Uvicorn entrypoint
- `app/api/` contains routers
- `app/core/config.py` stores typed settings
- `app/db/session.py` stores PostgreSQL engine/session setup
- `.claude/skills/` contains API-specific guidance

## Claude Code Workflow
- Read `CLAUDE.md` before touching routes, models, or auth logic.
- Use `.claude/skills/api-designer` before adding or changing endpoints.
- Use `.claude/skills/db-modeler` before changing tables or migrations.
- Use `.claude/skills/security-check` before merging auth, secrets, or CORS changes.

## Verification
```bash
PATH="$PWD/.venv/bin:$PATH" pytest
PATH="$PWD/.venv/bin:$PATH" python -m uvicorn main:app --host 127.0.0.1 --port 8051
```
