# API Kit — Claude Code Project Instructions

## Product Context
- This project is a starter for REST APIs built with FastAPI, PostgreSQL, and Docker.
- The default user is a solo founder or backend engineer who needs a production-shaped service skeleton without spending the first day on framework wiring.
- The starter must stay import-safe and bootable even when PostgreSQL is not running yet.

## Architecture Guardrails
- `main.py` is the only public Uvicorn entrypoint.
- Database configuration lives in `app/core/config.py` and `app/db/session.py`.
- Route handlers must return typed JSON-friendly payloads and avoid connecting to PostgreSQL at import time.
- Health checks must stay lightweight and must not depend on a live database.

## Commands
- Create venv: `python3 -m venv .venv`
- Install deps: `PATH="$PWD/.venv/bin:$PATH" python -m pip install -r requirements.txt`
- Run API: `PATH="$PWD/.venv/bin:$PATH" python -m uvicorn main:app --reload`
- Run tests: `PATH="$PWD/.venv/bin:$PATH" pytest`
- Boot Docker stack: `docker compose up --build`

## Working Rules
- Review `.claude/skills/api-designer` before adding endpoints or response contracts.
- Review `.claude/skills/db-modeler` before touching persistence or introducing migrations.
- Review `.claude/skills/security-check` before changing auth, secrets, headers, or public exposure.
- Prefer explicit dependency injection and typed settings over global mutable state.

## Definition Of Done
- `python -m uvicorn main:app` starts successfully from the project root.
- `GET /health` returns a JSON payload without requiring PostgreSQL.
- README and `.env.example` are sufficient for a new user to run the API locally.

## Claude Assets
- Project-local skills live under `.claude/skills/`.
- Project-local hooks live under `.claude/hooks/`.
