---
name: security-check
description: "Use when you are about to merge or ship backend changes and need a concrete security pass over validation, auth, secrets, and logging."
---

# Security Check

## 触发条件
- 功能完成，准备提测或上线
- 新增了认证、支付、Webhook 或文件上传
- 接口会处理用户输入或外部回调

## 工作流程
1. 检查输入校验是否覆盖空值、越界和恶意格式。
2. 检查权限边界：谁能读、谁能写、谁能删。
3. 扫描密钥、token 和服务角色 key 是否误入仓库。
4. 检查依赖漏洞和不必要的高权限服务账号。
5. 输出必须修、建议修和可接受风险三类结论。

## 输出规范
- 每条问题要给出风险级别和修复建议
- 结论必须落到具体文件、接口或配置点
- 不允许只说“注意安全”这种空话

## 示例
- 输入：`检查 TaskFlow SaaS 的任务创建接口`
- 输出：
  - 发现 `SUPABASE_SERVICE_ROLE_KEY` 不应出现在浏览器端环境变量
  - 建议在服务端 route handler 校验 title 长度和用户 session
  - 若开启 RLS，需要确保用户只能操作自己的 tasks 记录
