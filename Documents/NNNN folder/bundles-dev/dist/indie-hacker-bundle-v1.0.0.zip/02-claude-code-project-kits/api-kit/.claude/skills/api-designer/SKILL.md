---
name: api-designer
description: "Use when you need to turn product actions into a clear API contract before writing handlers, docs, or tests."
---

# API Designer

## 触发条件
- 新增 REST 或 GraphQL 接口
- 需要为前后端协作定义清晰契约
- 想把零散 handler 收敛成可维护的 API 面

## 工作流程
1. 定义资源名、用户动作和最小字段集。
2. 先写请求体、响应体和错误体结构。
3. 明确鉴权、幂等、分页和排序规则。
4. 用真实调用示例验证命名是否顺手。
5. 最后再实现 handler、文档和测试。

## 输出规范
- 至少包含 endpoint、method、request、response、error cases
- 错误码和错误文案要能直接给前端用
- 如果有分页，必须说明默认排序和游标/页码策略

## 示例
- 输入：`给 TaskFlow SaaS 设计任务列表 API`
- 输出：
  - `GET /api/tasks?status=today&limit=20`
  - 成功响应返回 `data[]` 和 `meta.count`
  - 400 用于非法 status，401 用于未登录，500 留给不可恢复错误
  - 补一条 `POST /api/tasks` 示例，说明 title 不能为空
