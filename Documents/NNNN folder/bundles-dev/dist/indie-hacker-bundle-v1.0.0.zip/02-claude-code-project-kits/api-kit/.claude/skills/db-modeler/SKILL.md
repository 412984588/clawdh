---
name: db-modeler
description: "Use when product requirements need a database shape, migration plan, and indexing strategy that fit the MVP."
---

# DB Modeler

## 触发条件
- 要设计新表、迁移或索引
- 需求已经从页面层走到真实持久化
- 团队在讨论“一张表还是多张表”

## 工作流程
1. 识别核心实体、主键和生命周期。
2. 只保留当前迭代必须落库的字段。
3. 写出约束、默认值和删除策略。
4. 根据查询路径补最小索引，而不是预建所有索引。
5. 同步输出迁移顺序和回滚提示。

## 输出规范
- 必须包含表结构、字段解释、约束和索引理由
- 说明哪些字段是未来扩展位，哪些是现在就要严格校验的
- 尽量给出 SQL 或 migration 片段

## 示例
- 输入：`为 TaskFlow SaaS 设计 tasks 表`
- 输出：
  - 字段：`id/title/priority/status/due_at/created_at`
  - 约束：priority 和 status 用 check constraint
  - 索引：`(status, priority, created_at desc)` 支持 today/backlog 列表
  - 暂不拆 subtasks，先把产品做出来
