#!/usr/bin/env bash
set -euo pipefail

# PowerShell compatibility: invoke with `bash .claude/hooks/pre-push.sh` once the virtualenv exists.
# Docker validation remains optional and only runs when `docker` is available on PATH.

PYTHON_BIN="${PYTHON_BIN:-python3}"
if [ -x ".venv/bin/python" ]; then
  PYTHON_BIN=".venv/bin/python"
fi

"$PYTHON_BIN" -m pytest
"$PYTHON_BIN" -m compileall main.py app

if command -v docker >/dev/null 2>&1; then
  docker compose config >/dev/null
fi
