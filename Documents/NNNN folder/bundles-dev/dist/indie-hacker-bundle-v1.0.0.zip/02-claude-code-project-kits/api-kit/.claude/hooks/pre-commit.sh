#!/usr/bin/env bash
set -euo pipefail

# PowerShell compatibility: run via `bash .claude/hooks/pre-commit.sh` after creating `.venv`.
# Keep `.venv/Scripts` or `.venv/bin` on PATH before invoking this hook.

PYTHON_BIN="${PYTHON_BIN:-python3}"
if [ -x ".venv/bin/python" ]; then
  PYTHON_BIN=".venv/bin/python"
fi

"$PYTHON_BIN" -m pytest
