from functools import lru_cache

from pydantic import computed_field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "API Kit"
    app_env: str = "development"
    api_v1_prefix: str = "/api/v1"
    database_url: str = "postgresql+psycopg://postgres:postgres@localhost:5432/api_kit"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    @computed_field  # type: ignore[prop-decorator]
    @property
    def database_host(self) -> str:
        without_driver = self.database_url.split("://", maxsplit=1)[-1]
        host_part = without_driver.split("@")[-1]
        return host_part.split("/")[0]


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
