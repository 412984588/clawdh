from fastapi import APIRouter

from app.core.config import get_settings

router = APIRouter(tags=["health"])


@router.get("/health")
def healthcheck() -> dict[str, str]:
    settings = get_settings()
    return {
      "status": "ok",
      "service": settings.app_name,
      "environment": settings.app_env,
      "database_host": settings.database_host,
    }
