from fastapi.testclient import TestClient

from main import app


client = TestClient(app)


def test_healthcheck_returns_service_metadata() -> None:
    response = client.get("/health")

    assert response.status_code == 200
    assert response.json()["status"] == "ok"
    assert response.json()["service"] == "API Kit"
