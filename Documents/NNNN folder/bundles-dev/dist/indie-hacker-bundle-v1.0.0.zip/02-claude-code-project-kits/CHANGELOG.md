# Changelog

## [1.0.0] - 2026-03-20

### Added
- Initial release with five project kits: `saas-kit`, `api-kit`, `cli-kit`, `chrome-ext-kit`, and `landing-kit`
- Root installer and bundle builder for individual kit ZIPs plus the complete bundle
- Embedded local `CLAUDE.md`, skills, hooks, and starter project scaffolds

### Changed
- Final QA remediation for root docs, runtime requirements, cross-platform notes, and kit packaging hygiene
