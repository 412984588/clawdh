import { DEFAULT_POPUP_STATE } from '@/lib/storage';

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    void chrome.storage.local.set({
      popup_state: DEFAULT_POPUP_STATE,
      install_timestamp: new Date().toISOString(),
    });
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === 'PING') {
    sendResponse({ type: 'PONG' });
  }

  return true;
});
