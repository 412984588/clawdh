export interface PopupState {
  enabled: boolean;
  lastPingStatus: 'idle' | 'ok' | 'error';
}

export const DEFAULT_POPUP_STATE: PopupState = {
  enabled: true,
  lastPingStatus: 'idle',
};

export async function loadPopupState(): Promise<PopupState> {
  const fallback = DEFAULT_POPUP_STATE;
  if (!chrome?.storage?.local) {
    return fallback;
  }

  const result = await chrome.storage.local.get('popup_state');
  return {
    ...fallback,
    ...(result.popup_state as Partial<PopupState> | undefined),
  };
}

export async function savePopupState(state: PopupState): Promise<void> {
  if (!chrome?.storage?.local) {
    return;
  }

  await chrome.storage.local.set({ popup_state: state });
}

export async function pingBackground(): Promise<boolean> {
  if (!chrome?.runtime?.sendMessage) {
    return false;
  }

  try {
    const response = await chrome.runtime.sendMessage({ type: 'PING' });
    return response?.type === 'PONG';
  } catch {
    return false;
  }
}
