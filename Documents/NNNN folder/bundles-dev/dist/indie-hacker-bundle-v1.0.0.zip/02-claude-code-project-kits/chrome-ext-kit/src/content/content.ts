const ATTRIBUTE_NAME = 'data-claude-code-project-kit';

if (!document.documentElement.hasAttribute(ATTRIBUTE_NAME)) {
  document.documentElement.setAttribute(ATTRIBUTE_NAME, 'chrome-ext-kit');
}

void chrome.runtime.sendMessage({ type: 'PING' }).catch(() => {
  // Ignore missing worker responses during page-only smoke tests.
});
