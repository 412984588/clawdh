import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { PopupPanel } from './PopupPanel';
import './popup.css';

const root = document.getElementById('root');

if (!root) {
  throw new Error('Root element not found');
}

createRoot(root).render(
  <StrictMode>
    <PopupPanel />
  </StrictMode>,
);
