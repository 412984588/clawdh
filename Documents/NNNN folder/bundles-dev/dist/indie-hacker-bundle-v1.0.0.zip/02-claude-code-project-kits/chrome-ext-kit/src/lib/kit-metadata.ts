export interface KitMetadata {
  readonly id: 'chrome-ext-kit';
  readonly name: string;
  readonly version: string;
  readonly defaultPrompt: string;
}

export const kitMetadata: KitMetadata = {
  id: 'chrome-ext-kit',
  name: import.meta.env.VITE_EXTENSION_NAME ?? 'Chrome Extension Kit',
  version: '0.1.0',
  defaultPrompt:
    import.meta.env.VITE_DEFAULT_PROMPT ??
    'Summarize the current page and suggest the next action.',
};
