import { useEffect, useState } from 'react';
import { kitMetadata } from '@/lib/kit-metadata';
import {
  DEFAULT_POPUP_STATE,
  loadPopupState,
  pingBackground,
  savePopupState,
  type PopupState,
} from '@/lib/storage';

export function PopupPanel() {
  const [state, setState] = useState<PopupState>(DEFAULT_POPUP_STATE);

  useEffect(() => {
    void loadPopupState().then(setState);
  }, []);

  async function toggleEnabled(): Promise<void> {
    const nextState: PopupState = {
      ...state,
      enabled: !state.enabled,
    };
    setState(nextState);
    await savePopupState(nextState);
  }

  async function checkBridge(): Promise<void> {
    const ok = await pingBackground();
    const nextState: PopupState = {
      ...state,
      lastPingStatus: ok ? 'ok' : 'error',
    };
    setState(nextState);
    await savePopupState(nextState);
  }

  return (
    <main className="panel">
      <section className="hero">
        <span className="eyebrow">Claude Code Project Kit</span>
        <h1>{kitMetadata.name}</h1>
        <p>{kitMetadata.defaultPrompt}</p>
      </section>

      <section className="status-card">
        <div className="status-grid">
          <div>
            <span className="status-label">Extension</span>
            <span className="status-value">{state.enabled ? 'Enabled' : 'Paused'}</span>
          </div>
          <div>
            <span className="status-label">Bridge</span>
            <span
              className={`status-value ${
                state.lastPingStatus === 'ok' ? 'success' : 'idle'
              }`}
            >
              {state.lastPingStatus.toUpperCase()}
            </span>
          </div>
        </div>
      </section>

      <section className="actions-card">
        <span className="status-label">Actions</span>
        <div className="action-row">
          <button className="button primary" onClick={() => void toggleEnabled()} type="button">
            {state.enabled ? 'Pause Extension' : 'Enable Extension'}
          </button>
          <button className="button secondary" onClick={() => void checkBridge()} type="button">
            Ping Worker
          </button>
        </div>
      </section>
    </main>
  );
}
