---
name: feedback-loop
description: "Use when the extension needs a lightweight in-product feedback loop with capture, categorization, and notification."
---

# Feedback Loop — 用户反馈系统

## 触发条件
- 用户说"加反馈功能"、"收集用户意见"、"做用户反馈"
- 产品上线后需要了解用户在想什么
- 需要知道哪里出了问题

## 工作流程
1. **反馈按钮**：页面右下角固定按钮，点击弹出表单
2. **收集信息**：类型（Bug/功能请求/其他）+ 描述 + 截图（可选）
3. **存入数据库**：Supabase `feedback` 表
4. **发邮件通知**：Resend 发给开发者
5. **Dashboard**：在后台看所有反馈，标记已读/处理中/已完成

## 输出规范
- `components/feedback-widget.tsx`：悬浮反馈按钮 + 表单
- `app/api/feedback/route.ts`：API 端点
- `supabase/migrations/002_feedback.sql`：数据库表
- `app/(dashboard)/feedback/page.tsx`：反馈管理页
