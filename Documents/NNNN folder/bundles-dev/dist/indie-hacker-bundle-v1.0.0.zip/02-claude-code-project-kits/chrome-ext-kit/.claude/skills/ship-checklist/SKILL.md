---
name: ship-checklist
description: "Use when the extension is close to release and you need a concrete launch checklist before publish or handoff."
---

# Ship Checklist — 上线前必检清单

## 触发条件
- 用户说"我要上线了"、"准备发布"、"deploy 之前要做什么"
- 产品功能开发完，准备对外公开
- 第一次上线，不知道要检查什么

## 工作流程
运行完整清单，每项都要确认 ✅ 或说明为什么跳过：

### 🌐 域名 & 基础设施
- [ ] 自定义域名已绑定（不用 vercel.app 子域）
- [ ] SSL 证书有效（HTTPS 强制跳转）
- [ ] www 重定向到 non-www（或反过来，保持一致）
- [ ] 环境变量全部在 Vercel/Railway 配好

### 🔍 SEO & 社交分享
- [ ] `<title>` 每页不同，< 60 字符
- [ ] `<meta name="description">` 每页，< 160 字符
- [ ] OG 图 1200×630px（`og:image`）
- [ ] `robots.txt` 存在（`/public/robots.txt`）
- [ ] `sitemap.xml` 已生成

### 📊 监控 & 分析
- [ ] Plausible 或 Vercel Analytics 已添加
- [ ] Sentry 错误监控已配置
- [ ] Uptime 监控（BetterUptime 免费计划）

## 输出规范
- 逐项输出 ✅ / ❌ / ⚠️ 状态
- ❌ 项给出最快修复方式（< 5 分钟能搞定的先搞定）
- 输出最终上线宣言格式
