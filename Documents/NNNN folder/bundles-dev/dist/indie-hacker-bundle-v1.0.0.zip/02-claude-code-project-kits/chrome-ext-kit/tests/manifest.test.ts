import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';

const kitRoot = dirname(fileURLToPath(new URL('../package.json', import.meta.url)));

test('manifest uses MV3 and points to generated build entries', async () => {
  const manifest = JSON.parse(
    await readFile(join(kitRoot, 'public/manifest.json'), 'utf8'),
  ) as {
    manifest_version?: number;
    action?: { default_popup?: string };
    background?: { service_worker?: string; type?: string };
    content_scripts?: Array<{ js?: string[] }>;
  };

  assert.equal(manifest.manifest_version, 3);
  assert.equal(manifest.action?.default_popup, 'popup.html');
  assert.equal(manifest.background?.service_worker, 'background.js');
  assert.equal(manifest.background?.type, 'module');
  assert.equal(manifest.content_scripts?.[0]?.js?.[0], 'content.js');
});
