# Chrome Extension Kit — Claude Code Project Instructions

## Product Context
- This project is a starter for Chrome Extensions built with Manifest V3, React, and Vite.
- The default user is a solo founder or product engineer who needs a production-shaped browser extension skeleton without spending the first day on manifest wiring and build setup.
- The starter must always build into a Chrome-loadable `dist/` directory.

## Architecture Guardrails
- `public/manifest.json` is the single source of truth for permissions, entrypoints, and MV3 metadata.
- `popup.html` and `src/popup/` own the React popup UI.
- `src/background/service-worker.ts` must stay event-driven and avoid assuming persistent in-memory state.
- `src/content/content.ts` should be safe to inject repeatedly on the same page.
- Shared extension state must flow through `src/lib/storage.ts`, not scattered raw `chrome.storage` calls.

## Commands
- Install deps: `npm install`
- Run tests: `npm test`
- Run typecheck: `npm run typecheck`
- Build unpacked extension: `npm run build`
- Rebuild on file changes: `npm run dev`

## Working Rules
- Review `.claude/skills/mvp-scaffold` before adding extension pages, options screens, or new build surfaces.
- Review `.claude/skills/feedback-loop` before collecting user input, debug traces, or support signals.
- Review `.claude/skills/ship-checklist` before changing permissions, preparing Chrome Web Store assets, or packaging the build.
- Keep permissions minimal and explain any new permission in `README.md`.

## Definition Of Done
- `npm test` passes from the project root.
- `npm run build` produces a Chrome-loadable `dist/` directory.
- `dist/manifest.json`, `dist/popup.html`, `dist/background.js`, and `dist/content.js` all exist after the build.
- README is sufficient for a new user to load the unpacked extension in Chrome.

## Claude Assets
- Project-local skills live under `.claude/skills/`.
- Project-local hooks live under `.claude/hooks/`.
