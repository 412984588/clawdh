# Chrome Extension Kit

`Chrome Extension Kit` is Kit #4 in `Claude Code Project Kits`. It is a Manifest V3 + React + Vite starter for teams shipping browser automation, assistant overlays, and workflow helpers with Claude Code guidance embedded from day one.

## Runtime Requirement
- Node 18+

## Includes
- Manifest V3 extension shell
- React popup with storage-backed toggle state
- Background service worker with install bootstrapping and message handling
- Content script that marks the current page as extension-enabled
- Project-level `CLAUDE.md`
- Local Claude Code skills for scaffolding, feedback, and ship readiness
- Local hooks for test and build verification

## Quick Start
```bash
npm install
npm test
npm run build
```

After `npm run build`, open `chrome://extensions`, enable Developer mode, choose `Load unpacked`, and select the generated `dist/` directory.

## Project Layout
- `public/manifest.json` is the source of truth for the MV3 manifest
- `popup.html` and `src/popup/` power the React popup
- `src/background/service-worker.ts` owns install/setup events
- `src/content/content.ts` runs on matched pages
- `src/lib/storage.ts` wraps extension storage access
- `.claude/skills/` contains extension-specific workflow guidance

## Environment
The starter exposes these build-time variables:
- `VITE_EXTENSION_NAME`
- `VITE_DEFAULT_PROMPT`

Defaults are safe for local builds, so the extension can be built and loaded without editing `.env.example`.

## Claude Code Workflow
- Read `CLAUDE.md` before changing the manifest, permissions, or entrypoints.
- Use `.claude/skills/mvp-scaffold` before adding new extension surfaces or pages.
- Use `.claude/skills/feedback-loop` before wiring telemetry, feedback, or in-extension reporting.
- Use `.claude/skills/ship-checklist` before publishing or handing off the unpacked build.

## Verification
```bash
npm test
npm run typecheck
npm run build
```

Expected output after the build:
- `dist/manifest.json`
- `dist/popup.html`
- `dist/background.js`
- `dist/content.js`

Keep `CLAUDE.md`, `.env.example`, and `public/manifest.json` in sync whenever command surfaces or permissions change.
