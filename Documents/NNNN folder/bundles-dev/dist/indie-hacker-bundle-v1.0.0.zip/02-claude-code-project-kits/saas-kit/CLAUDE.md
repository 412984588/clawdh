# SaaS Kit — Claude Code Project Instructions

## Product Context
- This project is a starter for subscription SaaS products built with Next.js, Supabase, and Stripe.
- The default audience is a solo founder who needs authentication, billing, and a clean dashboard shell on day one.
- Keep the first shipped version small: landing page, pricing, dashboard shell, and integration-ready server helpers.

## Architecture Guardrails
- Frontend uses the Next.js App Router with server components by default.
- Supabase and Stripe helpers must fail lazily with actionable error messages when environment variables are missing.
- Do not hardcode secrets, callback URLs, or production identifiers in code.
- Prefer project-local `.claude/skills/` assets over generic global guidance when they apply.

## Commands
- Install dependencies: `npm install`
- Start development: `npm run dev`
- Run tests: `npm run test`
- Produce a production build: `npm run build`

## Claude Assets
- Local skills live in `.claude/skills/` and are the first source of guidance for auth, billing, and ship readiness.
- Local hooks live in `.claude/hooks/` and should be run before commit/push when you change app behavior.
- If global guidance conflicts with this kit, prefer the local assets in this project tree.

## Working Rules
- Before changing billing, auth, or onboarding flows, review `.claude/skills/stripe-setup`, `.claude/skills/auth-quick`, and `.claude/skills/ship-checklist`.
- Keep copy and layouts optimized for shipping speed, not enterprise complexity.
- New server utilities must include typed return values and predictable error messages.

## Definition Of Done
- The homepage, pricing page, and dashboard shell render without external credentials.
- The health route returns kit metadata.
- README and `.env.example` are enough for a new user to start the project locally.
