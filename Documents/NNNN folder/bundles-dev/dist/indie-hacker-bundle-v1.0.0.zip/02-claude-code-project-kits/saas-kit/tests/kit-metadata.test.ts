import assert from 'node:assert/strict';
import test from 'node:test';

import { SAAS_KIT_METADATA, getSaasKitIntegrations } from '../lib/kit-metadata.ts';

test('saas kit metadata exposes the expected slug', () => {
  assert.equal(SAAS_KIT_METADATA.slug, 'saas-kit');
});

test('saas kit integrations list contains three enabled foundations', () => {
  const integrations = getSaasKitIntegrations();

  assert.equal(integrations.length, 3);
  assert.ok(integrations.every((integration) => integration.enabled));
});
