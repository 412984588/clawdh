# SaaS Kit

`SaaS Kit` is Kit #1 in `Claude Code Project Kits`. It gives you a locally runnable Next.js SaaS starter with project-specific Claude Code guidance already embedded.

## Runtime Requirement
- Node 18+

## Includes
- Next.js 14 App Router project
- Supabase + Stripe helper modules
- Project-level `CLAUDE.md`
- Local Claude Code skills for auth, billing, and launch readiness
- Local hooks for `test` and `build`

## Quick Start
```bash
npm install
cp .env.example .env.local
npm run dev
```

Open `http://localhost:3000` after the dev server starts.

## Environment Variables
Only `NEXT_PUBLIC_APP_URL` is required for the starter shell. Supabase and Stripe values are optional until you wire up auth and billing.

## Claude Code Workflow
- Read `CLAUDE.md` before making major changes.
- Use `.claude/skills/auth-quick` when touching sign-in flows.
- Use `.claude/skills/stripe-setup` when adding subscriptions or checkout flows.
- Run `.claude/hooks/pre-commit.sh` before committing and `.claude/hooks/pre-push.sh` before pushing.

## Verification
```bash
npm run test
npm run build
```
