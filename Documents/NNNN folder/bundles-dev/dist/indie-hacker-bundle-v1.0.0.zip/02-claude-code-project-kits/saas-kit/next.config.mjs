import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const configRoot = dirname(fileURLToPath(import.meta.url));

/** @type {import('next').NextConfig} */
const nextConfig = {
  eslint: {
    ignoreDuringBuilds: true,
  },
  outputFileTracingRoot: configRoot,
};

export default nextConfig;
