import Stripe from 'stripe';

import { requireServerEnv } from '@/lib/env';

let cachedStripeClient: Stripe | null = null;

export function createStripeClient(): Stripe {
  if (cachedStripeClient) {
    return cachedStripeClient;
  }

  cachedStripeClient = new Stripe(requireServerEnv('STRIPE_SECRET_KEY'));
  return cachedStripeClient;
}
