export interface KitIntegration {
  name: string;
  enabled: boolean;
  reason: string;
}

export interface SaaSKitMetadata {
  slug: string;
  name: string;
  description: string;
}

export const SAAS_KIT_METADATA: SaaSKitMetadata = {
  slug: 'saas-kit',
  name: 'SaaS Kit',
  description: 'A Stripe-ready Next.js SaaS starter with Supabase helpers and project-local Claude Code guidance.',
};

export function getSaasKitIntegrations(): KitIntegration[] {
  return [
    {
      name: 'Supabase auth shell',
      enabled: true,
      reason: 'The project includes typed helpers and env placeholders for auth and data storage.',
    },
    {
      name: 'Stripe billing shell',
      enabled: true,
      reason: 'Stripe client helpers and pricing page placeholders are included for subscription flows.',
    },
    {
      name: 'Claude Code project guidance',
      enabled: true,
      reason: 'Project-local CLAUDE instructions, skills, and hooks ship inside the kit.',
    },
  ];
}
