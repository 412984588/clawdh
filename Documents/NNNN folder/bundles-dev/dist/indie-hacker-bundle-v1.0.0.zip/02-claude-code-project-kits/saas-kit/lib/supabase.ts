import { createClient, type SupabaseClient } from '@supabase/supabase-js';

import { requireServerEnv } from '@/lib/env';

export function createSupabaseAdminClient(): SupabaseClient {
  return createClient(
    requireServerEnv('NEXT_PUBLIC_SUPABASE_URL'),
    requireServerEnv('SUPABASE_SERVICE_ROLE_KEY'),
    {
      auth: {
        persistSession: false,
      },
    },
  );
}
