import { getMissingOptionalIntegrations } from '@/lib/env';

const onboardingSteps = [
  'Connect Supabase credentials',
  'Wire a Stripe price ID',
  'Replace demo copy with your product positioning',
  'Add your first authenticated page or API mutation',
];

export default function DashboardPage() {
  const missingIntegrations = getMissingOptionalIntegrations();

  return (
    <main className="mx-auto flex min-h-screen max-w-5xl flex-col gap-10 px-6 py-16">
      <header className="space-y-3">
        <p className="text-sm font-medium uppercase tracking-[0.2em] text-brand-700">Dashboard shell</p>
        <h1 className="text-4xl font-semibold tracking-tight">Your starter dashboard is ready for real data.</h1>
        <p className="text-lg text-slate-600">
          This page stays usable without secrets. Once you add Supabase and Stripe values, swap in live queries and subscription state.
        </p>
      </header>

      <section className="grid gap-6 md:grid-cols-[1.4fr_1fr]">
        <article className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
          <h2 className="text-xl font-semibold">Suggested first edits</h2>
          <ol className="mt-6 space-y-4 text-sm leading-6 text-slate-700">
            {onboardingSteps.map((step, index) => (
              <li key={step} className="flex gap-4">
                <span className="inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-brand-100 font-medium text-brand-700">
                  {index + 1}
                </span>
                <span>{step}</span>
              </li>
            ))}
          </ol>
        </article>

        <article className="rounded-3xl border border-slate-200 bg-slate-950 p-8 text-slate-50 shadow-sm">
          <h2 className="text-xl font-semibold">Integration status</h2>
          <ul className="mt-6 space-y-3 text-sm leading-6 text-slate-200">
            {missingIntegrations.map((item) => (
              <li key={item}>Missing: {item}</li>
            ))}
          </ul>
        </article>
      </section>
    </main>
  );
}
