import { NextResponse } from 'next/server';

import { SAAS_KIT_METADATA, getSaasKitIntegrations } from '@/lib/kit-metadata';

export function GET(): NextResponse {
  return NextResponse.json({
    status: 'ok',
    slug: SAAS_KIT_METADATA.slug,
    integrations: getSaasKitIntegrations(),
  });
}
