import { Button } from '@/components/ui/button';
import { SAAS_KIT_METADATA, getSaasKitIntegrations } from '@/lib/kit-metadata';

export default function HomePage() {
  const integrations = getSaasKitIntegrations();

  return (
    <main className="min-h-screen bg-gradient-to-b from-brand-50 via-white to-canvas">
      <section className="mx-auto flex max-w-6xl flex-col gap-10 px-6 py-24 lg:flex-row lg:items-center">
        <div className="max-w-2xl space-y-6">
          <p className="inline-flex rounded-full border border-brand-100 bg-white px-4 py-1 text-sm font-medium text-brand-700">
            Claude Code Project Kits · Kit #1
          </p>
          <h1 className="text-5xl font-semibold tracking-tight text-ink">
            Ship a subscription SaaS starter without assembling the stack from scratch.
          </h1>
          <p className="text-lg leading-8 text-slate-600">
            {SAAS_KIT_METADATA.description} You get a homepage, pricing flow shell, dashboard,
            Supabase and Stripe helpers, plus project-local Claude Code instructions and skills.
          </p>
          <div className="flex flex-wrap gap-4">
            <Button asChild href="/dashboard">
              Open dashboard shell
            </Button>
            <Button asChild href="/pricing" variant="secondary">
              Review pricing starter
            </Button>
          </div>
        </div>

        <div className="grid flex-1 gap-4 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="text-xl font-semibold">Prewired foundations</h2>
          {integrations.map((integration) => (
            <article
              key={integration.name}
              className="rounded-2xl border border-slate-200 bg-slate-50 p-4"
            >
              <div className="flex items-center justify-between">
                <h3 className="font-medium">{integration.name}</h3>
                <span className="rounded-full bg-brand-100 px-3 py-1 text-xs font-medium text-brand-700">
                  {integration.enabled ? 'Ready' : 'Needs env'}
                </span>
              </div>
              <p className="mt-2 text-sm leading-6 text-slate-600">{integration.reason}</p>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}
