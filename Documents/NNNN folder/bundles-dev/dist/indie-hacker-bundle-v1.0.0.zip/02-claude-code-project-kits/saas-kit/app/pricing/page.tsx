import { Button } from '@/components/ui/button';

const tiers = [
  {
    name: 'Starter',
    price: '$19',
    description: 'Launch a solo product with landing pages, auth scaffolding, and basic billing.',
  },
  {
    name: 'Growth',
    price: '$49',
    description: 'Add richer analytics, support automations, and advanced upgrade prompts.',
  },
  {
    name: 'Scale',
    price: '$99',
    description: 'White-label handoff materials and higher-touch onboarding flows.',
  },
];

export default function PricingPage() {
  return (
    <main className="mx-auto max-w-6xl px-6 py-20">
      <header className="max-w-2xl space-y-4">
        <p className="text-sm font-medium uppercase tracking-[0.2em] text-brand-700">Pricing shell</p>
        <h1 className="text-4xl font-semibold tracking-tight">Swap these tiers with your own plan logic.</h1>
        <p className="text-lg text-slate-600">
          The starter gives you a structure for public pricing, upgrade copy, and Stripe-ready placeholders.
        </p>
      </header>

      <section className="mt-12 grid gap-6 lg:grid-cols-3">
        {tiers.map((tier) => (
          <article key={tier.name} className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
            <h2 className="text-2xl font-semibold">{tier.name}</h2>
            <p className="mt-2 text-4xl font-semibold text-brand-700">{tier.price}</p>
            <p className="mt-4 min-h-24 text-sm leading-6 text-slate-600">{tier.description}</p>
            <Button className="mt-6 w-full">Connect Stripe checkout</Button>
          </article>
        ))}
      </section>
    </main>
  );
}
