import Link from 'next/link';
import type { AnchorHTMLAttributes, ButtonHTMLAttributes, ReactNode } from 'react';

type ButtonVariant = 'primary' | 'secondary';

interface BaseButtonProps {
  children: ReactNode;
  className?: string;
  variant?: ButtonVariant;
}

type ButtonAsButtonProps = BaseButtonProps &
  ButtonHTMLAttributes<HTMLButtonElement> & {
    asChild?: false;
  };

type ButtonAsLinkProps = BaseButtonProps &
  AnchorHTMLAttributes<HTMLAnchorElement> & {
    asChild: true;
    href: string;
  };

type ButtonProps = ButtonAsButtonProps | ButtonAsLinkProps;

function getClasses(variant: ButtonVariant, className?: string): string {
  const baseClasses =
    'inline-flex items-center justify-center rounded-full px-5 py-3 text-sm font-medium transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2';
  const variantClasses =
    variant === 'secondary'
      ? 'border border-slate-300 bg-white text-slate-900 hover:border-brand-500 hover:text-brand-700'
      : 'bg-brand-700 text-white hover:bg-brand-900';

  return [baseClasses, variantClasses, className].filter(Boolean).join(' ');
}

export function Button(props: ButtonProps) {
  const variant = props.variant ?? 'primary';
  const className = getClasses(variant, props.className);

  if (props.asChild) {
    const { asChild: _asChild, children, className: _className, variant: _variant, href, ...rest } =
      props;

    return (
      <Link className={className} href={href} {...rest}>
        {children}
      </Link>
    );
  }

  const { asChild: _asChild, children, className: _className, variant: _variant, ...rest } = props;

  return (
    <button className={className} type="button" {...rest}>
      {children}
    </button>
  );
}
