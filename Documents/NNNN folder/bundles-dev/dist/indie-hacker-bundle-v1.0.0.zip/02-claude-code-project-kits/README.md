# Claude Code Project Kits

Five runnable starter kits with project-local `CLAUDE.md`, local skills, and local hooks already embedded.

## Kits

| Kit | Runtime | Use Case |
|-----|---------|----------|
| `saas-kit` | Node 18+ | Next.js SaaS starter with Supabase and Stripe helpers |
| `api-kit` | Python 3.11+ | FastAPI + PostgreSQL + Docker API service |
| `cli-kit` | Python 3.11+ | Click + Rich terminal application |
| `chrome-ext-kit` | Node 18+ | Manifest V3 extension with React popup and service worker |
| `landing-kit` | Node 18+ | Next.js + Tailwind + MDX marketing site |

## Quick Start

Use `install.sh` to choose a kit and copy it into a new working directory:

```bash
./install.sh
```

Non-interactive usage:

```bash
./install.sh saas-kit ../my-saas
./install.sh api-kit ../my-api
```

The installer copies the selected kit without local build artifacts such as `node_modules`, `.venv`, `.next`, `dist`, or `__pycache__`.

## After Installation

- `saas-kit`, `chrome-ext-kit`, `landing-kit`: run `npm install`
- `api-kit`, `cli-kit`: create a Python 3.11+ virtualenv and install dependencies
- Read the copied `CLAUDE.md` before making changes

## Included Names

This bundle ships:
- SaaS Kit
- API Kit
- CLI Tool Kit
- Chrome Extension Kit
- Landing Kit

Every kit is self-contained and can be initialized with `install.sh`.
