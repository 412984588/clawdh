# Project Delivery SOP

> The step-by-step process for building and delivering AI automation workflows to clients.
> Follow this for every project to ensure consistent quality and professional handoffs.

---

## Overview: The 6-Stage Delivery Process

```
Stage 1: Plan → Stage 2: Build → Stage 3: Test → Stage 4: Demo → Stage 5: Fix → Stage 6: Handoff
```

---

## Stage 1 — Plan (Before You Write a Single Node)

### Step 1: Create the Workflow Architecture Document
For each workflow, document before building:

```markdown
## Workflow: [NAME]

**Trigger:** [What starts this workflow? Webhook / Schedule / Manual]
**Input data:** [What data comes in? Format? Source?]
**Processing steps:** [List every transformation step]
**Output:** [Where does data go? What happens as a result?]
**Error handling:** [What happens if step 2 fails? step 3?]
**Notifications:** [Who gets notified of success/failure?]
**Dependencies:** [External APIs, credentials, other workflows]
**Test scenarios:** [List 3+ test cases including edge cases]
```

### Step 2: Validate the Architecture with the Client
Send a brief architecture overview before building:
> "Before I build this, I want to confirm the logic is right. Here's exactly what Workflow 1 will do: [paste architecture]. Does this match your expectations?"

---

## Stage 2 — Build

### Step 3: Set Up the Workflow Scaffold
1. Create a new workflow in n8n
2. Name it clearly: `[CLIENT] — [Workflow Name] v1`
3. Add a sticky note at the top with:
   - Purpose
   - Trigger type
   - Created date
   - Dependencies
4. Add all credentials via n8n's Credential Store (never hardcode)

### Step 4: Build Node by Node
Work from left to right (trigger → process → output):

**Order of operations:**
1. Add the trigger node first
2. Add the final output node (email, Slack, CRM update, etc.)
3. Fill in the middle nodes
4. Connect everything
5. Add error handling to each critical node
6. Add a final "success notification" node

**At each node, ask:**
- What happens if this fails?
- What data am I passing to the next node?
- Is there a sensitive value that needs to be an env variable?

### Step 5: Add Error Handling
Every workflow needs an error handling branch:

```
[Main Flow]  →  [Success] → [Client Notification] → Done
     ↓
[On Error]   →  [Error Logger] → [Your Error Alert] → Manual review
```

Configure the error alert to notify YOU, not the client. Handle errors before they notice.

---

## Stage 3 — Test

### Step 6: Local Testing (3 successful runs required)
Before showing the client anything:

- [ ] Run the workflow manually 3 times with realistic test data
- [ ] All 3 runs complete without errors
- [ ] Output data is exactly as expected
- [ ] Test with edge cases:
  - [ ] What if input data is missing a field?
  - [ ] What if an API is slow (timeout)?
  - [ ] What if the same data is processed twice (idempotency)?
  - [ ] What if the data contains special characters or non-English text?

### Step 7: Integration Testing
Test the workflow with REAL data from the client's system (even just 1–2 real records):
- [ ] Trigger from the actual data source (not a test mock)
- [ ] Verify data arrives in the correct destination
- [ ] Confirm notifications are sent to the right people
- [ ] Confirm error handling triggers correctly when you force an error

### Step 8: Performance Check
- [ ] Workflow completes in a reasonable time (< 30 seconds for simple flows)
- [ ] No runaway loops (add an execution timeout)
- [ ] Memory usage is normal (not loading large files unnecessarily)

---

## Stage 4 — Demo

### Step 9: Record a Loom Video (Before the Call)
Record a 3–5 minute Loom walkthrough:
1. Show the trigger point ("Here's where it starts...")
2. Walk through each node visually
3. Show a live run with real data
4. Show the output (the email, Slack message, CRM record, etc.)

**Subject line when sending:** "Workflow 1 is ready — here's a quick demo"

### Step 10: Schedule the Demo Call
Live call agenda:
1. Watch the Loom together (if they haven't seen it)
2. Have the CLIENT trigger the workflow themselves
3. Watch the output arrive together
4. Answer questions
5. Get verbal approval to move to the next workflow

**The magic moment:** When the client triggers the workflow and sees it work for the first time, they become advocates. Don't skip this step.

---

## Stage 5 — Fix & Iterate

### Step 11: Capture and Prioritize Feedback
After the demo, email a feedback summary within 2 hours:

```
Subject: [PROJECT NAME] — feedback recap and next steps

Hi [CLIENT NAME],

Thanks for the demo time today! Here's what I'm addressing:

CHANGES TO WORKFLOW 1:
- [ ] [Change 1 — description and expected timeline]
- [ ] [Change 2 — description and expected timeline]

IN SCOPE (included in original price): Changes 1–2
OUT OF SCOPE (additional cost): None / [Change X at $Y]

Updated timeline: Workflow 2 now live by [DATE].

[YOUR NAME]
```

### Step 12: Implement Changes (Max 2 Rounds of Revision)
- **Round 1:** Address all feedback
- **Round 2:** Address any remaining issues
- **Round 3+:** If changes exceed 2 rounds, assess whether scope has expanded:
  > "We've done two rounds of revision, which is included. This next request [DESCRIPTION] is outside the original scope. I can handle it for an additional $[PRICE]. Want to proceed?"

---

## Stage 6 — Handoff

### Step 13: Prepare Handoff Documentation
Fill out the handoff documentation template (`handoff-documentation-template.md`).
This is the document the client will keep forever. Make it excellent.

### Step 14: Training Session
Schedule a 60-minute training call:

**Agenda:**
1. **Walk through each workflow** (20 min): Show how each triggers, what it does, what the output looks like
2. **Teach them how to monitor** (10 min): Where to see if workflows are running, how to see execution history
3. **Show how to trigger manually** (5 min): In case they need to re-run something
4. **Error scenarios** (10 min): What they'll see if something breaks, what to do
5. **Q&A** (15 min): Open floor

**Record the training session** and share the recording.

### Step 15: Final Handoff Email

```
Subject: [PROJECT NAME] — Project Complete! 🎉

Hi [CLIENT NAME],

Your automation system is live and running. Here's your handoff package:

📄 Documentation: [LINK]
📹 Training recording: [LINK]
⚙️ n8n access: [URL] (your login)

YOUR SYSTEM AT A GLANCE:
• Workflow 1 [NAME]: [One-line description of what it does now]
• Workflow 2 [NAME]: [One-line description of what it does now]
• Workflow 3 [NAME]: [One-line description of what it does now]

30-DAY SUPPORT:
You have 30 days of free support from today ([DATE] – [DATE]).
For questions or issues, email [EMAIL] or message me on [SLACK/WHATSAPP].

WHAT HAPPENS AFTER DAY 30:
Support continues at $[HOURLY_RATE]/hr, or you can roll into my [RETAINER PLAN NAME] retainer at $[RETAINER]/month (includes monitoring, fixes, and 1 new workflow per month).

I've loved working on this with you. If you have a colleague or friend who could benefit from automation, I'd really appreciate an introduction.

[YOUR NAME]
```

---

## Delivery Quality Gates

| Gate | Criteria |
|------|----------|
| Build complete | Workflow runs 3× without errors |
| Test passed | Edge cases verified, error handling confirmed |
| Demo approved | Client has given verbal or written approval |
| Documentation done | Handoff doc is complete and reviewed |
| Training complete | Client has triggered each workflow themselves |
| Final handoff sent | Email sent with all links and support terms |
