# Handoff Template

Use this document when the workflow goes live.

---

## Workflow Summary

- Workflow name:
- Business owner:
- Technical owner:
- Launch date:
- Primary KPI:

## What the Automation Does

Describe the trigger, steps, and final outputs in plain English.

## Systems and Credentials

List every tool touched and who owns the credential.

## Exception Handling

- What happens on API failure?
- Who gets alerted?
- What manual fallback exists?

## Recommended Next Improvements

1. ...
2. ...
3. ...

## Support Window

State how long launch support is included and how issues should be reported.
