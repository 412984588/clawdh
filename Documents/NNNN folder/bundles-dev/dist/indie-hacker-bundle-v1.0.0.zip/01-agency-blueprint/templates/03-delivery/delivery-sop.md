# Delivery SOP — From Kickoff to Stable Launch

This SOP exists so every project feels boring in the best sense: clear owners, visible milestones, tight feedback loops, and no surprises at the end. The fastest way to lose trust in automation work is to let the build disappear into a black box. Clients do not need daily noise, but they do need confidence that the workflow is moving from kickoff to launch with discipline.

## 1. After Kickoff

Within one business day of the kickoff call, send the written workflow specification. It should describe trigger, logic, systems touched, expected outputs, exception paths, and the single KPI that defines success. Ask for written approval before building. This step protects scope and prevents "small" requests from quietly bloating the project.

## 2. Build in Milestones

Split delivery into visible milestones:
- access and data validation
- core workflow logic
- exception handling
- reporting and alerts
- staging review
- production launch

Every milestone should end with a short note: what changed, what is blocked, and what the client needs to confirm. If a dependency slips, surface it immediately. Silence kills momentum faster than bad news.

## 3. QA Before Handoff

Test with real examples, broken examples, and edge cases. Trigger the workflow multiple times, document what happens when APIs fail, and verify who gets notified. A workflow that works only on the happy path is not ready for handoff.

## 4. Launch and Handoff

Launch during an agreed window, monitor the first live runs, then deliver the handoff packet: workflow summary, credentials map, escalation path, and recommended next improvements. The client should know exactly what was shipped, how to judge success, and who owns the system after launch.
