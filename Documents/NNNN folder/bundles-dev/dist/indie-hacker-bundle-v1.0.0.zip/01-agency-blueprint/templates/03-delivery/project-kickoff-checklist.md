# Project Kickoff Checklist

> Complete all items within 48 hours of receiving the signed contract and first payment.
> A strong kickoff sets the tone for the entire project.

---

## Immediately After Contract Signed (Hour 0–2)

- [ ] Send payment invoice (if not already paid)
- [ ] Send kickoff confirmation email (template below)
- [ ] Create a new folder in your project management tool: `[CLIENT_NAME] — [PROJECT_NAME]`
- [ ] Add key dates to your calendar:
  - [ ] Kickoff call scheduled
  - [ ] Week 2 check-in scheduled
  - [ ] Delivery date
  - [ ] 30-day support window end date
- [ ] Create a client folder in your file storage (Google Drive / Notion / Dropbox)

---

## Kickoff Confirmation Email Template

**Subject:** We're official — kickoff details for [PROJECT NAME]

---

Hi [CLIENT NAME],

Fantastic — we're official! I'm looking forward to building this for you.

Here's what happens next:

**Step 1: Send me access credentials**
I'll need the following to get started (please send via a secure method like 1Password or Bitwarden Send):
- [LIST SPECIFIC CREDENTIALS NEEDED — e.g., "n8n API key", "HubSpot API key", "Gmail app password"]

**Step 2: Kickoff call**
We're confirmed for [DATE] at [TIME]. Agenda:
- Review the project scope (30 min)
- Confirm data flows and edge cases (10 min)
- Set up communication channels (5 min)

Join here: [CALENDAR LINK / ZOOM LINK]

**Step 3: First workflow goes live**
Target: [DATE], 7 days from today.

**Questions or concerns before the call?**
Reply here or reach me at [EMAIL/SLACK].

Excited to get started,
[YOUR NAME]

---

## Before the Kickoff Call (24 hours before)

- [ ] Re-read the proposal and scope of work
- [ ] Draft a list of clarifying questions you still have
- [ ] Prepare a simple project overview document (1 page) with:
  - Project goal
  - 3 workflows to be built
  - Timeline
  - How you'll communicate updates
- [ ] Set up your n8n environment for this client:
  - [ ] Create a new n8n workspace or folder
  - [ ] Set up environment variable storage
  - [ ] Test API connectivity for their main tools

---

## During the Kickoff Call

**Agenda to cover:**

1. **Confirm the scope** (5 min)
   > "Before we dive in, let me confirm what we're building together: [summarize proposal]. Does this still match your expectations?"

2. **Map the data flows** (15 min)
   > "Let's trace exactly where data enters each workflow and where it ends up. For Workflow 1: [walk through step by step]."

3. **Identify edge cases** (10 min)
   > "What happens if [common failure scenario]? Should we send an alert, skip it, or log it?"

4. **Set communication norms** (5 min)
   > "How do you prefer to get updates — email, Slack, or a shared doc? I'll send weekly progress updates every Friday."

5. **Confirm access and credentials** (5 min)
   > "I need [LIST] to get started. The fastest way to share these securely is [METHOD]. Can you send those today?"

6. **Confirm success criteria** (5 min)
   > "When we're done, how will you know this was a success? What does 'working perfectly' look like to you?"

---

## After the Kickoff Call (Within 2 hours)

- [ ] Send a kickoff call summary email (template below)
- [ ] Log client details in your project management tool:
  - Primary contact + email
  - Secondary contact (if any)
  - Preferred communication channel
  - Agreed success criteria
  - Timeline milestones
- [ ] Begin building Workflow 1

---

## Kickoff Call Summary Email Template

**Subject:** Kickoff call recap — [PROJECT NAME]

---

Hi [CLIENT NAME],

Great call today! Here's a quick summary so we're aligned:

**What we're building:**
1. [Workflow 1 name + one-line description]
2. [Workflow 2 name + one-line description]
3. [Workflow 3 name + one-line description]

**Timeline:**
- Workflow 1 live: [DATE]
- Workflow 2 live: [DATE]
- Full system live: [DATE]
- Training + handoff: [DATE]

**You need to send me:**
- [ ] [Credential 1]
- [ ] [Credential 2]

**How we'll communicate:**
- Weekly updates every Friday via [EMAIL/SLACK]
- For urgent questions: [CONTACT METHOD]

**Success looks like:**
"[Repeat the success criteria the client described]"

I'll have the first workflow ready for your review by [DATE].

[YOUR NAME]

---

## Ongoing Communication Cadence

| Check-in | Frequency | Format |
|----------|-----------|--------|
| Progress update | Weekly (every Friday) | Short email or Slack message |
| Workflow demo | Per workflow completion | Video call or Loom video |
| Issue notifications | As needed | Email or Slack |
| Final handoff | End of project | Video call + written documentation |
