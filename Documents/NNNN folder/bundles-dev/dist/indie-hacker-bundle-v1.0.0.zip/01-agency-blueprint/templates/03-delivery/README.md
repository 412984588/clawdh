# 03 — Delivery

> Delivery discipline is how you turn a one-off project into repeatable revenue and referrals.

---

## Contents

| File | Purpose |
|------|---------|
| `kickoff-checklist.md` | Pre-build checklist for access, owners, KPIs, and launch constraints |
| `client-onboarding-sop.md` | Step-by-step onboarding flow after a deal is signed |
| `delivery-sop.md` | Build, QA, launch, and support process |
| `handoff-template.md` | Final documentation packet for the client |

---

## Delivery Principle

Ship one workflow that works reliably in the client's real environment. Do not overbuild on day one.
