# Kickoff Checklist

Use this before touching the workflow builder.

---

## Stakeholders

- [ ] Executive sponsor identified
- [ ] Day-to-day operator identified
- [ ] Technical contact identified
- [ ] Approval path for launch changes confirmed

## Inputs

- [ ] Source systems listed
- [ ] Destination systems listed
- [ ] Required credentials requested
- [ ] Sample records collected
- [ ] Success metric defined

## Constraints

- [ ] Business hours and time zone confirmed
- [ ] Error escalation path documented
- [ ] Compliance or security limits noted
- [ ] Go-live window agreed

## Build Hygiene

- [ ] Staging path available
- [ ] Naming convention agreed
- [ ] Rollback plan written
- [ ] Client communication cadence scheduled
