# Client Onboarding SOP

This SOP starts the moment the agreement is signed.

---

## Day 0

1. Send welcome email with kickoff scheduler link.
2. Request systems access and example data.
3. Share a simple intake form for workflow details, approvers, and exception cases.

## Day 1

1. Run the kickoff call.
2. Confirm the target workflow, KPI, and launch deadline.
3. Walk through current process step by step.
4. Agree on the communication channel for status updates.

## Day 2

1. Publish the written workflow spec.
2. Get written approval on scope.
3. Create the build board with milestones, owners, and risks.

## Rules

- No build work before access is confirmed.
- No launch without explicit owner sign-off.
- Every open question must have a named owner and due date.
