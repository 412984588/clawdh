# Non-Disclosure Agreement (NDA)

> ⚠️ **DISCLAIMER**: This template is provided for reference purposes only and does not constitute legal advice.
> Consult a licensed attorney in your jurisdiction before using this document.

---

# MUTUAL NON-DISCLOSURE AGREEMENT

**This Agreement** is entered into as of {{DATE}} by and between:

**Party A:**
{{YOUR_FULL_NAME OR COMPANY NAME}}
{{YOUR_ADDRESS}}
Email: {{YOUR_EMAIL}}
("Disclosing Party A")

**Party B:**
{{CLIENT_COMPANY_NAME}}
{{CLIENT_ADDRESS}}
Represented by: {{CLIENT_REPRESENTATIVE_NAME}}, {{CLIENT_REPRESENTATIVE_TITLE}}
Email: {{CLIENT_EMAIL}}
("Disclosing Party B")

(Each party may be referred to individually as a "Party" and collectively as the "Parties.")

---

## Purpose

The Parties wish to explore a potential business relationship involving AI automation services (the "Purpose"). In connection with the Purpose, each Party may disclose to the other certain confidential information. This Agreement governs the treatment of that information.

---

## 1. Definition of Confidential Information

**1.1** "Confidential Information" means any non-public information disclosed by one Party ("Disclosing Party") to the other Party ("Receiving Party"), whether disclosed orally, in writing, or by any other means, that:
- Is designated as "Confidential" or "Proprietary" at the time of disclosure, or
- A reasonable person would understand to be confidential given the nature of the information and the circumstances of disclosure.

**1.2** Confidential Information includes, but is not limited to: business plans, financial data, customer lists, technical specifications, software code, workflow designs, automation logic, pricing information, and trade secrets.

**1.3** Confidential Information does NOT include information that:
(a) Is or becomes publicly available through no fault of the Receiving Party;
(b) Was rightfully known to the Receiving Party before disclosure, without restriction;
(c) Is independently developed by the Receiving Party without use of Confidential Information;
(d) Is received from a third party without restriction on disclosure; or
(e) Is required to be disclosed by applicable law or court order, provided the Receiving Party gives the Disclosing Party reasonable prior notice.

---

## 2. Obligations of Receiving Party

**2.1** The Receiving Party agrees to:
(a) Keep all Confidential Information strictly confidential;
(b) Not disclose Confidential Information to any third party without prior written consent of the Disclosing Party;
(c) Use Confidential Information solely for the Purpose described in this Agreement;
(d) Protect Confidential Information using at least the same degree of care it uses to protect its own confidential information, but no less than reasonable care;
(e) Limit disclosure of Confidential Information to its employees, contractors, and advisors who have a need to know for the Purpose and who are bound by confidentiality obligations at least as protective as this Agreement.

**2.2** The Receiving Party shall promptly notify the Disclosing Party upon discovery of any unauthorized disclosure or use of Confidential Information.

---

## 3. Term

**3.1** This Agreement shall remain in effect for **2 (two) years** from the Effective Date, unless terminated earlier by mutual written agreement.

**3.2** Confidentiality obligations with respect to information disclosed during the term shall survive for an additional **3 (three) years** after the expiration or termination of this Agreement.

---

## 4. Return or Destruction of Information

Upon request by the Disclosing Party, or upon termination of this Agreement, the Receiving Party shall promptly:
(a) Return all tangible materials containing Confidential Information; or
(b) Certify in writing the destruction of all such materials.

---

## 5. No License

Nothing in this Agreement grants either Party any rights in the other Party's Confidential Information except as expressly set forth herein. No license under any patent, trademark, copyright, or other intellectual property right is granted or implied.

---

## 6. No Obligation

This Agreement does not obligate either Party to proceed with the Purpose or enter into any further agreement.

---

## 7. Remedies

**7.1** The Parties acknowledge that unauthorized disclosure of Confidential Information could cause irreparable harm for which monetary damages would be an inadequate remedy.

**7.2** Accordingly, the Disclosing Party shall be entitled to seek equitable relief, including injunction and specific performance, in addition to all other remedies available at law or in equity.

---

## 8. Governing Law

This Agreement shall be governed by the laws of {{STATE/PROVINCE, COUNTRY}}, without regard to its conflict of laws principles.

---

## 9. General

**9.1 Entire Agreement.** This Agreement constitutes the entire agreement between the Parties with respect to the subject matter hereof.

**9.2 Amendments.** No modification of this Agreement shall be effective unless in writing and signed by both Parties.

**9.3 Severability.** If any provision of this Agreement is held unenforceable, the remaining provisions shall remain in full force.

**9.4 Counterparts.** This Agreement may be executed in counterparts, each of which shall be an original. Electronic signatures are acceptable.

---

## Signatures

**PARTY A:**

Signature: ___________________________

Name: {{YOUR_FULL_NAME}}

Date: _______________________________

---

**PARTY B:**

Signature: ___________________________

Name: {{CLIENT_REPRESENTATIVE_NAME}}

Title: {{CLIENT_REPRESENTATIVE_TITLE}}

Company: {{CLIENT_COMPANY_NAME}}

Date: _______________________________
