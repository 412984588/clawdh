# Freelance Service Agreement

> ⚠️ **DISCLAIMER**: This template is provided for reference purposes only and does not constitute legal advice.
> Consult a licensed attorney in your jurisdiction before using this document.
> Laws governing independent contractor agreements vary significantly by country and state/province.

---

# FREELANCE SERVICES AGREEMENT

**This Agreement** is entered into as of {{DATE}} ("Effective Date") by and between:

**Service Provider:**
{{YOUR_FULL_NAME OR COMPANY NAME}}
{{YOUR_ADDRESS}}
Email: {{YOUR_EMAIL}}
("Contractor")

**Client:**
{{CLIENT_COMPANY_NAME}}
{{CLIENT_ADDRESS}}
Represented by: {{CLIENT_REPRESENTATIVE_NAME}}, {{CLIENT_REPRESENTATIVE_TITLE}}
Email: {{CLIENT_EMAIL}}
("Client")

---

## 1. Services

**1.1** Contractor agrees to provide the services described in the attached Scope of Work ("SOW"), which is incorporated into this Agreement by reference.

**1.2** The SOW describes the specific deliverables, timeline, and acceptance criteria for the project. Any changes to the SOW must be agreed upon in writing by both parties.

**1.3** Contractor shall perform the services in a professional manner consistent with industry standards.

---

## 2. Compensation & Payment

This section defines the commercial **payment terms** for the engagement, including deposit timing, invoice due dates, and late-payment remedies.

**2.1 Project Fee.** Client agrees to pay Contractor the total fee specified in the SOW: **${{TOTAL_PRICE}} USD**.

**2.2 Payment Schedule.**
- **Deposit (50%):** ${{DEPOSIT_AMOUNT}} due upon signing this Agreement
- **Final Payment (50%):** ${{FINAL_AMOUNT}} due upon delivery and client acceptance of all deliverables

**2.3 Invoice Terms.** All invoices are due within **7 calendar days** of receipt.

**2.4 Late Payments.** Payments received more than 14 days late will incur a late fee of 1.5% per month on the outstanding balance.

**2.5 Work Suspension.** If payment is more than 14 days overdue, Contractor reserves the right to suspend work until payment is received in full.

---

## 3. Timeline

**3.1** Contractor shall complete the services according to the timeline specified in the SOW.

**3.2** Timeline is contingent on Client providing timely access, feedback, and approvals as requested. Delays caused by Client will extend the project timeline accordingly, with no penalty to Contractor.

---

## 4. Revisions

**4.1** This Agreement includes up to **2 (two) rounds of revisions** per deliverable.

**4.2** Additional revision rounds are available at Contractor's standard hourly rate of **${{HOURLY_RATE}} USD/hour**, invoiced separately.

---

## 5. Intellectual Property

**5.1 Ownership Upon Payment.** Upon receipt of full payment, Client shall own all rights, title, and interest in the deliverables created specifically for Client under this Agreement.

**5.2 Contractor's Tools and IP.** Contractor retains all rights to pre-existing tools, frameworks, methodologies, and general-purpose automation components not created specifically for Client.

**5.3 Portfolio Rights.** Contractor may reference the project type and scope (but not confidential Client details) in Contractor's portfolio and marketing materials.

---

## 6. Confidentiality

**6.1** Each party agrees to keep the other party's Confidential Information confidential and not to disclose it to any third party without prior written consent.

**6.2** Confidentiality obligations survive termination of this Agreement for a period of **3 (three) years**.

---

## 7. Independent Contractor Status

**7.1** Contractor is an independent contractor, not an employee of Client. Contractor is responsible for all taxes and insurance arising from Contractor's self-employment.

**7.2** Contractor has the right to perform services for other clients during the term of this Agreement, provided such work does not create a conflict of interest.

---

## 8. Warranties and Representations

**8.1** Contractor warrants that the deliverables will substantially conform to the specifications in the SOW, and that Contractor has the right to enter into this Agreement.

**8.2** EXCEPT AS EXPRESSLY STATED IN THIS SECTION, THE SERVICES ARE PROVIDED "AS IS" WITHOUT ANY OTHER WARRANTIES.

---

## 9. Limitation of Liability

**9.1** IN NO EVENT SHALL EITHER PARTY BE LIABLE TO THE OTHER FOR ANY INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS.

**9.2** Contractor's total liability under this Agreement shall not exceed the total fees paid by Client in the 3 months preceding the claim.

---

## 10. Termination

**10.1 Termination by Client.** Client may terminate this Agreement at any time with 7 days written notice. Client will pay for all work completed to the date of termination, with a minimum of the deposit amount.

**10.2 Termination by Contractor.** Contractor may terminate this Agreement with 14 days written notice if Client fails to pay an invoice within 30 days of the due date.

**10.3 Effect of Termination.** Upon termination, each party will return or destroy the other party's Confidential Information. Deliverables completed and paid for will transfer to Client.

---

## 11. Dispute Resolution

**11.1** The parties agree to attempt to resolve any dispute through good-faith negotiation before pursuing other remedies.

**11.2** This Agreement shall be governed by the laws of {{STATE/PROVINCE, COUNTRY}}.

---

## 12. General Provisions

**12.1 Entire Agreement.** This Agreement, including the attached SOW, constitutes the entire agreement between the parties.

**12.2 Amendments.** No amendment to this Agreement shall be effective unless in writing and signed by both parties.

**12.3 Severability.** If any provision of this Agreement is found unenforceable, the remainder of the Agreement continues in full force.

---

## Signatures

**CONTRACTOR:**

Signature: ___________________________

Name: {{YOUR_FULL_NAME}}

Date: _______________________________

---

**CLIENT:**

Signature: ___________________________

Name: {{CLIENT_REPRESENTATIVE_NAME}}

Title: {{CLIENT_REPRESENTATIVE_TITLE}}

Company: {{CLIENT_COMPANY_NAME}}

Date: _______________________________
