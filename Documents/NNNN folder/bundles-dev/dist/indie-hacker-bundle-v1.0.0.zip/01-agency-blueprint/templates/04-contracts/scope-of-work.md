# Scope of Work Template

> This document attaches to and forms part of the Freelance Service Agreement.
> Complete all sections before sending to the client for signature.

---

# SCOPE OF WORK

**Project Name:** {{PROJECT_NAME}}
**SOW Number:** {{SOW_001}}
**Effective Date:** {{DATE}}
**Attached to:** Freelance Service Agreement dated {{AGREEMENT_DATE}}

**Contractor:** {{YOUR_NAME / COMPANY}}
**Client:** {{CLIENT_COMPANY}}

---

## 1. Project Overview

**Business Objective:**
{{One paragraph describing what the client is trying to achieve. Focus on business outcomes, not technical details.}}

**Problem Being Solved:**
{{Describe the current manual process or pain point that this automation will address. Be specific.}}

**Success Criteria:**
The project will be considered successfully delivered when:
1. {{Measurable criterion #1 — e.g., "Lead form submissions are automatically added to HubSpot within 60 seconds"}}
2. {{Measurable criterion #2 — e.g., "Client receives a Slack notification for each new lead"}}
3. {{Measurable criterion #3 — e.g., "Failed runs trigger an email alert to contractor@email.com"}}

---

## 2. Deliverables

### Deliverable 1: {{WORKFLOW_1_NAME}}

**Description:** {{Plain-English description of what this workflow does}}

**Inputs:**
- Data source: {{WHERE DATA COMES FROM}}
- Trigger: {{WHAT STARTS THE WORKFLOW}}
- Required fields: {{LIST REQUIRED DATA FIELDS}}

**Processing:**
1. {{Step 1}}
2. {{Step 2}}
3. {{Step 3}}

**Outputs:**
- Destination: {{WHERE DATA GOES}}
- Format: {{EMAIL / SLACK / CRM RECORD / etc.}}
- Notification: {{WHO GETS NOTIFIED AND HOW}}

**Acceptance criteria:**
- [ ] Workflow runs successfully with live data
- [ ] Error handling triggers when [failure condition]
- [ ] Output matches specification in 3 consecutive test runs

---

### Deliverable 2: {{WORKFLOW_2_NAME}}

**Description:** {{Plain-English description}}

**Inputs:**
- Data source: {{SOURCE}}
- Trigger: {{TRIGGER}}

**Outputs:**
- Destination: {{DESTINATION}}

**Acceptance criteria:**
- [ ] Workflow runs successfully with live data
- [ ] Error handling is in place
- [ ] Client has verified output meets expectations

---

### Deliverable 3: {{WORKFLOW_3_NAME}}

**Description:** {{Plain-English description}}

**Inputs:**
- Data source: {{SOURCE}}
- Trigger: {{TRIGGER}}

**Outputs:**
- Destination: {{DESTINATION}}

**Acceptance criteria:**
- [ ] Workflow runs successfully with live data
- [ ] Error handling is in place
- [ ] Client has verified output meets expectations

---

### Additional Deliverables

- [ ] Handoff documentation (per `handoff-documentation-template.md`)
- [ ] 1-hour training session (recorded)
- [ ] n8n environment setup and configuration
- [ ] 30-day post-launch support (bug fixes and minor adjustments)

---

## 3. What Is NOT Included (Out of Scope)

The following are explicitly excluded from this project and would require a separate SOW and pricing:

- Any workflows or integrations not listed in Section 2
- Custom frontend UI or web application development
- Data cleanup, data migration, or database administration
- {{SPECIFIC EXCLUSION RELEVANT TO THIS PROJECT}}
- Ongoing support beyond the 30-day post-launch window
- Training or onboarding for more than {{N}} team members
- Changes to third-party tools, platforms, or APIs not in Contractor's control

---

## 4. Client Responsibilities

For the project to succeed, Client agrees to:

- [ ] Provide all required API credentials and system access within **3 business days** of signing
- [ ] Designate a single point of contact for this project: {{CLIENT_POC_NAME}}
- [ ] Respond to questions and feedback requests within **2 business days**
- [ ] Attend scheduled review calls (no cancellations less than 24 hours in advance)
- [ ] Provide a staging/test environment or confirm testing on production is acceptable
- [ ] Provide sample or test data for workflow testing
- [ ] Sign off on each workflow before Contractor proceeds to the next

**Note:** Delays caused by Client failure to meet these responsibilities will extend the project timeline proportionally.

---

## 5. Timeline and Milestones

| Milestone | Description | Target Date | Owner |
|-----------|-------------|-------------|-------|
| Contract signed | Agreement + SOW signed, deposit paid | {{DATE}} | Both |
| Kickoff call | Credentials, access, data flows confirmed | {{DATE}} | Both |
| Workflow 1 demo | First workflow live and demonstrated | {{DATE}} | Contractor |
| Workflow 1 approved | Client sign-off on Workflow 1 | {{DATE}} | Client |
| Workflow 2 demo | Second workflow live and demonstrated | {{DATE}} | Contractor |
| Workflow 3 demo | Third workflow live and demonstrated | {{DATE}} | Contractor |
| Full system testing | All workflows tested end-to-end | {{DATE}} | Contractor |
| Training session | 1-hour team training, session recorded | {{DATE}} | Both |
| Final handoff | Documentation delivered, project closed | {{DATE}} | Contractor |
| Support window ends | 30-day support period closes | {{DATE}} | — |

---

## 6. Tools and Technology

**Platform:** n8n ({{HOSTED ON CLIENT'S SERVER / n8n Cloud / Contractor's Server}})

**Integrations required:**
| Tool | Purpose | API Version |
|------|---------|-------------|
| {{TOOL_1}} | {{PURPOSE}} | {{API v.X}} |
| {{TOOL_2}} | {{PURPOSE}} | {{API v.X}} |
| {{TOOL_3}} | {{PURPOSE}} | {{API v.X}} |

**AI/LLM services (if applicable):**
| Service | Purpose | Cost responsibility |
|---------|---------|-------------------|
| {{OpenAI / Claude / etc.}} | {{TEXT_CLASSIFICATION / etc.}} | {{Client pays API costs}} |

---

## 7. Pricing

| Line Item | Amount |
|-----------|--------|
| Workflow 1 — {{NAME}} | ${{PRICE}} |
| Workflow 2 — {{NAME}} | ${{PRICE}} |
| Workflow 3 — {{NAME}} | ${{PRICE}} |
| n8n setup and configuration | Included |
| Training session (1 hour) | Included |
| Handoff documentation | Included |
| 30-day post-launch support | Included |
| **Total Project Fee** | **${{TOTAL_PRICE}}** |

**Payment schedule:**
- 50% deposit (${{DEPOSIT}}) due upon signing
- 50% final payment (${{FINAL}}) due upon delivery of all deliverables

---

## 8. Change Request Process

Any change to this SOW must follow this process:

1. Either party submits a written Change Request describing the proposed change
2. Contractor provides a written estimate of time and cost impact within 3 business days
3. Both parties sign the Change Request to authorize it
4. Timeline and cost are adjusted accordingly

Work on changes does not begin until the Change Request is signed.

---

## 9. Signatures

By signing, both parties agree to the scope, timeline, and terms described in this document.

---

**CONTRACTOR:**

Signature: ___________________________

Name: {{YOUR_FULL_NAME}}

Date: _______________________________

---

**CLIENT:**

Signature: ___________________________

Name: {{CLIENT_REPRESENTATIVE_NAME}}

Title: {{CLIENT_REPRESENTATIVE_TITLE}}

Company: {{CLIENT_COMPANY_NAME}}

Date: _______________________________
