# 04 — Contracts

> These templates are starting points, not jurisdiction-specific legal advice. Review with counsel before production use.

---

## Contents

| File | Purpose |
|------|---------|
| `freelance-service-agreement.md` | Core commercial agreement for implementation work |
| `mutual-nda-template.md` | Basic confidentiality agreement |
| `scope-of-work-template.md` | Attachment that defines project boundaries and deliverables |

---

## Use Pattern

1. Finalize pricing and commercial model.
2. Attach the scope of work.
3. Use the NDA only if confidential internal data will be shared before contracting.
