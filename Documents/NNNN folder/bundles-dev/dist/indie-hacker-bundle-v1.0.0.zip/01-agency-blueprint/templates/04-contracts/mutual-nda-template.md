# Mutual NDA Template

This mutual non-disclosure agreement is entered into between `[PARTY A]` and `[PARTY B]` as of `[DATE]`.

## Purpose

The parties intend to discuss a possible business relationship involving automation systems, workflows, internal processes, and related commercial information.

## Confidential Information

Confidential information includes non-public business, technical, financial, operational, and customer information disclosed in any form. It does not include information that is public, already known without duty of confidentiality, independently developed, or lawfully received from a third party.

## Obligations

Each party agrees to:
- use confidential information only for the stated purpose
- restrict access to people who need to know
- protect the information with reasonable care
- not disclose it without written permission

## Term

This agreement remains in effect for two years from the effective date. Confidentiality obligations survive for three years after disclosure unless local law requires a longer term.

## Return or Destruction

Upon request, each party will return or destroy confidential materials, except for archival copies retained for legal compliance.
