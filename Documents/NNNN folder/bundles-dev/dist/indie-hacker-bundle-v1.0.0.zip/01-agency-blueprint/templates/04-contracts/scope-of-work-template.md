# Scope of Work Template

## Project

- Client:
- Project name:
- Effective date:
- Project owner:

## Objective

Describe the operational problem being solved and the business outcome expected.

## Included Deliverables

1. Workflow design
2. Build and QA
3. Documentation and handoff
4. Launch support for `[X]` business days

## Exclusions

List anything not included to protect margin and clarity.

## Timeline

| Milestone | Owner | Target Date |
|-----------|-------|-------------|
| Kickoff | | |
| Staging review | | |
| Launch | | |
| Handoff | | |

## Fees

- Project fee:
- Optional monthly support:
- Payment schedule:

## Acceptance

State exactly how the client approves the work.
