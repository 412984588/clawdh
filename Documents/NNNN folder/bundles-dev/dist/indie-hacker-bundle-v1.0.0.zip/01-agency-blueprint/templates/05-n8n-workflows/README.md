# 05 — n8n Workflow Templates

> 18 production-ready n8n workflow JSON files for AI automation agency operations.
> Import directly into n8n: Workflows → Import from file → select the JSON.

---

## Contents

| File | Purpose | Tier |
|------|---------|------|
| `client-lead-capture.json` | Capture inbound leads from web forms → CRM + Slack alert | Pro+ |
| `project-status-reporter.json` | Weekly project status email to client | Pro+ |
| `invoice-automation.json` | Auto-generate and send invoices on project completion | Pro+ |
| `client-feedback-collector.json` | Post-project feedback survey automation | Pro+ |
| `monthly-report-generator.json` | Pull metrics + generate PDF-ready monthly report | Pro+ |
| `onboarding-email-automation.json` | Trigger welcome email sequence on contract signing | Pro+ |
| `proposal-follow-up.json` | Auto follow-up on sent proposals after 3 days | Pro+ |
| `client-portal-notifier.json` | Notify client when deliverables are uploaded | Pro+ |
| `upsell-trigger.json` | Detect upsell opportunities based on client activity | Pro+ |
| `churn-prevention-alert.json` | Flag at-risk clients based on engagement signals | Pro+ |
| `discovery-call-booking.json` | Send intake data to calendar and notify the delivery team | Pro+ |
| `invoice-follow-up.json` | Chase overdue invoices with reminder sequences and status flags | Pro+ |
| `lead-enrichment-pipeline.json` | Enrich inbound leads before outreach or qualification | Pro+ |
| `onboarding-kickoff.json` | Launch client kickoff tasks after contract signature | Pro+ |
| `support-escalation-router.json` | Route high-priority support requests to the right owner | Pro+ |
| `testimonial-request.json` | Request social proof after successful delivery milestones | Pro+ |
| `upsell-opportunity-alert.json` | Score expansion signals and notify account managers | Pro+ |
| `weekly-client-report.json` | Generate recurring weekly update summaries for clients | Pro+ |

---

## Prerequisites

- n8n v1.x (self-hosted or n8n Cloud)
- Credentials configured in n8n's Credential Store before importing workflows
- Environment variables set (each workflow lists its required variables)

## Import Instructions

1. Open n8n
2. Go to **Workflows** in the left sidebar
3. Click **Import from file**
4. Select the JSON file
5. Set up credentials (the workflow will show which credentials are missing)
6. Test with the **Test workflow** button before activating
7. Click **Activate** to enable

## Environment Variables Required

Set these in your n8n environment configuration:

```bash
# Shared across workflows
AGENCY_EMAIL=your@email.com
AGENCY_NAME=Your Agency Name
SLACK_WEBHOOK_URL=https://hooks.slack.com/...

# CRM integration
CRM_API_KEY=your_crm_api_key
CRM_BASE_URL=https://api.yourcrm.com

# Notification
NOTIFICATION_EMAIL=alerts@youragency.com
```

Individual workflows may require additional environment variables — see the `description` field inside each JSON.
