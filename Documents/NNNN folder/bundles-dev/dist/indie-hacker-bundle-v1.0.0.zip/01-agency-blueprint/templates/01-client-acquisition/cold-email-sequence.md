# Cold Email Sequence — AI Automation Services

> A 5-email sequence designed for freelancers and agencies selling n8n / AI automation services.
> Customize `[YOUR NAME]`, `[COMPANY]`, `[PROSPECT COMPANY]`, `[NICHE]`, and `[RESULT]` before sending.
> Recommended sending tool: Instantly.ai, Lemlist, or Apollo.io

---

## Email #1 — Day 0 (First Touch)

**Subject:** Quick question about [PROSPECT COMPANY]'s operations

---

Hi [FIRST NAME],

I was looking at [PROSPECT COMPANY] and noticed you're scaling fast in [NICHE/MARKET].

Most [NICHE] companies at your stage are losing 10–15 hours per week on tasks that could be fully automated — things like lead follow-up, client status updates, and invoice chasing.

I help [NICHE] businesses build custom AI automation systems using n8n. Last month I helped [REFERENCE CLIENT TYPE] cut their admin time by 60% and recover $3,200/month in billable hours.

Would it make sense to hop on a 20-minute call to see if I could do the same for [PROSPECT COMPANY]?

Best,
[YOUR NAME]
[YOUR TITLE] | [YOUR COMPANY/WEBSITE]

---

## Email #2 — Day 3 (Value Add)

**Subject:** How [SIMILAR COMPANY] saved 12 hours/week with automation

---

Hi [FIRST NAME],

Following up on my last email — wanted to share something specific to [NICHE] businesses.

Here's exactly what a typical automation stack looks like for a company your size:

**The 3 workflows that save [NICHE] companies the most time:**
1. **Lead capture → CRM sync** — every inbound inquiry automatically logged and assigned (saves ~3 hrs/week)
2. **Client onboarding sequence** — welcome emails, document requests, and kickoff scheduling on autopilot (saves ~4 hrs/week)
3. **Weekly status report generator** — pulls data from your tools and sends a polished report to clients automatically (saves ~3 hrs/week)

Total: ~10 hours/week back to your team. At $100/hour billable, that's $4,000/month in recovered value.

I build these in n8n — no expensive SaaS subscriptions, runs on your own server.

Worth a 20-minute call?

[YOUR NAME]

---

## Email #3 — Day 7 (Social Proof)

**Subject:** [RESULT] — thought you'd find this relevant

---

Hi [FIRST NAME],

I just finished a project for a [NICHE] company similar to [PROSPECT COMPANY] — wanted to share the outcome since it's directly relevant to what you're doing.

**The situation:** They were manually processing 200+ leads per week, taking 2–3 days to respond to each one.

**What we built:** An n8n automation that:
- Captured leads from their website form
- Scored them using AI (Claude API) based on fit criteria
- Sent personalized follow-up emails within 5 minutes
- Updated their CRM and notified the sales rep

**The result:** Response time dropped from 48 hours to 5 minutes. Lead-to-call conversion went up 34% in the first month.

**What it cost them:** $1,800 setup + $400/month to maintain.

If even 1 extra deal closes per month because of faster follow-up, that automation pays for itself 10x over.

Would something like this be useful at [PROSPECT COMPANY]?

[YOUR NAME]

---

## Email #4 — Day 14 (Direct Ask)

**Subject:** Re: Quick question about [PROSPECT COMPANY]'s operations

---

Hi [FIRST NAME],

I've sent a few emails over the past two weeks — I'll make this one short.

I genuinely think there's a 10–15 hour/week opportunity at [PROSPECT COMPANY] that I could help you capture. That usually translates to $3,000–$6,000/month in recovered productivity.

If you're not the right person to talk to, could you point me to whoever handles operations or process improvement?

And if the timing just isn't right — totally understood, no hard feelings. Just let me know and I'll stop following up.

Either way, thanks for your time.

[YOUR NAME]

---

## Email #5 — Day 21 (Break-Up Email)

**Subject:** Closing the loop — [PROSPECT COMPANY]

---

Hi [FIRST NAME],

I'm going to stop reaching out after this email — I don't want to be a nuisance.

I'll leave you with one thing: the companies I've seen get the most value from AI automation are the ones that act before their competitors do. In 12–18 months, this stuff will be table stakes. Right now it's still a real competitive advantage.

If you ever want to explore what's possible for [PROSPECT COMPANY], my calendar link is below. No pitch, no pressure — just a conversation.

[CALENDAR LINK]

Wishing you and the team a great [QUARTER/YEAR].

[YOUR NAME]

P.S. If you know someone else who'd benefit from this, I'd be grateful for an introduction.

---

## Sequence Settings

| Email | Day | Subject Line Approach | Best Sending Time |
|-------|-----|----------------------|-------------------|
| #1 | 0 | Question / curiosity | Tuesday–Thursday, 7–9am recipient TZ |
| #2 | 3 | Specific value / numbers | Tuesday–Thursday, 7–9am |
| #3 | 7 | Social proof / case study | Tuesday–Thursday, 7–9am |
| #4 | 14 | Direct ask / short | Monday, 8–10am |
| #5 | 21 | Break-up / respect | Tuesday, 8–10am |

## Customization Notes

- Replace `[RESULT]` in Email #3 subject with a specific metric (e.g., "34% more leads booked")
- Keep emails under 150 words for best open rates on mobile
- Use plain text format (no HTML, no images) for higher deliverability
- Personalize the first line of each email with a company-specific observation
