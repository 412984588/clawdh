# Discovery Call Script — AI Automation Services

> A 45-minute sales call framework for diagnosing workflow pain, quantifying ROI, and moving a prospect to proposal.

---

## Call Goal

Leave the conversation with three things:
- A clear picture of the prospect's current process
- A quantified business case for automation
- Explicit agreement on the next step and decision owner

---

## Agenda (45 Minutes)

### 1. Frame the Call (5 min)

Use this opener:

> "Thanks for taking the time. My goal today is to understand how your team handles [PROCESS], where the bottlenecks are, and whether automation would create a meaningful return. If there is a fit, I will outline the best next step. If there is not, I will tell you directly."

Questions:
- What made you take this call now?
- Why is this a priority in this quarter instead of later?
- Who besides you cares most about fixing this problem?

### 2. Diagnose the Workflow (15 min)

Map the current state in detail:
- What triggers the workflow today?
- Which tools are involved?
- Where does work get stuck, duplicated, or dropped?
- How many handoffs happen between people or systems?
- What exceptions break the process most often?

Probe for frequency and cost:
- How many times per week does this happen?
- How many people touch it?
- What does a delay or mistake cost you?

### 3. Quantify the Business Case (10 min)

Turn pain into economics:
- How many hours per week are spent manually?
- What is the loaded hourly value of the people involved?
- What revenue is delayed because response time is slow?
- What error rate or missed follow-up rate are you seeing?

Summarize in plain language:

> "It sounds like this process burns roughly [X] hours per week, creates [Y] delays, and puts [Z] revenue at risk. If we remove the manual steps, the project likely pays back within [time period]."

### 4. Confirm Fit and Constraints (10 min)

- What systems are non-negotiable?
- Do you need this deployed in your own stack or is a managed setup acceptable?
- Who approves budget?
- What timeline would feel useful?
- What would make this a no-go internally?

### 5. Close the Next Step (5 min)

Choose one path:
- Proposal within 24 hours
- Technical scoping session with their operator
- No-fit closeout with a referral or alternative suggestion

Use this close:

> "Based on what you shared, I recommend [option]. I will send [deliverable] by [date], and we can review it with [stakeholders] on [time]."

---

## Red Flags

- The prospect cannot name a single measurable outcome
- No one owns the process end to end
- They want a vague "AI strategy" instead of a workflow problem
- Decision authority is unclear and budget is fictional

Walk away early when these show up repeatedly.
