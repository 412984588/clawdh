# 01 — Client Acquisition

> Your pipeline starts here. These templates help you attract, qualify, and convert clients who will pay $1,000–$10,000/month for AI automation services.

---

## Contents

| File | Purpose |
|------|---------|
| `cold-email-sequence.md` | 5-email cold outreach sequence — optimized for 15–25% reply rates |
| `linkedin-outreach.md` | LinkedIn DM scripts for cold, warm, and referral contacts |
| `discovery-call-script.md` | 45-minute call framework to qualify leads and close deals |
| `proposal-template.md` | Professional proposal with pricing sections and social proof |

---

## How to Use This Folder

### Week 1: Set Up Your Outreach Machine
1. Choose your niche (e-commerce, SaaS, real estate, healthcare — pick ONE)
2. Build a list of 50 target companies (LinkedIn Sales Navigator or Apollo.io)
3. Customize the cold email sequence with your name, niche, and a relevant case study
4. Start sending Day 1 emails (10–20 per day max)

### Week 2: Qualify and Book Calls
1. Reply to interested prospects using the LinkedIn follow-up scripts
2. Use the discovery call script to qualify their automation needs
3. Send the proposal template within 24 hours of a positive call

### Week 3+: Close and Scale
1. Follow up on proposals using Email #4 and #5 of the cold sequence
2. Aim for 1–2 discovery calls per week
3. Close your first client within 30 days

---

## Niche Selection Guide

The fastest path to $5,000/month is a **focused niche**. Recommended starting niches:

| Niche | Pain Points to Solve | Price Range |
|-------|---------------------|-------------|
| E-commerce / DTC brands | Order tracking, customer support, review collection | $1,500–$3,000/month |
| Real estate agencies | Lead nurturing, CRM updates, listing alerts | $1,000–$2,500/month |
| B2B SaaS companies | Lead qualification, onboarding emails, churn alerts | $2,000–$5,000/month |
| Recruiting / HR | Candidate screening, interview scheduling, follow-ups | $1,500–$3,000/month |
| Professional services (law, accounting) | Client intake, document collection, reminder sequences | $1,000–$2,000/month |

---

## Success Metrics to Track

- **Emails sent per week**: Target 50–100
- **Reply rate**: Benchmark 10–20% (good), 20–30% (excellent)
- **Discovery call bookings per week**: Target 2–3
- **Proposal-to-close rate**: Benchmark 20–30%
