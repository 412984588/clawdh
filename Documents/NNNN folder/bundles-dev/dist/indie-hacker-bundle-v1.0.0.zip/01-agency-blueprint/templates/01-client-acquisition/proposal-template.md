# Proposal Template — AI Automation Implementation

> Use this after a qualified discovery call. Keep the language commercial and outcome-focused.

---

## 1. Executive Summary

[CLIENT NAME] wants to reduce manual effort in [PROCESS], improve speed across [TEAM/FUNCTION], and create a more reliable workflow for [OUTCOME]. Based on our discovery call on [DATE], I recommend building a focused automation system in n8n that handles the highest-friction parts first and leaves room for future expansion.

Primary business outcomes:
- Recover approximately [X] hours per week
- Reduce response or processing time from [CURRENT] to [TARGET]
- Improve visibility with automated alerts and reporting
- Lower operational risk from missed handoffs and manual re-entry

## 2. Scope of Work

The initial phase includes:
- Workflow mapping and systems access review
- n8n automation design and build
- AI enrichment or classification steps where relevant
- QA, exception handling, and delivery walkthrough
- Launch support for [X] business days after go-live

Excluded unless added in writing:
- Large data cleanup projects
- Net-new frontend applications
- Custom integrations not discussed in discovery

## 3. Deliverables

- One production-ready automation for [PROCESS]
- Documentation with trigger, logic, exceptions, and owner notes
- Loom walkthrough or live handoff session
- Monitoring checklist and escalation path

## 4. Timeline

| Phase | Output | Timing |
|------|--------|--------|
| Discovery Wrap | Final workflow spec | Day 1 |
| Build | Core automation live in staging | Days 2-5 |
| QA | Edge-case review and fixes | Days 6-7 |
| Launch | Production handoff | Day 8 |

## 5. Investment

Choose one:
- **Project fee**: $[AMOUNT] one-time
- **Project + support**: $[AMOUNT] setup + $[MONTHLY] retainer

The support retainer covers monitoring, small improvements, and incident response during business hours.

## 6. Why This Project Pays Back

If this automation saves [X] hours per week at a loaded cost of $[RATE]/hour, the annual operational value is roughly $[VALUE]. That excludes revenue lift from faster follow-up or fewer missed tasks. The goal is not just a workflow that "works"; the goal is a system that pays for itself quickly and compounds every month after launch.

## 7. Next Step

If approved, reply with:
- "Approved"
- Billing contact
- Technical point of contact
- Preferred kickoff date

I will then send the final service agreement and launch checklist within one business day.

---

## Pricing Reference

Standard project investment: {{PRICE}}

Use this placeholder when inserting the finalized price from your `value-pricing-calculator.md` output.

Example packages:
- Basic automation (1 workflow): {{PRICE_BASIC}}
- Standard system (3 workflows): {{PRICE_STANDARD}}
- Full build (5+ workflows + retainer): {{PRICE_PREMIUM}}
