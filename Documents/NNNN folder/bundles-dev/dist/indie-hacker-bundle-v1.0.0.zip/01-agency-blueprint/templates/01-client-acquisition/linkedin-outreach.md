# LinkedIn Outreach Scripts — AI Automation Services

> Scripts for three scenarios: cold contacts, warm connections, and referral introductions.
> LinkedIn has a 300-character limit on connection request notes. Keep them short.

---

## Part 1 — Cold Connection Requests

### Script A: Niche-Specific (Best for targeting)
> *Use when you know their industry and company size*

```
Hi [NAME] — I help [NICHE] companies automate their ops with n8n workflows.
Noticed [PROSPECT COMPANY] is growing fast. Would love to connect and share what's been working.
```
*(271 characters)*

---

### Script B: Pain-Point Lead (Best for ops/founder profiles)
> *Use when their profile mentions manual processes or team growth*

```
Hi [NAME] — saw you're scaling the team at [COMPANY]. Most ops leaders at your stage tell me
they're drowning in manual tasks. I build AI automation that fixes that. Worth connecting?
```
*(287 characters)*

---

### Script C: Content Engagement (Best after engaging with their post)
> *Use after liking/commenting on a relevant post*

```
[NAME] — just commented on your post about [TOPIC]. I work in the same space
(AI automation for [NICHE]). Would be great to have you in my network.
```
*(213 characters)*

---

## Part 2 — First DM After Connection Accepted

> Wait 24–48 hours after connection is accepted before sending this message.

### DM Template A: Soft Discovery
```
Hey [NAME], thanks for connecting!

Quick question — what's the most time-consuming manual process in your team right now?

I ask because I've been helping [NICHE] companies automate exactly that kind of work with n8n,
and I'm curious what the landscape looks like at [COMPANY].

No pitch — genuinely curious.
```

---

### DM Template B: Value-First Approach
```
Hey [NAME], appreciate the connection.

I put together a short breakdown of the 3 automations that save [NICHE] companies the most time —
wanted to share in case it's useful.

[Paste a 3-bullet summary from cold-email-sequence.md Email #2]

Would any of these be relevant for [COMPANY]? Happy to dig into specifics if so.
```

---

### DM Template C: Direct But Respectful
```
Hey [NAME] — I'll be straight with you.

I help [NICHE] businesses build n8n automation systems that typically save 10–15 hours/week
and pay for themselves within 60 days.

Would a 20-minute call make sense to see if there's a fit? No obligation — if it's not relevant,
I'll leave you alone.
```

---

## Part 3 — Follow-Up Messages (If No Reply)

### Follow-Up #1 — Day 5
```
Hey [NAME] — just wanted to bump this up in case it got buried.

Happy to send over a quick example of what the automation would look like for [COMPANY] if that's easier than a call?
```

---

### Follow-Up #2 — Day 12 (Last Touch)
```
[NAME] — I'll leave you alone after this one!

If the timing is ever right to look at AI automation for [COMPANY], feel free to ping me.
Wishing you a great [MONTH].
```

---

## Part 4 — Warm Contact Outreach

> Use when reconnecting with former colleagues, clients, or anyone who knows you.

### Script: Warm Reconnect
```
Hey [NAME] — it's been a while! Hope things are going well at [COMPANY].

I've been doing some interesting work lately — building AI automation systems for [NICHE] businesses
using n8n. Cutting a lot of manual work out of their operations.

If you ever come across someone who'd benefit from that kind of thing,
I'd love an introduction. And I'm happy to do the same for you anytime.
```

---

## Part 5 — Referral Request Scripts

> Use with existing clients or happy connections to generate warm introductions.

### Script A: After a Successful Project
```
[CLIENT NAME] — it's been a pleasure working on the automation for [COMPANY].

I wanted to ask — do you know 2–3 other [NICHE] business owners who might benefit
from a similar system? Even a quick introduction would mean a lot.

And of course, I'd happily build a free additional workflow for [COMPANY]
as a thank you if the intro leads to a project.
```

---

### Script B: General Network Ask
```
[NAME] — I'm looking to work with 2 more [NICHE] companies this quarter on AI automation.

Is there anyone in your network who runs a [NICHE] business and might be open to a quick conversation?

No pressure if not — just thought I'd ask while it's top of mind.
```

---

## LinkedIn Profile Optimization Checklist

Before running outreach, make sure your profile is ready:

- [ ] **Headline**: "[Niche] AI Automation Specialist | Save 10+ hrs/week with n8n workflows"
- [ ] **About section**: Clear problem → solution → outcome in first 200 characters (shown in preview)
- [ ] **Featured section**: Add a case study, a workflow demo video, or a link to your calendar
- [ ] **Recent activity**: Like and comment on posts in your target niche 3–5x per week
- [ ] **Connection strategy**: Connect with 20–30 ideal prospects per day (LinkedIn limit)

---

## Volume Benchmarks

| Activity | Daily Target | Weekly Target |
|----------|-------------|---------------|
| Connection requests sent | 15–25 | 75–125 |
| DMs sent to new connections | 5–10 | 25–50 |
| Follow-up messages | 5–10 | 25–50 |
| Referral asks | 1–2 | 5–10 |
| **Discovery calls booked** | — | **2–4** |
