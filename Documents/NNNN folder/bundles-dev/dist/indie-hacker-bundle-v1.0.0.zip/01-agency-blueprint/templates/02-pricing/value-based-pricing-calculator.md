# Value-Based Pricing Calculator

Use this worksheet immediately after discovery while the numbers are fresh.

---

## 1. Time Savings

- Process frequency per week: `[X]`
- Average manual time per run: `[Y]` minutes
- Team members involved: `[Z]`
- Loaded hourly rate: `$[RATE]`

Formula:

`weekly value = X * (Y / 60) * Z * RATE`

## 2. Revenue Impact

- Leads currently lost because of slow follow-up: `[N]`
- Average deal value: `$[DEAL VALUE]`
- Conservative conversion improvement after automation: `[PERCENT]%`

Formula:

`monthly revenue upside = N * DEAL VALUE * conversion improvement`

## 3. Risk Reduction

- Manual errors per month: `[COUNT]`
- Average cost per error: `$[COST]`

Formula:

`monthly risk reduction = COUNT * COST`

## 4. Pricing Decision

Use the combined monthly value as the anchor:
- Monthly value under $2,000: quote a focused starter project
- Monthly value between $2,000 and $8,000: quote a standard project + support retainer
- Monthly value above $8,000: quote a premium build and position further automations as roadmap items

## 5. Messaging Template

> "Based on your current workflow, this automation is worth roughly $[VALUE] per month between hours recovered, faster response, and reduced errors. My fee is $[FEE], which gives you payback in roughly [TIMEFRAME]."

Do not oversell precision. This is a commercial framing tool, not an accounting document.
