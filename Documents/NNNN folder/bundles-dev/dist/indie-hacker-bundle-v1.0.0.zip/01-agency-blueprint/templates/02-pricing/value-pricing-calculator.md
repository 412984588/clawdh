# Value Pricing Calculator — AI Automation Services

> Use this calculator during or after the discovery call to build a data-driven case for your price.
> Fill in the client's numbers, then present the math as part of your proposal.

---

## How to Use This Calculator

1. During the discovery call, capture the inputs in Section 1
2. Run the calculations in Section 2 (use a spreadsheet or mental math)
3. Present the output table in your proposal under "Why This Investment Makes Sense"
4. Price your project at 1.5×–3× the monthly value

---

## Section 1 — Input Capture (During Discovery Call)

### Time Savings Inputs

| Input | Client's Answer | Variable Name |
|-------|----------------|---------------|
| How many hours per week does your team spend on [MANUAL TASK]? | _____ hrs | `HOURS_PER_WEEK` |
| How many people are doing this task? | _____ people | `HEADCOUNT` |
| What's the average fully-loaded cost per hour for those people? | $_____ /hr | `HOURLY_RATE` |
| What % of that time do you think automation could eliminate? | _____% | `AUTOMATION_RATE` |

### Revenue Impact Inputs

| Input | Client's Answer | Variable Name |
|-------|----------------|---------------|
| How many leads/inquiries do you receive per week? | _____ | `LEADS_PER_WEEK` |
| What's your average deal size? | $_____ | `DEAL_VALUE` |
| What's your current lead-to-close rate? | _____% | `CLOSE_RATE` |
| How long does it currently take to follow up with a new lead? | _____ hrs | `CURRENT_RESPONSE_TIME` |
| What would you estimate as your ideal follow-up time? | _____ min | `TARGET_RESPONSE_TIME` |

### Error / Rework Inputs (Optional)

| Input | Client's Answer | Variable Name |
|-------|----------------|---------------|
| How often do errors occur in [MANUAL PROCESS]? | _____× /week | `ERROR_FREQUENCY` |
| How long does it take to fix each error? | _____ hrs | `REWORK_HOURS` |
| Have any errors caused a lost client or deal? | Yes / No / $ | `ERROR_COST` |

---

## Section 2 — Calculations

### Calculation A: Time Savings Value

```
Weekly hours eliminated = HOURS_PER_WEEK × HEADCOUNT × AUTOMATION_RATE
Monthly hours eliminated = Weekly hours × 4.3
Monthly dollar value     = Monthly hours × HOURLY_RATE

Example:
  5 hrs/week × 2 people × 80% = 8 hrs/week eliminated
  8 × 4.3 = 34.4 hrs/month
  34.4 × $85/hr = $2,924/month
```

**Monthly Time Savings Value = $________**

---

### Calculation B: Revenue Uplift (If Faster Follow-Up)

Faster response time → higher lead conversion.

Research benchmark: Responding within 5 minutes vs. 48 hours increases contact rates by 100× (Harvard Business Review, 2011 — still holds for B2B).

Conservative model: Assume just 10% more leads convert with faster follow-up.

```
Additional deals per month = (LEADS_PER_WEEK × 4.3) × CLOSE_RATE × 10%
Additional revenue per month = Additional deals × DEAL_VALUE

Example:
  20 leads/week × 4.3 = 86 leads/month
  86 × 15% close rate = 12.9 deals/month currently
  12.9 × 10% uplift = 1.29 additional deals/month
  1.29 × $2,500 deal value = $3,225/month additional revenue
```

**Monthly Revenue Uplift = $________**

---

### Calculation C: Error Reduction Value

```
Monthly rework hours = ERROR_FREQUENCY × REWORK_HOURS × 4.3
Monthly rework cost  = Monthly rework hours × HOURLY_RATE

Example:
  3 errors/week × 2 hrs/error × 4.3 = 25.8 hrs/month
  25.8 × $60/hr = $1,548/month in rework cost
```

**Monthly Error Reduction Value = $________**

---

### Calculation D: Total Monthly Value

```
Total Monthly Value = Time Savings + Revenue Uplift + Error Reduction

Example:
  $2,924 + $3,225 + $1,548 = $7,697/month
```

**Total Monthly Value = $________**

---

## Section 3 — Project Price Recommendation

| Pricing Approach | Formula | Example |
|-----------------|---------|---------|
| Conservative (1.5× monthly value) | Total Monthly Value × 1.5 | $7,697 × 1.5 = $11,546 |
| Standard (2× monthly value) | Total Monthly Value × 2 | $7,697 × 2 = $15,394 |
| Aggressive (3× monthly value) | Total Monthly Value × 3 | $7,697 × 3 = $23,091 |
| Payback period anchor | "Pays back in 60 days" | $7,697 × 2 months = $15,394 |

**Recommended price for this client: $________**

---

## Section 4 — Presentation Script

Use this in your proposal or on a follow-up call:

> "Based on what you told me, here's the math:
>
> Your team currently spends **{{HOURS_PER_WEEK × HEADCOUNT}} hours per week** on [PROCESS].
> At an average cost of ${{HOURLY_RATE}}/hour, that's **${{MONTHLY_TIME_COST}}/month** in manual effort.
>
> The automation I'm proposing eliminates approximately {{AUTOMATION_RATE}}% of that — recovering **${{MONTHLY_TIME_SAVINGS}} per month** for your business.
>
> On top of that, faster follow-up on leads alone is worth an estimated **${{MONTHLY_REVENUE_UPLIFT}}/month** based on a conservative 10% improvement in conversion.
>
> Total monthly value: **${{TOTAL_MONTHLY_VALUE}}**.
>
> My project price is ${{PRICE}}.
> At that rate, the system pays for itself in **{{PRICE / TOTAL_MONTHLY_VALUE}} months** — and then delivers that value every single month after that.
>
> Does that framing make sense?"

---

## Section 5 — Quick Reference Card (Laminate This)

```
┌─────────────────────────────────────────────────────┐
│         VALUE PRICING QUICK REFERENCE               │
├─────────────────────────────────────────────────────┤
│ Time savings: Hours × Rate × Automation% × 4.3      │
│ Revenue uplift: Leads × Close rate × 10% × Deal$    │
│ Error savings: Errors × Rework hrs × Rate × 4.3     │
│                                                      │
│ Project price = Total monthly value × 2             │
│ Payback = Price ÷ Monthly value (target: <3 months) │
│                                                      │
│ NEVER quote hourly rate first.                       │
│ ALWAYS show ROI math before the price.               │
└─────────────────────────────────────────────────────┘
```
