# AI Automation Service Pricing Guide

> Market benchmarks and pricing strategies for n8n / AI automation freelancers.
> Last updated: March 2026. Prices reflect the current US and European market.

---

## Part 1 — Market Benchmarks

### What the Market Is Paying (2025–2026)

Based on Upwork, Toptal, and direct freelance market data:

| Service | Low End | Market Rate | Premium Rate |
|---------|---------|-------------|--------------|
| n8n workflow setup (single) | $150 | $500–$800 | $1,500+ |
| Zapier → n8n migration | $200 | $600–$1,200 | $2,000+ |
| AI agent build (Claude/OpenAI) | $500 | $1,500–$3,000 | $5,000+ |
| Full automation system (3–5 workflows) | $800 | $2,500–$5,000 | $8,000+ |
| Monthly managed automation retainer | $300 | $800–$1,500 | $2,500+ |
| Automation audit + roadmap | $300 | $800–$1,500 | $2,500+ |

**Key insight:** The top 20% of automation freelancers earn 5–10x more than average.
The difference is almost entirely **positioning and communication**, not technical skill.

---

## Part 2 — Pricing Models

### Model 1: Fixed-Price Projects (Best for Beginners)

Charge a flat fee for a defined scope.

**Pros:**
- Easy to sell (client knows exactly what they're paying)
- No time tracking required
- You benefit if you get faster

**Cons:**
- Scope creep kills profitability if you're not careful
- Hard to price accurately without experience

**How to set your fixed price:**
1. Estimate hours: How long will this honestly take?
2. Multiply by your desired effective hourly rate (aim for $100–$200/hr)
3. Add 20% buffer for unexpected complexity
4. Round up to the nearest clean number ($1,750 → $2,000)

**Example:**
- Estimate: 8 hours build + 2 hours testing + 1 hour documentation = 11 hours
- Target rate: $150/hour
- Raw: 11 × $150 = $1,650
- Buffer: $1,650 × 1.2 = $1,980
- Final price: **$2,000**

---

### Model 2: Value-Based Pricing (Best for Established Freelancers)

Price based on the value delivered, not hours worked.

**The Formula:**
```
Project Price = Monthly Value × Payback Multiplier
```

Where:
- **Monthly Value** = client's time savings + revenue impact per month
- **Payback Multiplier** = typically 1.5× to 3× monthly value

**Example:**
- Client saves 15 hrs/week × $80/hr = $1,200/week = **$4,800/month**
- Price = $4,800 × 2 = **$9,600**

This is *still* a great deal for the client (pays back in 2 months, then free value for years).

**Use the Value Pricing Calculator in `value-pricing-calculator.md` to make this case.**

---

### Model 3: Monthly Retainers (Best for Recurring Revenue)

Charge a monthly fee for ongoing work: maintenance, monitoring, expansion.

**Retainer structure:**

| Tier | Monthly Price | What's Included |
|------|--------------|-----------------|
| Basic Maintenance | $400–$600/mo | Monitoring, bug fixes, minor updates (2 hrs/mo) |
| Growth | $800–$1,200/mo | Maintenance + 1 new workflow/month + monthly report (5 hrs/mo) |
| Scale | $1,500–$2,500/mo | Maintenance + 2 new workflows + strategy call + priority support (10 hrs/mo) |

**How to introduce the retainer:**
After a project is live, send this message:
> "Now that the system is running, you'll want someone monitoring it and expanding it as your needs grow. I offer a monthly retainer for exactly that — want me to put together a quick proposal?"

**Close rate:** 40–60% of project clients who see results will take a retainer.

---

### Model 4: Productized Services (Best for Scale)

Package your most common service at a fixed price, sold repeatedly.

**Examples of productized automation offers:**

| Package | Price | Scope |
|---------|-------|-------|
| "Leads on Autopilot" | $1,200 | Web form → CRM → personalized follow-up email sequence |
| "Invoice Automator" | $800 | Project completion → invoice generated → follow-up on unpaid |
| "Weekly Report Machine" | $600 | Data from 3 sources → formatted report → email to stakeholders |
| "Churn Early Warning System" | $1,500 | User behavior → AI scoring → Slack alert + retention email |
| "Client Onboarding Bot" | $1,000 | Contract signed → welcome sequence → document collection → kickoff scheduling |

**Why productized services work:**
- Easier to market (specific problem → specific solution)
- Faster to deliver (you've done it before)
- Easier to price (fixed, non-negotiable)
- Scales without scaling your time

---

## Part 3 — Pricing Psychology

### The Anchoring Strategy

Always present three options. Never present one.

| Option | Price | What's Included |
|--------|-------|-----------------|
| Basic | ${{LOW_PRICE}} | Core workflow only |
| **Recommended** | **${{MID_PRICE}}** | **Core + 2 additional workflows + 30-day support** |
| Premium | ${{HIGH_PRICE}} | Everything + retainer for 3 months |

**Why this works:** The middle option feels "reasonable" compared to the premium. Most clients choose the middle. The premium makes the middle look affordable.

---

### Handling "That's Too Expensive"

When a client says your price is too high, they usually mean one of three things:

**A) They don't understand the value.**
→ Response: "Let me walk through the math. If this saves your team {{X}} hours/week at {{RATE}}/hour, that's {{MONTHLY_VALUE}}/month. I'm charging {{PRICE}} — that's less than one month's savings. Does that framing help?"

**B) They don't trust you yet.**
→ Response: "I completely understand — we just met. Would you be open to a smaller first project? For {{SMALLER_PRICE}}, I can build just {{ONE_WORKFLOW}} so you can see the quality of my work before committing to the full system."

**C) They genuinely don't have budget.**
→ Response: "What range did you have in mind? If it's significantly different, I want to make sure we're not wasting each other's time. If it's closer, let's see if we can scope something that works."

---

## Part 4 — When to Raise Your Rates

Raise your rates when:
- You're fully booked (no available slots in the next 2 weeks)
- Clients accept your price without any pushback (means you're undercharging)
- You've completed 5+ successful projects
- You have a documented case study with measurable results
- You're the only specialist in a particular niche or tech stack

**Rate increase cadence:** Raise rates by 20–30% every 6 months until you start getting occasional pushback. That's your market rate.

---

## Part 5 — Scope Creep Protection

Always define what's **not** included in your proposals.

**Common scope creep scenarios and how to respond:**

| Request | How to respond |
|---------|---------------|
| "Can you also connect it to [NEW TOOL]?" | "That's not in the current scope — I can quote it as an add-on. Probably $300–$500." |
| "Can we add another trigger condition?" | "Minor changes like this are included. Major logic changes are billed at ${{HOURLY_RATE}}/hr." |
| "Can you also set this up for our UK team?" | "That would be a separate deployment — same price as the original setup." |
| "Can we jump on a call every week?" | "I include one check-in call per month. Additional calls are $150/hour." |

**The easiest way to prevent scope creep:** Write a clear scope of work before starting. See `templates/04-contracts/scope-of-work.md`.
