# 02 — Pricing

> Use these documents to price automation work based on business value instead of hours alone.

---

## Contents

| File | Purpose |
|------|---------|
| `pricing-guide.md` | Positioning, anchors, and deal-structure guidance |
| `value-based-pricing-calculator.md` | Worksheet to quantify hours saved, risk reduced, and upside created |
| `objection-handling.md` | Responses for budget pushback, scope uncertainty, and comparison shopping |

---

## Recommended Order

1. Read the pricing guide to set your package strategy.
2. Run the calculator using numbers from your discovery call.
3. Use objection handling only after you have a quantified ROI narrative.
