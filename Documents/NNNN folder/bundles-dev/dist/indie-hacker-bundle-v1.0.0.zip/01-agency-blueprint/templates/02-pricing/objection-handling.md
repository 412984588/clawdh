# Objection Handling — Pricing Conversations

Use these responses after you have explained the ROI. Do not jump to defense mode too early.

---

## "This is more than we expected."

Response:

> "That makes sense. The right comparison is not another freelancer quote, it is the cost of leaving the workflow manual. Based on the numbers we discussed, the process is already costing you around $[VALUE] per month. My goal is to remove that drain quickly and make the project pay for itself."

## "Can you lower the price?"

Response:

> "I can reduce scope more easily than I can reduce price. If budget is tight, we should strip this down to the single highest-value workflow and phase the rest later."

## "We need to think about it."

Response:

> "Of course. What specifically do you need to think through: ROI, timing, internal approval, or scope? If I know the blocker, I can answer it directly."

## "Another vendor is cheaper."

Response:

> "That can be true. The question is whether they are pricing implementation effort or business outcome. My proposal includes handoff quality, exception handling, and launch support so the workflow actually sticks."

## Rule

Never negotiate against yourself. Clarify the concern, reduce scope if needed, and protect margin.
