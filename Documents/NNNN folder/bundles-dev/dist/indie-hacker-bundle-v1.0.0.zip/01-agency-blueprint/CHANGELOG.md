# Changelog

All notable changes to the AI Automation Agency Starter Kit will be documented here.

---

## [1.0.0] — 2026-03-20

### Added
- **01-client-acquisition**: 5-email cold outreach sequence, LinkedIn DM scripts, discovery call framework, full proposal template
- **02-pricing**: AI automation pricing guide with market benchmarks, value-based pricing calculator
- **03-delivery**: Project kickoff checklist, client onboarding SOP, delivery SOP, handoff documentation template
- **04-contracts**: Freelance service agreement, NDA template, scope of work document
- **05-n8n-workflows**: 18 production-ready workflow JSONs covering lead capture, onboarding, invoicing, reporting, retention, upsell, testimonial capture, and support routing
- **06-customer-success**: 30/60/90-day check-in templates, upsell script, case study template, onboarding email sequence
- `build_bundle.py`: Automated packaging script for all three tiers
- `tests/test_bundle.py`: Standard-library validation suite for structure, content, workflow JSONs, and bundle boundaries

### Notes
- Initial public release
- All n8n workflows exported as reusable starter templates for n8n v1.x style builds
- Document templates written for international English-speaking buyers
