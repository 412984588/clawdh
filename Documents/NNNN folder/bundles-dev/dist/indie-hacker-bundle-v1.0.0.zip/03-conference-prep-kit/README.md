# Claude Code Conference & Workshop Prep Kit

An evergreen prep system for anyone running a `code with Claude` conference talk, internal workshop, office-hours lab, or live demo day. This pack does not depend on one event brand. It packages reusable conference-ready `CLAUDE.md` templates, environment checks, facilitation assets, and team coordination docs that help presenters avoid setup failure, reduce demo drift, and keep workshop time focused on outcomes instead of troubleshooting.

## Who This Is For

- Solo presenters preparing a live Claude Code demo
- Workshop leads teaching a room of mixed-skill attendees
- DevRel teams running conference booths, labs, or breakout sessions
- Engineering managers coordinating multi-presenter training sessions

## Tiers

| Tier | Price | Includes |
| --- | ---: | --- |
| Lite | $19 | Conference-ready `CLAUDE.md` template, 30-point environment health checklist, MCP quick config guide, 5 workshop-common skills |
| Pro | $39 | Everything in Lite, plus 15 advanced `CLAUDE.md` templates, workshop demo project template, team collaboration config, and a conference FAQ cheat sheet |

## Asset Map

- `assets/01-conference-ready-claude-template/` — baseline `CLAUDE.md` for a live session
- `assets/02-environment-health-checklist/` — preflight checklist with 30 verification points
- `assets/03-mcp-quick-config-guide/` — practical MCP setup and fallback guide
- `assets/04-workshop-common-skills/` — reusable workflow skills for facilitation
- `assets/05-advanced-claude-templates/` — 15 scenario-specific `CLAUDE.md` variants
- `assets/06-demo-project-template/` — starter demo structure for rehearsals
- `assets/07-team-collaboration-config/` — handoff and operator coordination docs
- `assets/08-faq-cheat-sheet/` — fast answers for common workshop and conference issues

## Quick Start

1. Pick the `CLAUDE.md` template that matches your session format.
2. Run through the 30-point checklist before you travel or go on stage.
3. Use the MCP guide to confirm local and fallback paths for tools.
4. If you are running with a partner or producer, use the collaboration config before rehearsal.
5. Rebuild the release ZIPs after content edits.

## Verification

```bash
python3 generate_assets.py
python3 build_bundle.py
python3 -m pytest tests/test_bundle.py -q
```

## Release Files

- `dist/conference-prep-kit-lite-v1.0.0.zip`
- `dist/conference-prep-kit-pro-v1.0.0.zip`

Both ZIPs include `README.md`, `CHANGELOG.md`, `LICENSE`, and `tiers.json`, while excluding development-only files.
