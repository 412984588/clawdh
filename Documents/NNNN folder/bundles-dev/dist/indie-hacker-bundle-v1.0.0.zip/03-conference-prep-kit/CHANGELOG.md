# Changelog

## 1.0.0 - 2026-03-20

- Initial release of the Claude Code Conference & Workshop Prep Kit
- Added Lite bundle with a conference-ready `CLAUDE.md`, environment checklist, MCP guide, and 5 workshop skills
- Added Pro bundle with 15 advanced `CLAUDE.md` templates, demo project template, team collaboration config, and FAQ cheat sheet
- Added reproducible asset generation and ZIP packaging workflow
