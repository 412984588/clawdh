# Conference Prep FAQ Cheat Sheet

## Quick Answers

### What if venue Wi-Fi is unreliable?
Use the local-first demo path, reduce live integrations, and keep one hotspot-backed fallback ready before the room opens.

### What if attendees have different local environments?
Anchor the session on shared checkpoints, publish the health checklist early, and keep a recovery lane for people who fall behind.

### What if an MCP server fails live?
State the failure clearly, show the fallback path, and continue the narrative with the stable workflow you already rehearsed.

### How much repo context should I show?
Only enough to explain the decision the audience needs right now. Extra tabs and directories create noise, not trust.

### Should I debug every attendee issue on stage?
No. Solve the room-level issue, capture the outlier, and offer a post-session remedy.

### How do I keep a co-presented session smooth?
Assign ownership before rehearsal and define who speaks, who types, and who calls the fallback when the demo drifts.
