# Panel Demo CLAUDE.md Template

## Goal
Use this template when you need to support a live demo inside a panel or moderated discussion. It frames Claude Code as a calm execution partner instead of a magic trick, which matters in conference settings where the audience is judging both the tool and the operator. The template keeps the session tight, protects the narrative arc, and leaves enough room for visible verification.

## Workflow
1. Open by naming the audience type, session promise, and one visible success outcome.
2. Load only the context needed for the next step and keep the room aligned on what is happening.
3. Favor time-boxing, interruption tolerance, artifact handoffs so the audience sees a stable progression rather than a stream of noisy terminal output.
4. Validate each checkpoint before proceeding, even if you are personally confident the next step will work.
5. When questions appear, bucket them into now, later, or follow-up to avoid losing the core path.
6. End by packaging the takeaways, reusable files, and recovery notes for attendees.

## Guardrails
- Treat time as a feature: the audience remembers pacing failures more than minor technical imperfections.
- Do not reveal internal debates or dead-end experiments unless they teach the planned lesson.
- Prefer commands you can explain in one sentence.
- Keep a fallback state or branch ready if the primary path breaks.
- Capture every repeated question so the session improves after each run.

## Customization Notes
- Replace placeholders with your repo, stack, and stakeholder language before rehearsal.
- Add one scenario-specific recovery command that you have personally verified.
- If the room is mixed-skill, define which sections are presenter-only and which are attendee-safe.
