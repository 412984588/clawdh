# Team Collaboration Checklist

## How To Use
Review this checklist before every rehearsal and before entering the room on event day. It exists to make responsibilities explicit before pressure arrives.

- [ ] Confirm who owns the keyboard.
- [ ] Confirm who narrates during setup failures.
- [ ] Confirm who watches time and attendee questions.
- [ ] Confirm the hand signal or phrase for an operator handoff.
- [ ] Confirm the fallback repo state everyone can restore to.
- [ ] Confirm who publishes follow-up assets after the session.

## Notes
If any line is ambiguous, the room will notice. Resolve it before the session starts.
