# Handoff Template

## Current State
Summarize what the audience has already seen, what command or step is active, and what outcome they expect next.

## Risks
List the two most fragile parts of the remaining flow and the fallback if either fails.

## Next Operator Move
State the exact command, file, or prompt the next presenter will handle so the transition feels deliberate instead of accidental.

## What Good Looks Like
A good handoff is short, concrete, and leaves no ambiguity about ownership. The incoming operator should know the repo state, the command path, the success condition, and the sentence the presenter will say while the action happens. If any of those pieces are missing, the audience experiences hesitation immediately and the team loses momentum.

## Anti-Patterns
- Handing off with “you take it from here”
- Changing the plan during the handoff itself
- Omitting the fallback path when the next move is risky
- Assuming the other presenter remembers the exact checkpoint from rehearsal
