# Team Collaboration Config

This section helps multi-person conference teams coordinate a Claude Code session without stepping on each other. The most common failure pattern in collaborative demos is not technical. It is ambiguous ownership. When one person thinks they are steering recovery and another person thinks they are narrating, the audience experiences hesitation immediately.

## Recommended Roles
- Lead presenter: owns narrative and audience pacing
- Terminal operator: owns command execution and visible recovery
- Producer or floater: monitors time, chat, and room drift

## Suggested Workflow
Define checkpoints before rehearsal, assign who speaks during failure recovery, and document what triggers a handoff. Use the supporting templates in this folder to keep those choices consistent across sessions.
