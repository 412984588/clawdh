# Role Map

## Presenter
Owns story, pacing, and attendee framing.

## Operator
Owns terminal execution, log inspection, and technical recovery.

## Producer
Owns time checks, attendee queueing, and artifact capture.

## Escalation Rule
If a recovery path exceeds ninety seconds, the producer calls the fallback and the presenter moves the narrative forward.

## Coordination Notes
The three roles should behave like a relay team, not three people improvising in parallel. The presenter keeps the audience oriented, the operator protects technical correctness, and the producer keeps the room and the clock from silently drifting off course. When these boundaries are explicit, the demo feels calm even when something goes wrong.

## Review Cadence
Review the role map before rehearsal, after rehearsal, and once more before show time. Small role confusion in rehearsal becomes visible friction on stage.
