# Conference-Ready CLAUDE.md

## Goal
Deliver a reliable, audience-friendly Claude Code session that proves one clear workflow, recovers quickly from failure, and leaves attendees with practical next steps they can repeat after the event. This template is written for stage demos, workshops, lab sessions, and conference booth conversations where time pressure and environmental noise make vague instructions dangerous.

## Workflow
1. Start by restating the session promise in one sentence and define what success looks like for the audience.
2. Confirm the known-good demo path before branching into optional examples or attendee questions.
3. Narrate intent before each command so the room can follow even if the screen momentarily lags.
4. Use short checkpoints after each meaningful action and verify output before moving on.
5. If anything fails, switch to the preplanned recovery path instead of improvising a new architecture in public.
6. End with a recap, artifact handoff, and one practical action attendees should take next.

## Guardrails
- Prefer stable, local workflows over flashy but brittle cloud dependencies.
- Never expose secrets, raw credentials, or personal messages on screen.
- Keep commands copyable and explain which lines are safe to reuse.
- Choose one narrative thread; do not branch into side quests unless time is protected.
- If the room gets stuck, optimize for shared recovery, not individual perfection.

## Presenter Notes
- Open with the user problem, not the tool feature list.
- Maintain a visible fallback repo state you can return to between demos.
- Keep one teammate or producer informed of the next checkpoint if you are not presenting solo.
- Prepare a concise answer for why Claude Code is the right tool for this workflow.
