# MCP Quick Config Guide

## When To Use
Use this guide when you need a workshop-safe path for Model Context Protocol setup and validation. It is designed for live environments where attendees may have different machines, different auth states, and different levels of terminal confidence.

## Core Setup Flow
1. Confirm the MCP server list before the session and remove anything you will not demonstrate.
2. Validate one known-good tool call per server during rehearsal.
3. Document the local config path and the exact command attendees should run first.
4. Prepare a fallback demo path that works even if one MCP server is unavailable.

## Workshop Advice
- Group MCP servers into required, nice-to-have, and optional tiers.
- Show attendees how to verify availability before they try advanced examples.
- Keep one slide or handout with absolute paths, config filenames, and common auth steps.
- Prefer boring, deterministic tools over “wow” integrations that fail half the time on shared Wi-Fi.

## Common Failure Patterns
- Server installed but not referenced by the active config file.
- Auth present on the presenter laptop but missing on participant machines.
- Tool commands work in one shell but not from the project environment.
- A demo relies on network access the venue does not provide consistently.
