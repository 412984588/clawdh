# Demo Triage Skill

## Use When
Use when a live command fails and you need a fast path to diagnosis without losing audience trust.

## What It Does
This skill gives the facilitator a repeatable micro-playbook for high-pressure workshop moments. It reduces improvisation, keeps language consistent, and helps the room recover together instead of scattering into one-off fixes that burn time and trust.

## Suggested Steps
1. Restate the issue in plain language so the whole room shares the same diagnosis.
2. Isolate whether the problem is environment, prompt design, or repo state.
3. Apply the smallest recovery step that returns most attendees to the same checkpoint.
4. Announce the next visible validation step before anyone starts typing again.
5. Capture the issue for the post-session FAQ or handout if it is likely to repeat.

## Facilitation Notes
- Keep instructions short enough to say aloud without reading a paragraph.
- Prefer room-wide fixes to heroic one-machine debugging.
- Mark the moment when it is better to move on and share an after-session remedy.
