# Workshop Demo Project Template

This folder models a compact rehearsal project for a Claude Code workshop. It is intentionally small enough to explain on stage and structured enough to support dry runs with a producer, facilitator, or co-presenter. The aim is not to ship a real product here. The aim is to provide a stable sandbox where you can practice prompt framing, demo resets, and attendee handoffs without risking your main client or conference repository.

## Included Files
- `CLAUDE.md` for demo-specific execution rules
- `IMPLEMENTATION_PLAN.md` for the live session arc
- `RESET-CHECKLIST.md` for between-run cleanup

## How To Use
Clone the structure into a rehearsal repo, swap in your own stack, and time a full walkthrough. Note where Claude Code helps the story and where you should simplify before presenting to a real audience.
