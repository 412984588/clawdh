# Implementation Plan

## Session Arc
1. Introduce the repo and the audience problem.
2. Show the baseline state and define what will change.
3. Use Claude Code to plan the modification.
4. Apply the change with visible verification.
5. Summarize what Claude handled, what the operator decided, and what attendees can reuse.

## Timing Notes
- Intro: 2 minutes
- Build step: 6 minutes
- Verification: 2 minutes
- Questions and recap: 5 minutes

## Fallback
If time is compressed, skip the optional variation and move directly to the verified final state.
