# Demo Project CLAUDE.md

## Goal
Keep the rehearsal project stable enough to demonstrate one end-to-end workflow repeatedly while still showing authentic Claude Code usage. The demo should be easy to reset, easy to narrate, and easy for another presenter to inherit if you need backup.

## Workflow
1. Start from the known-good project state and announce the exact task for this run.
2. Apply one meaningful change at a time and verify the result immediately.
3. Keep logs and terminal output visible only when they advance the lesson.
4. If the demo slips, revert to the reset checklist instead of debugging forever.
5. Save the final state and the exact prompts that produced it for later replay.

## Guardrails
- Never introduce secrets or machine-specific paths into the demo repository.
- Keep the visible project surface smaller than the temptation to over-explain it.
- Rehearse handoffs so another facilitator can continue from the same checkpoint.
