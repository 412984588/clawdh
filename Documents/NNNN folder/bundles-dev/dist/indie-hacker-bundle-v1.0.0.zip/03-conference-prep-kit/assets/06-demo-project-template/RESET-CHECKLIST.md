# Reset Checklist

## How To Use
Run this short reset between rehearsals, between breakout groups, or before a second conference demo on the same day.

- [ ] Restore the repo to the known-good tag or branch.
- [ ] Reopen the terminal in the correct working directory.
- [ ] Clear stale output panes and local temp files.
- [ ] Confirm the first validation command still passes.
- [ ] Recheck projector-safe font size and visible windows.
- [ ] Confirm any required MCP tools still answer a known-good request.
