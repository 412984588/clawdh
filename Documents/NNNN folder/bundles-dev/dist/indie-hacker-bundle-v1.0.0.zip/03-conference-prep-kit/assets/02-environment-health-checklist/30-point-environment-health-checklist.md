# 30-Point Environment Health Checklist

## How To Use
Run this checklist twenty-four hours before travel, again after arriving at the venue, and once more in the final pre-session window. The goal is not to create ceremony. The goal is to make every hidden dependency visible before an audience discovers it for you.

## Checklist
- [ ] Confirm Claude Code is installed and launches without login prompts.
- [ ] Verify the demo repository opens from a clean terminal session.
- [ ] Run the first command path once before rehearsal.
- [ ] Confirm Python or Node versions match the demo instructions.
- [ ] Verify the package manager cache does not trigger surprise installs.
- [ ] Check internet access for the venue and your hotspot fallback.
- [ ] Confirm Git credentials are already authenticated for the repo flow.
- [ ] Verify any required API keys are injected through a safe local path.
- [ ] Test microphone input if you plan to narrate while typing.
- [ ] Set terminal font size for the back row, not just your laptop.
- [ ] Confirm screen sharing does not hide the command line cursor.
- [ ] Disable disruptive desktop notifications before show time.
- [ ] Prepare a local copy of all docs in case venue Wi-Fi fails.
- [ ] Verify sample data files are present in the demo repository.
- [ ] Run lint or tests once so the first pass is not painfully slow live.
- [ ] Check the fallback branch or tag you can reset to between demos.
- [ ] Verify the editor theme has strong contrast on projector hardware.
- [ ] Confirm browser tabs are minimal and ordered if any are required.
- [ ] Validate any MCP server starts locally and returns one known-good call.
- [ ] Prepare a no-network fallback story for tool-dependent moments.
- [ ] Check battery and power cable reach for the stage or workshop table.
- [ ] Confirm the demo account has permissions needed for the workflow.
- [ ] Prepare one short success path and one deeper branch if time allows.
- [ ] Verify copy-paste buffers do not contain secrets from earlier work.
- [ ] Test the exact prompt that opens the session narrative.
- [ ] Write down the three recovery commands you can run from memory.
- [ ] Confirm a teammate knows when to jump in if the demo stalls.
- [ ] Verify handout links or QR codes resolve from a mobile device.
- [ ] Prepare the closing CTA for attendees before the session starts.
- [ ] Run one full rehearsal with a timer and note every fragile step.

## Recovery Notes
Circle the items that failed during rehearsal and write the fallback beside them. The strongest presenters are not the ones with zero issues. They are the ones who know exactly which issues matter, which can be ignored, and which recovery path keeps the audience moving.
