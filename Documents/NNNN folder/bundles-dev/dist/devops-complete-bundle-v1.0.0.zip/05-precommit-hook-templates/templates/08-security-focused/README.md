# Security Focused — Pre-commit Config

Security-first pre-commit config. Blocks secrets, scans for vulnerable dependencies, and runs static analysis.

## Hooks

| Hook | What it does |
|------|-------------|
| `detect-private-key` | Block PEM/SSH private keys |
| `no-commit-to-branch` | Prevent direct commits to main/master |
| `detect-secrets` | Entropy-based secret scanning (AWS keys, tokens, passwords) |
| `bandit` | Python security linter (SQL injection, shell injection, etc.) |
| `pip-audit` | Check Python dependencies for known CVEs |
| `semgrep` | Multi-language static analysis with community rules |

## Usage

```bash
cp .pre-commit-config.yaml /your-project/
# Initialize secrets baseline (scan current files, mark as known)
detect-secrets scan > .secrets.baseline
pre-commit install
pre-commit run --all-files
```

## Requirements

```bash
pip install pre-commit detect-secrets bandit[toml] pip-audit semgrep
```

## Notes

- Run `detect-secrets scan > .secrets.baseline` before first install — otherwise every existing secret pattern triggers a failure
- `semgrep` uses `--config auto` which downloads community rules; for offline use, specify a local ruleset
