# Python Basic — Pre-commit Config

Standard pre-commit config for Python projects (FastAPI, Flask, scripts, libraries).

## Hooks

| Hook | What it does |
|------|-------------|
| `trailing-whitespace` | Remove trailing spaces |
| `end-of-file-fixer` | Ensure files end with newline |
| `check-yaml` / `check-json` / `check-toml` | Validate config files |
| `check-added-large-files` | Block files >500 KB |
| `detect-private-key` | Block accidental key commits |
| `ruff` | Fast Python linter (replaces flake8/isort/pyupgrade) with auto-fix |
| `ruff-format` | Code formatter (replaces black) |
| `mypy` | Static type checker |

## Usage

```bash
cp .pre-commit-config.yaml /your-python-project/
pre-commit install
pre-commit run --all-files
```

## Requirements

```bash
pip install pre-commit ruff mypy
```
