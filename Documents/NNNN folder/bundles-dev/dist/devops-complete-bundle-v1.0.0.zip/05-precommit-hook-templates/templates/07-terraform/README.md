# Terraform — Pre-commit Config

Pre-commit config for Terraform infrastructure projects. Enforces formatting, validates configs, and runs security checks.

## Hooks

| Hook | What it does |
|------|-------------|
| `terraform_fmt` | Auto-format all `.tf` files |
| `terraform_validate` | Validate Terraform config |
| `terraform_docs` | Auto-generate/update `README.md` from variables and outputs |
| `terraform_tflint` | Lint for deprecated syntax, undocumented variables, pinned modules |
| `checkov` | Static analysis for security misconfigurations |

## Usage

```bash
cp .pre-commit-config.yaml /your-terraform-project/
pre-commit install
pre-commit run --all-files
```

## Requirements

```bash
pip install pre-commit checkov
brew install terraform tflint terraform-docs
```

## Customization

```yaml
# Disable terraform_docs if not needed
hooks:
  - id: terraform_fmt
  - id: terraform_validate
  - id: terraform_tflint
```
