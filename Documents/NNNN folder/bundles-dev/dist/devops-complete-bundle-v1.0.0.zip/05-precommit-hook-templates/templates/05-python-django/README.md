# Python Django — Pre-commit Config

Pre-commit config for Django projects, extending the Python basic config with Django-specific checks.

## Hooks

All hooks from `01-python-basic`, plus:

| Hook | What it does |
|------|-------------|
| `django-upgrade` | Auto-upgrade Django code to target version syntax |
| `django-check` | Run `manage.py check` (catches config errors) |
| `django-migrations-check` | Fail if unapplied migrations exist |

## Usage

```bash
cp .pre-commit-config.yaml /your-django-project/
pre-commit install
pre-commit run --all-files
```

## Requirements

```bash
pip install pre-commit ruff mypy django-stubs types-requests django-upgrade
```

## Customization

```yaml
# Change Django target version
- id: django-upgrade
  args: ["--target-version", "4.2"]  # or "5.0", "5.1"
```

## Notes

`django-check` and `django-migrations-check` use `language: system` — they run in your active virtualenv. Run `pre-commit` from within your venv or set `DJANGO_SETTINGS_MODULE` appropriately.
