# Go App — Pre-commit Config

Pre-commit config for Go applications and libraries.

## Hooks

| Hook | What it does |
|------|-------------|
| `trailing-whitespace` | Remove trailing spaces |
| `end-of-file-fixer` | Ensure files end with newline |
| `detect-private-key` | Block accidental key commits |
| `go-fmt` | Run `gofmt` on changed files |
| `go-vet` | Run `go vet` |
| `go-imports` | Fix import grouping with `goimports` |
| `go-mod-tidy` | Keep `go.mod` and `go.sum` tidy |
| `golangci-lint` | Run `golangci-lint` with auto-fix |

## Usage

```bash
cp .pre-commit-config.yaml /your-go-project/
pre-commit install
pre-commit run --all-files
```

## Requirements

```bash
pip install pre-commit
# Go tools
go install golang.org/x/tools/cmd/goimports@latest
go install github.com/golangci/golangci-lint/cmd/golangci-lint@latest
```
