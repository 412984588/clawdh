# Docs & Markdown — Pre-commit Config

Pre-commit config for documentation-heavy repositories and projects with significant Markdown content.

## Hooks

| Hook | What it does |
|------|-------------|
| `trailing-whitespace` / `end-of-file-fixer` | Whitespace cleanup |
| `check-added-large-files` | Block files >2 MB |
| `markdownlint` | Lint Markdown style (headings, lists, code blocks) with auto-fix |
| `prettier` | Format Markdown files consistently |
| `lychee` | Check all links in Markdown and HTML for broken URLs |

## Usage

```bash
cp .pre-commit-config.yaml /your-docs-project/
pre-commit install
pre-commit run --all-files
```

## Requirements

```bash
pip install pre-commit
npm install --save-dev markdownlint-cli prettier
brew install lychee  # or: cargo install lychee
```

## Customization

```yaml
# Add .markdownlint.yaml to configure rules
# Exclude CHANGELOG from markdownlint (it often has non-standard format)
- id: markdownlint
  exclude: "CHANGELOG.md|node_modules"
```
