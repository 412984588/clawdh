# Node.js + TypeScript — Pre-commit Config

Pre-commit config for Node.js and TypeScript projects (Express, Fastify, NestJS, CLI tools).

## Hooks

| Hook | What it does |
|------|-------------|
| `trailing-whitespace` | Remove trailing spaces |
| `end-of-file-fixer` | Ensure files end with newline |
| `detect-private-key` | Block accidental key commits |
| `prettier` | Format JS/TS/CSS/JSON/YAML/Markdown |
| `eslint` | Lint and auto-fix JS/TS files |
| `tsc` | TypeScript type check (no emit) |

## Usage

```bash
cp .pre-commit-config.yaml /your-node-project/
pre-commit install
pre-commit run --all-files
```

## Requirements

```bash
pip install pre-commit
npm install --save-dev prettier eslint typescript
```

## Notes

`eslint` and `tsc` use `local` hooks — they run via `npx` using your project's installed versions. Make sure `.eslintrc.*` and `tsconfig.json` are present.
