# General Repo — Pre-commit Config

Language-agnostic baseline config. Works with any project — good starting point before adding language-specific hooks.

## Hooks

| Hook | What it does |
|------|-------------|
| `trailing-whitespace` | Remove trailing spaces |
| `end-of-file-fixer` | Ensure files end with newline |
| `check-yaml` | Validate YAML files |
| `check-json` | Validate JSON files |
| `check-toml` | Validate TOML files |
| `check-xml` | Validate XML files |
| `check-added-large-files` | Block files >1 MB |
| `check-merge-conflict` | Block unresolved merge conflict markers |
| `check-case-conflict` | Catch case-insensitive filename conflicts |
| `detect-private-key` | Block accidental key commits |
| `mixed-line-ending` | Normalize to LF |
| `no-commit-to-branch` | Prevent direct commits to main/master |
| `commitizen` | Enforce conventional commit messages |

## Usage

```bash
cp .pre-commit-config.yaml /any-project/
pre-commit install
pre-commit install --hook-type commit-msg  # for commitizen
pre-commit run --all-files
```

## Requirements

```bash
pip install pre-commit commitizen
```
