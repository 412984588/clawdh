# React App — Pre-commit Config

Pre-commit config for React and frontend projects (Vite, CRA, Next.js frontend layer).

## Hooks

| Hook | What it does |
|------|-------------|
| `trailing-whitespace` / `end-of-file-fixer` | Whitespace cleanup |
| `detect-private-key` | Block accidental key commits |
| `prettier` | Format JS/TS/CSS/SCSS/JSON/YAML/Markdown |
| `eslint` | Lint and auto-fix JS/TS/JSX/TSX |
| `stylelint` | Lint and auto-fix CSS/SCSS |
| `tsc` | TypeScript type check across the project |

## Usage

```bash
cp .pre-commit-config.yaml /your-react-project/
pre-commit install
pre-commit run --all-files
```

## Requirements

```bash
pip install pre-commit
npm install --save-dev prettier eslint stylelint typescript
```
