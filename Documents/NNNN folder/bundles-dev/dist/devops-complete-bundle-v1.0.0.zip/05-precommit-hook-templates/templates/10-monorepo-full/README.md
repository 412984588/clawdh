# Monorepo Full — Pre-commit Config

Combined pre-commit config for monorepos containing Python, JavaScript/TypeScript, and Terraform. Uses file path filters to apply the right hooks to the right packages.

## Hooks

| Scope | Hook | Applies to |
|-------|------|-----------|
| Universal | `trailing-whitespace`, `end-of-file-fixer`, `detect-private-key`, `no-commit-to-branch` | All files |
| Universal | `check-yaml/json/toml`, `check-added-large-files`, `mixed-line-ending` | All files |
| Python | `ruff`, `ruff-format` | `packages/**/*.py` |
| JS/TS | `prettier` | `packages/**/*.{js,ts,css,...}` |
| JS/TS | `eslint`, `tsc` | `packages/**/*.{js,ts}` |
| Terraform | `terraform_fmt`, `terraform_validate` | `infra/**` |
| Security | `detect-secrets` | All files |

## Usage

```bash
cp .pre-commit-config.yaml /your-monorepo/
# Initialize secrets baseline
detect-secrets scan > .secrets.baseline
pre-commit install
pre-commit run --all-files
```

## Customization

Adjust the `files:` regex patterns to match your monorepo structure:

```yaml
# If your packages are in "apps/" instead of "packages/"
files: "^apps/.*\\.py$"
```

## Requirements

```bash
pip install pre-commit ruff detect-secrets
npm install --save-dev prettier eslint typescript
brew install terraform
```
