# Changelog

## [1.0.0] — 2026-03-21

### Added

- `01-python-basic`: Python project hooks — ruff, black, mypy, isort, trailing-whitespace, end-of-file-fixer
- `02-node-typescript`: Node.js/TypeScript hooks — prettier, eslint, tsc (no-emit), commitlint
- `03-go-app`: Go project hooks — gofmt, go-vet, golangci-lint, go-mod-tidy
- `04-general-repo`: Language-agnostic baseline — trailing-whitespace, end-of-file-fixer, check-yaml, check-json, check-toml, detect-private-key, mixed-line-ending
- `05-python-django`: Django-specific additions — safety, bandit, django-upgrade, migration check
- `06-react-app`: React/frontend hooks — prettier, eslint, stylelint, tsc, import-sort
- `07-terraform`: Infrastructure hooks — terraform-fmt, tflint, checkov, tfsec
- `08-security-focused`: Security-first config — detect-secrets, bandit, semgrep, pip-audit, safety
- `09-docs-markdown`: Documentation hooks — markdownlint, prettier (markdown), check-added-large-files, vale
- `10-monorepo-full`: Combined config for monorepos — all hooks with file path filters
