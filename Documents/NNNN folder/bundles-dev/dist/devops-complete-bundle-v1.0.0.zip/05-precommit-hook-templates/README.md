# Pre-commit Hook Templates

10 ready-to-use `.pre-commit-config.yaml` files for Python, Node.js, Go, React, Terraform, and more. Drop one in your repo, run `pre-commit install`, and every commit gets automatically checked.

## Included Templates

| # | Template | Key Hooks |
|---|----------|-----------|
| 01 | python-basic | ruff, black, mypy, isort, trailing-whitespace |
| 02 | node-typescript | prettier, eslint, tsc, commitlint |
| 03 | go-app | gofmt, go-vet, golangci-lint, go-mod-tidy |
| 04 | general-repo | trailing-whitespace, check-yaml/json/toml, detect-private-key |
| 05 | python-django | + safety, bandit, django-upgrade |
| 06 | react-app | prettier, eslint, stylelint, tsc |
| 07 | terraform | terraform-fmt, tflint, checkov, tfsec |
| 08 | security-focused | detect-secrets, bandit, semgrep, pip-audit |
| 09 | docs-markdown | markdownlint, prettier, check-added-large-files |
| 10 | monorepo-full | All hooks with path-based file filters |

## Tiers

| Tier | Price | Templates |
|------|-------|-----------|
| Starter | $19 | 01–04 (Python, Node, Go, General) |
| Pro | $39 | All 10 templates |

## Quick Start

```bash
# Copy a config to your project root
cp templates/01-python-basic/.pre-commit-config.yaml ./

# Install pre-commit (if not already installed)
pip install pre-commit

# Install the hooks
pre-commit install

# Run against all files once
pre-commit run --all-files
```

## Requirements

`pre-commit` 3.x: `pip install pre-commit` or `brew install pre-commit`

## License

MIT — use on unlimited personal and commercial projects.
