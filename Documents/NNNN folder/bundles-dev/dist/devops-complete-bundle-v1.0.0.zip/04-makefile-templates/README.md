# Makefile Templates for Developer Workflows

10 production-ready Makefiles for Node.js, Python, Go, React, Next.js, Docker, Terraform, monorepos, CI helpers, and release automation. Drop one into any project and start using `make` immediately.

## Included Templates

| # | Template | Key Targets |
|---|----------|-------------|
| 01 | node-app | install, dev, test, build, lint, docker, clean |
| 02 | python-app | venv, install, lint, type-check, test, docker, clean |
| 03 | go-app | build, test, vet, race, lint, docker, clean |
| 04 | react-frontend | install, dev, build, test, lint, preview |
| 05 | next-app | install, dev, build, start, lint, type-check |
| 06 | docker-project | up, down, logs, shell, rebuild, clean |
| 07 | terraform-infra | init, fmt, validate, plan, apply, destroy |
| 08 | monorepo | bootstrap, test-all, build-all, lint-all, publish |
| 09 | ci-helpers | check-env, version-bump, tag, notify |
| 10 | release-automation | changelog, tag, publish, draft-release |

## Tiers

| Tier | Price | Templates |
|------|-------|-----------|
| Starter | $19 | 01–04 (Node, Python, Go, React) |
| Pro | $39 | All 10 templates |

## Usage

```bash
# Copy a Makefile to your project root
cp templates/01-node-app/Makefile ./Makefile

# See all available targets
make help

# Common workflow
make install
make test
make build
```

## Design Principles

- Every Makefile has a `help` target that lists available targets with descriptions
- `.PHONY` declared for all non-file targets
- Variables at the top for easy customization
- Color output for readability
- Works on macOS and Linux (bash-compatible)

## License

MIT — use on unlimited personal and commercial projects.
