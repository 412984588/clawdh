# Changelog

## [1.0.0] — 2026-03-21

### Added

- `01-node-app`: Node.js application Makefile (install, dev, test, build, lint, docker, clean)
- `02-python-app`: Python application Makefile (venv, install, lint, type-check, test, docker, clean)
- `03-go-app`: Go application Makefile (build, test, vet, race, lint, docker, clean)
- `04-react-frontend`: React frontend Makefile (install, dev, build, test, lint, preview)
- `05-next-app`: Next.js application Makefile (install, dev, build, start, lint, type-check)
- `06-docker-project`: Docker Compose project Makefile (up, down, logs, shell, rebuild, clean)
- `07-terraform-infra`: Terraform infrastructure Makefile (init, fmt, validate, plan, apply, destroy)
- `08-monorepo`: Monorepo Makefile (bootstrap, test-all, build-all, lint-all, publish)
- `09-ci-helpers`: CI utility Makefile (check-env, version-bump, tag, notify)
- `10-release-automation`: Release automation Makefile (changelog, tag, publish, draft-release)
