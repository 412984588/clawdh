# Node.js App Makefile

Standard Makefile for Node.js applications (Express, Fastify, NestJS, etc.).

## Targets

| Target | Description |
|--------|-------------|
| `make install` | `npm ci` |
| `make dev` | Start dev server with hot reload |
| `make test` | Run test suite |
| `make test-watch` | Run tests in watch mode |
| `make build` | Compile/bundle for production |
| `make lint` | Check code style |
| `make lint-fix` | Auto-fix lint issues |
| `make docker` | Build Docker image |
| `make docker-run` | Run Docker container with `.env` |
| `make clean` | Remove build artifacts and node_modules |

## Usage

```bash
cp Makefile /your-project/
make install
make dev
```

## Customization

```makefile
# Override at the top of Makefile or on command line
NODE_ENV=production make build
IMAGE=myapp TAG=v1.2.3 make docker
```
