# Release Automation Makefile

Automates the full release workflow: CHANGELOG generation, git tagging, GitHub Release, npm publish, and Docker image push.

## Targets

| Target | Description |
|--------|-------------|
| `make changelog` | Print CHANGELOG entry from git log |
| `make tag-release` | Create annotated tag from VERSION and push |
| `make draft-release` | Create GitHub draft release with notes |
| `make publish` | Publish to npm |
| `make docker-publish` | Build and push Docker image with VERSION tag |
| `make full-release` | Run tag + draft-release + docker-publish |

## Usage

```bash
cp Makefile /your-project/
# Edit VERSION file to new version
echo "1.2.0" > VERSION
make changelog    # Preview what will go in release notes
make full-release # Tag, GitHub release, Docker push
```

## Requirements

- `gh` CLI for GitHub release creation (`brew install gh`)
- Docker logged in to registry (`docker login ghcr.io`)
- npm logged in (`npm login`) for publish target

## Customization

```bash
# Override registry and image name
REGISTRY=docker.io IMAGE=myorg/myapp make docker-publish
```
