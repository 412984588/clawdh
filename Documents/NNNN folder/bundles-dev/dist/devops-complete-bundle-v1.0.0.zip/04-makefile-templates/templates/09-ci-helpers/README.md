# CI Helpers Makefile

Utility targets for CI/CD workflows: environment validation, version management, and git tagging.

## Targets

| Target | Description |
|--------|-------------|
| `make check-env` | Verify required env vars are set |
| `make check-tools` | Verify required CLI tools are installed |
| `make version-current` | Print current version from VERSION file |
| `make version-bump-patch` | Bump patch (1.2.3 → 1.2.4) |
| `make version-bump-minor` | Bump minor (1.2.3 → 1.3.0) |
| `make version-bump-major` | Bump major (1.2.3 → 2.0.0) |
| `make tag` | Create annotated git tag and push |
| `make ci-status` | Show recent CI runs (requires `gh`) |

## Usage

```bash
cp Makefile /your-project/
# Add to your CI pipeline:
make check-env
make check-tools
```

## Customization

```makefile
# Override required env vars in Makefile
REQUIRED_ENV ?= DATABASE_URL REDIS_URL SECRET_KEY

# Or on command line
REQUIRED_ENV="API_KEY DB_URL" make check-env
```

## Version Workflow

```bash
# Release workflow
make version-bump-patch   # Update VERSION file
git add VERSION
git commit -m "chore: bump version"
make tag                  # Tag and push
```
