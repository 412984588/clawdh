# React Frontend Makefile

Standard Makefile for React applications using Vite.

## Targets

| Target | Description |
|--------|-------------|
| `make install` | `npm ci` |
| `make dev` | Start Vite dev server |
| `make build` | Production build to `dist/` |
| `make preview` | Preview production build locally |
| `make test` | Run Vitest once |
| `make test-watch` | Run Vitest in watch mode |
| `make lint` | ESLint check |
| `make lint-fix` | Auto-fix lint issues |
| `make type-check` | TypeScript check (no emit) |
| `make docker` | Build nginx Docker image serving `dist/` |
| `make clean` | Remove `dist/`, `node_modules/`, `coverage/` |

## Usage

```bash
cp Makefile /your-react-project/
make install
make dev
```

## Adapting for Create React App

Replace `npm run dev` with `npm start` and `npm run preview` can be removed.
