# Terraform Infrastructure Makefile

Standard Makefile for Terraform infrastructure projects with environment support.

## Targets

| Target | Description |
|--------|-------------|
| `make init` | Initialize providers and modules |
| `make init-upgrade` | Upgrade to latest allowed provider versions |
| `make fmt` | Format all `.tf` files |
| `make validate` | Validate configuration |
| `make plan` | Show execution plan |
| `make apply` | Apply changes (interactive) |
| `make apply-auto` | Apply without confirmation (CI) |
| `make destroy` | Destroy all managed infrastructure |
| `make workspace-new` | Create new workspace |
| `make workspace-select` | Switch workspace |
| `make output` | Show all outputs |
| `make state-list` | List state resources |
| `make clean` | Remove `.terraform/` and state files |

## Usage

```bash
cp Makefile /your-terraform-project/
make init
make plan
make apply
```

## Multi-Environment

```bash
# Plan for staging environment (reads environments/staging.tfvars if present)
ENV=staging make plan

# Apply to production
ENV=prod make apply
```

## Workspaces

```bash
ENV=staging make workspace-new
ENV=staging make plan
```
