# Python App Makefile

Standard Makefile for Python applications (FastAPI, Flask, Django, CLI tools, etc.).

## Targets

| Target | Description |
|--------|-------------|
| `make venv` | Create `.venv` virtual environment |
| `make install` | Install production dependencies |
| `make install-dev` | Install all dependencies including dev tools |
| `make lint` | Run ruff linter |
| `make lint-fix` | Auto-fix lint issues |
| `make type-check` | Run mypy |
| `make test` | Run pytest |
| `make test-cov` | Run pytest with HTML coverage report |
| `make docker` | Build Docker image |
| `make docker-run` | Run Docker container with `.env` |
| `make clean` | Remove venv, cache, and build artifacts |

## Usage

```bash
cp Makefile /your-project/
make install-dev
make test
```

## Requirements

Expects `requirements.txt` and optionally `requirements-dev.txt`. Dev dependencies: `ruff`, `mypy`, `pytest`, `pytest-cov`.
