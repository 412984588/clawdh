# Monorepo Makefile

Standard Makefile for npm workspaces monorepos (also compatible with pnpm/yarn workspaces).

## Targets

| Target | Description |
|--------|-------------|
| `make bootstrap` | Install all workspace dependencies |
| `make build-all` | Build all packages |
| `make test-all` | Run tests in all packages |
| `make lint-all` | Lint all packages |
| `make type-check-all` | Type-check all packages |
| `make clean-all` | Remove build outputs |
| `make publish` | Build and publish all public packages |
| `make changed` | Show packages changed since last tag |
| `make graph` | Generate dependency graph SVG |

## Usage

```bash
cp Makefile /your-monorepo/
make bootstrap
make test-all
```

## Requirements

Expects `package.json` with `workspaces` configured:

```json
{
  "workspaces": ["packages/*"]
}
```

Each package should have `build`, `test`, `lint`, `type-check`, `clean` scripts defined where applicable. The `--if-present` flag skips packages that don't have a given script.
