# Docker Project Makefile

Standard Makefile for projects using Docker Compose.

## Targets

| Target | Description |
|--------|-------------|
| `make up` | Start all services (detached) |
| `make up-build` | Rebuild images and start |
| `make down` | Stop and remove containers |
| `make down-volumes` | Stop containers and delete volumes |
| `make restart` | Restart all services |
| `make logs` | Follow logs |
| `make ps` | Show running containers |
| `make shell` | Open shell in a container |
| `make pull` | Pull latest images |
| `make rebuild` | Force rebuild one service |
| `make clean` | Remove locally-built images |
| `make prune` | Docker system prune |

## Usage

```bash
cp Makefile /your-docker-project/
cp .env.example .env
make up
make logs
```

## Per-Service Operations

```bash
# Tail logs for one service
SERVICE=api make logs

# Open shell in running container
SERVICE=api make shell

# Rebuild just the api service
SERVICE=api make rebuild
```
