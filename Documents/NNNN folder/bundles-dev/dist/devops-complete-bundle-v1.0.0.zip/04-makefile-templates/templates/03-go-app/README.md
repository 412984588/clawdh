# Go App Makefile

Standard Makefile for Go applications and services.

## Targets

| Target | Description |
|--------|-------------|
| `make deps` | Download module dependencies |
| `make tidy` | Tidy and verify go.mod |
| `make build` | Build binary to `bin/` |
| `make build-linux` | Cross-compile for Linux amd64 |
| `make test` | Run `go test ./...` |
| `make test-race` | Run tests with race detector |
| `make test-cover` | Generate HTML coverage report |
| `make vet` | Run `go vet` |
| `make fmt` | Format with `gofmt` |
| `make lint` | Run `staticcheck` |
| `make docker` | Build Docker image |
| `make clean` | Remove `bin/` and coverage files |

## Usage

```bash
cp Makefile /your-go-project/
make deps
make build
./bin/app
```

## Customization

```bash
# Override binary name and entry point
BINARY=myservice MAIN=./cmd/server make build

# Cross-compile for multiple targets
GOOS=darwin GOARCH=arm64 go build -o bin/app-darwin-arm64 ./cmd/app
```

## Requirements

`staticcheck` for linting: `go install honnef.co/go/tools/cmd/staticcheck@latest`
