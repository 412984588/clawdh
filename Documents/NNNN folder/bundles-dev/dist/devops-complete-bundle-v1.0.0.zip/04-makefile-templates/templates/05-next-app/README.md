# Next.js App Makefile

Standard Makefile for Next.js applications (App Router or Pages Router).

## Targets

| Target | Description |
|--------|-------------|
| `make install` | `npm ci` |
| `make dev` | Start Next.js dev server with hot reload |
| `make build` | Production build (`.next/`) |
| `make start` | Start production server (requires build) |
| `make lint` | Run `next lint` |
| `make lint-fix` | Auto-fix lint issues |
| `make type-check` | TypeScript check (no emit) |
| `make test` | Run test suite |
| `make analyze` | Bundle analyzer (requires `@next/bundle-analyzer`) |
| `make docker` | Build Docker image |
| `make clean` | Remove `.next/`, `node_modules/` |

## Usage

```bash
cp Makefile /your-next-project/
make install
make dev
# Open http://localhost:3000
```

## Customization

```bash
# Change dev port
PORT=4000 make dev
```
