# GitHub Actions Workflow Pack

Production-ready GitHub Actions workflows for CI/CD, deployment, security, and more — copy-paste ready.

## What's Included

### Starter — $19

| Template | Contents |
|----------|----------|
| 01 — CI for Node.js | Standard CI + matrix across Node 18/20/22 |
| 02 — CI for Python | Standard CI with ruff, mypy, pytest, coverage |
| 03 — Deploy to Vercel | Preview + production deploy with PR comments |
| 04 — Build & Push Docker | ghcr.io publish with semantic tags |

### Pro — $39 (adds)

| Template | Contents |
|----------|----------|
| 05 — Release to npm | Tag-triggered npm publish + GitHub Release |
| 06 — Security Scans | CodeQL + dependency vulnerability review |
| 07 — Scheduled Jobs | Stale issues, dependency checks, cron jobs |

### Complete — $59 (adds)

| Template | Contents |
|----------|----------|
| 08 — Monorepo CI | Path-filtered CI — only run for changed packages |
| 09 — Deploy to AWS | ECS Fargate deploy + S3/CloudFront static site |
| 10 — Advanced Patterns | Reusable workflows, concurrency, dynamic matrix |

## Quick Start

1. Find the workflow matching your use case
2. Copy the `.yml` file to `.github/workflows/` in your project
3. Add required secrets (documented in each template's README)
4. Push to trigger

## Pricing

| Tier | Price | Workflows |
|------|-------|-----------|
| Starter | $19 | 4 workflow sets |
| Pro | $39 | 7 workflow sets |
| Complete | $59 | All 10 workflow sets |

## License

MIT — use in unlimited projects, commercial or personal.
