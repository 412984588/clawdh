# PR Labeler

Auto-labels PRs based on which files/directories were changed.

## Required Secrets
None — uses built-in `GITHUB_TOKEN`.

## Setup

Create `.github/labeler.yml` in your repository:

```yaml
# .github/labeler.yml

frontend:
  - changed-files:
    - any-glob-to-any-file: "src/components/**"
    - any-glob-to-any-file: "src/pages/**"
    - any-glob-to-any-file: "*.css"

backend:
  - changed-files:
    - any-glob-to-any-file: "src/api/**"
    - any-glob-to-any-file: "src/server/**"

database:
  - changed-files:
    - any-glob-to-any-file: "prisma/**"
    - any-glob-to-any-file: "migrations/**"

docs:
  - changed-files:
    - any-glob-to-any-file: "docs/**"
    - any-glob-to-any-file: "*.md"

ci:
  - changed-files:
    - any-glob-to-any-file: ".github/**"
```

## Notes
- Labels must already exist in the repository before they can be applied
- `sync-labels: true` removes labels when files no longer match the pattern
