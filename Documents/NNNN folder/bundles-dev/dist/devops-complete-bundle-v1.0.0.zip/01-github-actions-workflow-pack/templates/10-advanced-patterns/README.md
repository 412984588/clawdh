# 10 — Advanced Patterns

Advanced GitHub Actions patterns for complex workflows.

## Files

| File | Purpose |
|------|---------|
| `reusable-workflow.yml` | Reusable workflow called from other workflows |
| `workflow-caller.yml` | Example caller of the reusable workflow |
| `concurrency.yml` | Cancel in-progress runs on new push |
| `dynamic-matrix.yml` | Build matrix from JSON output of a previous step |

## Patterns Covered

### Reusable Workflows
Define a workflow once, call it from multiple repos or workflows. Reduces duplication for standard CI/CD steps.

### Concurrency Control
Prevent multiple deployments running simultaneously. Cancel in-progress preview deploys when a new push arrives.

### Dynamic Matrix
Generate the build matrix at runtime from a script output — useful when the list of packages or services changes dynamically.

### Workflow Composition
Chain workflows: `trigger-tests` → `on test success → trigger-deploy` using `workflow_run` trigger.
