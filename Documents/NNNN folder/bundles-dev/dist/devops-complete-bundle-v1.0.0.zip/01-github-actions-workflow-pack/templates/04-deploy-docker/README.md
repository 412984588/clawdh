# 04 — Build & Push Docker Image

Build a Docker image and push to GitHub Container Registry (ghcr.io) on every merge to main.

## Files

| File | Purpose |
|------|---------|
| `docker-publish.yml` | Build + push to ghcr.io with semantic tags |

## How It Works

1. Builds the Docker image from `Dockerfile` in repo root
2. Tags with: `latest`, git SHA, and semver tag (if triggered by a tag push)
3. Pushes to `ghcr.io/<owner>/<repo>`

## No Secrets Required

Uses `GITHUB_TOKEN` (automatic) for ghcr.io authentication — no setup needed.

## Triggering a Tagged Release

```bash
git tag v1.2.3
git push origin v1.2.3
```

This produces image tags: `latest`, `sha-abc1234`, `1.2.3`, `1.2`, `1`.
