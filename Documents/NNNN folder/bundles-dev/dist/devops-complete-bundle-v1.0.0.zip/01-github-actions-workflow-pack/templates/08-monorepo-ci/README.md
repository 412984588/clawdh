# 08 — Monorepo CI

Efficient GitHub Actions CI for monorepos using path filtering — only run CI for changed packages.

## Files

| File | Purpose |
|------|---------|
| `monorepo-ci.yml` | Run CI only for packages affected by the PR |
| `all-packages-ci.yml` | Full CI for all packages (use on main merges) |

## How Path Filtering Works

Using `dorny/paths-filter`, the workflow detects which packages changed and only runs CI for those. A PR changing only `packages/ui` won't trigger CI for `packages/api`.

## Structure Assumed

```
packages/
  api/     ← has its own package.json + test script
  web/     ← has its own package.json + test script
  ui/      ← has its own package.json + test script
```

Adjust the `filters` section in `monorepo-ci.yml` to match your package names and paths.

## Turborepo / pnpm

If using Turborepo, the `turbo run test --filter=...[HEAD^1]` pattern is even more powerful — see the README comments in the workflow file.
