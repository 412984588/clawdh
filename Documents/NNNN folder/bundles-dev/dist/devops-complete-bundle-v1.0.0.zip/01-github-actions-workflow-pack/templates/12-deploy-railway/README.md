# Deploy — Railway

Deploys to Railway on push to main using the Railway CLI.

## Required Secrets & Variables
| Name | Type | Where |
|------|------|-------|
| `RAILWAY_TOKEN` | Secret | railway.com → Account Settings → Tokens |
| `RAILWAY_SERVICE` | Variable | GitHub → Settings → Variables → Actions |

## Setup

```bash
# Get your Railway token from dashboard
# Set RAILWAY_SERVICE to your service name (e.g. "my-api")
```

## Customization

```yaml
# Deploy to a specific environment
run: railway up --service=${{ vars.RAILWAY_SERVICE }} --environment=staging --detach

# Wait for deployment to complete (remove --detach)
run: railway up --service=${{ vars.RAILWAY_SERVICE }}
```
