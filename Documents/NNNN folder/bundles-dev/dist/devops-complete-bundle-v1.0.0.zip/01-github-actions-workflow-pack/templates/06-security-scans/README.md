# 06 — Security Scans

Automated security scanning workflows for GitHub Actions.

## Files

| File | Purpose |
|------|---------|
| `codeql.yml` | GitHub CodeQL analysis — finds vulnerabilities in JS/TS/Python |
| `dependency-review.yml` | Block PRs that introduce vulnerable dependencies |

## CodeQL

CodeQL runs static analysis on your code to find security vulnerabilities. Results appear in the GitHub Security tab.

**Supported languages:** JavaScript, TypeScript, Python, Java, C#, Go, Ruby, Swift, C/C++

Update the `language` matrix in `codeql.yml` to match your project.

## Dependency Review

`dependency-review.yml` blocks PRs that add packages with known CVEs (critical or high severity by default). Requires GitHub Advanced Security (free for public repos).

## Schedule

CodeQL runs:
- On push to `main`
- On pull requests
- Weekly (Sunday midnight) — catches new CVEs in existing code
