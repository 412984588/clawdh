# 01 — CI for Node.js

GitHub Actions CI workflows for Node.js projects.

## Files

| File | Purpose |
|------|---------|
| `ci.yml` | Standard CI — install, lint, test, build |
| `ci-matrix.yml` | Matrix CI across Node.js 18/20/22 + OS |

## Setup

1. Copy the desired workflow to `.github/workflows/` in your project
2. Ensure your `package.json` has `test`, `lint`, and `build` scripts
3. Push to trigger

## Triggers

`ci.yml` runs on:
- Push to `main` or `develop`
- Pull requests to `main`

## Caching

Both workflows use `actions/cache` for `node_modules` keyed on `package-lock.json` hash — subsequent runs are significantly faster.
