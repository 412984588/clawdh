# 09 — Deploy to AWS

GitHub Actions workflows for deploying to AWS services.

## Files

| File | Purpose |
|------|---------|
| `deploy-ecs.yml` | Build Docker image and deploy to ECS Fargate |
| `deploy-s3-cloudfront.yml` | Deploy static site to S3 + invalidate CloudFront |

## Required Secrets (ECS)

| Secret | Description |
|--------|-------------|
| `AWS_ACCESS_KEY_ID` | IAM user access key |
| `AWS_SECRET_ACCESS_KEY` | IAM user secret key |
| `AWS_REGION` | e.g., `us-east-1` |
| `ECR_REPOSITORY` | ECR repository name |
| `ECS_SERVICE` | ECS service name |
| `ECS_CLUSTER` | ECS cluster name |
| `CONTAINER_NAME` | Container name in task definition |

## Required Secrets (S3 + CloudFront)

| Secret | Description |
|--------|-------------|
| `AWS_ACCESS_KEY_ID` | IAM user access key |
| `AWS_SECRET_ACCESS_KEY` | IAM user secret key |
| `AWS_REGION` | e.g., `us-east-1` |
| `S3_BUCKET` | S3 bucket name |
| `CLOUDFRONT_DISTRIBUTION_ID` | CloudFront distribution ID |

## IAM Permissions

Minimum IAM permissions are documented in each workflow file as comments.
