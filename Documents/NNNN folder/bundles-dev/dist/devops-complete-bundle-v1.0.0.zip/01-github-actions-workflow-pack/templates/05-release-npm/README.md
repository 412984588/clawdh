# 05 — Automated npm Release

Automate npm package publishing with semantic versioning using Changesets or release-it.

## Files

| File | Purpose |
|------|---------|
| `release-npm.yml` | Publish to npm when a version tag is pushed |
| `release-pr.yml` | Changesets — create Release PRs automatically |

## Required Secrets

| Secret | Where to find |
|--------|--------------|
| `NPM_TOKEN` | npmjs.com → Account → Access Tokens → Automation token |

## Workflow: Tag-Based Release

```bash
npm version patch  # or minor / major
git push --follow-tags
```

This triggers `release-npm.yml` which runs tests, builds, and publishes.

## Workflow: Changesets (recommended for libraries)

1. Install Changesets: `npm install -D @changesets/cli`
2. Initialize: `npx changeset init`
3. Add `release-pr.yml` to your repo
4. When PRs are merged, a Release PR is automatically created/updated
5. Merge the Release PR to publish
