# 02 — CI for Python

GitHub Actions CI workflows for Python projects.

## Files

| File | Purpose |
|------|---------|
| `ci.yml` | Standard CI — install, lint (ruff), test (pytest) |
| `ci-matrix.yml` | Matrix CI across Python 3.10/3.11/3.12 |

## Setup

1. Copy to `.github/workflows/`
2. Adjust Python version and dependency install command as needed
3. Workflow assumes `pytest` for tests and `ruff` for linting

## Dependency Managers

The workflow supports pip with `requirements.txt`. For Poetry or uv, see the comments in the file.
