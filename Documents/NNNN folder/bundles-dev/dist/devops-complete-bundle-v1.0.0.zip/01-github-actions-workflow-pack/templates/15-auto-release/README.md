# Auto Release

Uses [semantic-release](https://github.com/semantic-release/semantic-release) to automatically version, tag, generate a changelog, create a GitHub Release, and optionally publish to npm — all from commit message conventions.

## Required Secrets
| Secret | Required for |
|--------|-------------|
| `GITHUB_TOKEN` | Built-in — always available |
| `NPM_TOKEN` | Only if publishing to npm |

## Commit Convention
Uses Angular commit message format:

| Prefix | Release type |
|--------|-------------|
| `fix:` | Patch (1.0.**1**) |
| `feat:` | Minor (1.**1**.0) |
| `feat!:` or `BREAKING CHANGE:` | Major (**2**.0.0) |
| `chore:`, `docs:`, `style:`, `refactor:`, `test:` | No release |

## Setup
Add a `release.config.js` to your repo root:

```js
module.exports = {
  branches: ['main'],
  plugins: [
    '@semantic-release/commit-analyzer',
    '@semantic-release/release-notes-generator',
    '@semantic-release/changelog',
    '@semantic-release/npm',       // remove if not publishing
    '@semantic-release/github',
    ['@semantic-release/git', { assets: ['CHANGELOG.md', 'package.json'] }],
  ],
};
```
