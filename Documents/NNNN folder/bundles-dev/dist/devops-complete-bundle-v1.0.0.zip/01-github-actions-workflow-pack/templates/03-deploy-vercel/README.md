# 03 — Deploy to Vercel

Automated preview and production deployments to Vercel via GitHub Actions.

## Files

| File | Purpose |
|------|---------|
| `deploy-vercel.yml` | Preview deploy on PR, production deploy on merge to main |

## Required Secrets

Add these in your GitHub repo → Settings → Secrets:

| Secret | Where to find |
|--------|--------------|
| `VERCEL_TOKEN` | Vercel → Account Settings → Tokens |
| `VERCEL_ORG_ID` | `.vercel/project.json` after `vercel link` |
| `VERCEL_PROJECT_ID` | `.vercel/project.json` after `vercel link` |

## Setup

1. Install Vercel CLI: `npm i -g vercel`
2. Run `vercel link` in your project to generate `.vercel/project.json`
3. Copy the `orgId` and `projectId` values to GitHub secrets
4. Copy this workflow to `.github/workflows/`
