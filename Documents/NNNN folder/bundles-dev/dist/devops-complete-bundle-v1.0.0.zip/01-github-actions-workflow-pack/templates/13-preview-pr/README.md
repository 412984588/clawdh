# Preview — PR Deployment

Deploys a Vercel preview for every PR and posts (or updates) a comment with the URL.

## Required Secrets
| Secret | How to get |
|--------|-----------|
| `VERCEL_TOKEN` | vercel.com → Account Settings → Tokens |

## Behavior
- Opens/synchronizes PR → deploys preview and posts comment
- Re-synchronizes PR → updates the existing bot comment (no spam)

## Required Permissions
The workflow needs `pull-requests: write` to post comments. Ensure your repo allows Actions to create PR comments (Settings → Actions → General → Workflow permissions → Read and write).

## Customization

```yaml
# Add the PR number as a Vercel alias
- name: Alias preview URL
  run: vercel alias set ${{ steps.deploy.outputs.preview_url }} pr-${{ github.event.number }}.my-app.vercel.app --token=${{ secrets.VERCEL_TOKEN }}
```
