# Dependabot Auto-merge

Automatically approves and merges Dependabot PRs for minor and patch version updates. Major version updates require manual review.

## Required Secrets
None — uses built-in `GITHUB_TOKEN`.

## Required Repository Settings
- Enable **Allow auto-merge** in Settings → General → Pull Requests
- Enable **Require status checks to pass** in branch protection — auto-merge will wait for CI to pass

## Behavior
| Update type | Action |
|-------------|--------|
| Patch (`1.0.x`) | Approve + auto-merge |
| Minor (`1.x.0`) | Approve + auto-merge |
| Major (`x.0.0`) | No action — manual review required |

## Security Note
This only runs for `dependabot[bot]` PRs. Third-party PRs impersonating Dependabot cannot trigger this workflow due to GitHub's actor check.

## Customization

```yaml
# Only auto-merge patch updates (stricter)
if: steps.metadata.outputs.update-type == 'version-update:semver-patch'

# Auto-merge dev dependencies only
if: steps.metadata.outputs.dependency-type == 'direct:development'
```
