# Dependency Review

Blocks PRs that introduce dependencies with known vulnerabilities (HIGH or CRITICAL) or disallowed licenses.

## Required Secrets
None — uses built-in `GITHUB_TOKEN`.

## Requirements
- Repository must be public, or have GitHub Advanced Security enabled

## Configuration

```yaml
# Severity threshold (moderate | high | critical)
fail-on-severity: high

# License blocklist
deny-licenses: GPL-3.0, LGPL-3.0, AGPL-3.0

# Or use allowlist instead
allow-licenses: MIT, Apache-2.0, BSD-2-Clause, BSD-3-Clause, ISC
```

## Behavior
- Posts a summary comment on the PR with new/removed dependencies
- Fails the check if new dependencies have vulnerabilities at or above the threshold
- Helps enforce license compliance across PRs
