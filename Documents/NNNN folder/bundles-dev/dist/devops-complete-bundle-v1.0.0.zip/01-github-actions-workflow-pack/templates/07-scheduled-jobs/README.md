# 07 — Scheduled Jobs

Recurring GitHub Actions workflows using cron schedules.

## Files

| File | Purpose |
|------|---------|
| `stale-issues.yml` | Auto-close stale issues and PRs |
| `dependency-update.yml` | Weekly npm/pip dependency update check |
| `db-backup.yml` | Scheduled database backup (template) |

## Cron Syntax Quick Reference

```
┌───────────── minute (0-59)
│ ┌───────────── hour (0-23)
│ │ ┌───────────── day of month (1-31)
│ │ │ ┌───────────── month (1-12)
│ │ │ │ ┌───────────── day of week (0-6, Sun=0)
│ │ │ │ │
* * * * *

0 9 * * 1     # Every Monday at 9am UTC
0 0 * * 0     # Every Sunday at midnight UTC
0 */6 * * *   # Every 6 hours
```

## Note on Schedule Accuracy

GitHub may delay scheduled workflows by up to 30 minutes during high load.
