# CI — Go

Runs `go vet`, staticcheck, race-detector tests, and build across Go 1.22 and 1.23.

## Required Secrets
None — this workflow uses no secrets.

## Customization

```yaml
# Pin to single Go version
matrix:
  go-version: ["1.23"]

# Run tests with timeout
run: go test -v -race -timeout 5m ./...
```

## Notes
- `-race` flag enables the race detector — highly recommended for concurrent code
- `staticcheck` is a superset of `go vet`; remove it if you prefer a lighter setup
- Module caching is enabled via `cache: true` on `setup-go`
