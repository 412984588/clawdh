# Changelog

## [1.1.0] — 2026-03-21

### Added

- `11-ci-go`: Go CI with module caching, vet, staticcheck, and race detector
- `12-deploy-railway`: Automatic Railway deployments on push to main
- `13-preview-pr`: PR preview environments with bot comment updates (create or update on re-push)
- `14-dependency-review`: Block PRs that introduce high/critical vulnerabilities via dependency-review action
- `15-auto-release`: Semantic-release driven automatic versioning, changelog generation, and GitHub Release creation
- `16-pr-labeler`: Auto-label PRs based on changed files using actions/labeler
- `17-dependabot-auto-merge`: Automatically merge Dependabot minor/patch updates after CI passes

## [1.0.0] — 2024-01-01

### Added

- `01-ci-node`: Node.js CI with caching and matrix support
- `02-ci-python`: Python CI with ruff, mypy, pytest, and coverage upload
- `03-deploy-vercel`: Preview and production Vercel deployments with PR comments
- `04-deploy-docker`: Docker image build and push to ghcr.io with semantic tagging
- `05-release-npm`: Automated npm publishing on tag push with GitHub Release creation
- `06-security-scans`: CodeQL analysis and dependency vulnerability review
- `07-scheduled-jobs`: Stale issue management and scheduled maintenance workflows
- `08-monorepo-ci`: Path-filtered CI for monorepos — only run tests for changed packages
- `09-deploy-aws`: ECS Fargate deployment and S3/CloudFront static site deployment
- `10-advanced-patterns`: Reusable workflows, concurrency control, and dynamic matrix generation
