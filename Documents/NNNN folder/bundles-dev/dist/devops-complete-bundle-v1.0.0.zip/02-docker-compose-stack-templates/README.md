# Docker Compose Stack Templates

**8 production-ready Docker Compose stacks — docker-compose.yml + .env.example + README per stack.**

Spin up a complete local development environment in one command. Each stack is pre-configured with sensible defaults, health checks, named volumes, and documented environment variables.

## What's Inside

Every stack includes 3 files:
- `docker-compose.yml` — services, ports, volumes, health checks, restart policies
- `.env.example` — all environment variables with descriptions and defaults
- `README.md` — service list, ports, credentials, and common commands

## Stacks by Tier

### Starter ($19) — 4 stacks
| Stack | Services |
|-------|---------|
| `01-postgres-redis` | PostgreSQL 16 + Redis 7 + pgAdmin 4 + Redis Commander |
| `02-web-app-stack` | App + PostgreSQL + Redis + Nginx reverse proxy |
| `03-monitoring-stack` | Prometheus + Grafana + Node Exporter + cAdvisor |
| `04-message-queue` | RabbitMQ + Management UI |

### Pro ($39) — 8 stacks
Everything in Starter, plus:
| Stack | Services |
|-------|---------|
| `05-search-stack` | Elasticsearch 8 + Kibana + APM Server |
| `06-object-storage` | MinIO + Console |
| `07-log-aggregation` | Loki + Promtail + Grafana |
| `08-full-dev-environment` | PostgreSQL + Redis + RabbitMQ + MinIO + Mailhog + Adminer |

## Quick Start

```bash
cp .env.example .env
docker compose up -d
```

## Requirements
- Docker Engine 24+ (Compose V2 built-in)
- `docker compose` command (not `docker-compose`)
