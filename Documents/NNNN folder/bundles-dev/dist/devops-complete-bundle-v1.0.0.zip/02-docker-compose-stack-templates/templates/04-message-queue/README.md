# Message Queue Stack

RabbitMQ with the Management UI plugin.

## Services & Ports

| Service | Port | Purpose |
|---------|------|---------|
| RabbitMQ | 5672 | AMQP messaging |
| Management UI | 15672 | Web admin console |

## Quick Start

```bash
cp .env.example .env
# Set RABBITMQ_PASSWORD
docker compose up -d
```

## Management UI
- URL: http://localhost:15672
- Username: admin (from RABBITMQ_USER)
- Password: from RABBITMQ_PASSWORD

## Connection String

```
amqp://admin:changeme@localhost:5672/
```

## Common Operations

```bash
# List queues
docker compose exec rabbitmq rabbitmqctl list_queues

# Create a queue
docker compose exec rabbitmq rabbitmqadmin declare queue name=my-queue durable=true

# View logs
docker compose logs -f rabbitmq
```

## Notes
- `rabbitmq:3-management-alpine` includes the Management UI plugin — no separate install needed
- Data persists in a named volume; `docker compose down` keeps data, `docker compose down -v` removes it
