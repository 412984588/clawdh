# Object Storage Stack

MinIO — S3-compatible object storage with a web console.

## Services & Ports

| Service | Port | Purpose |
|---------|------|---------|
| MinIO API | 9000 | S3-compatible API |
| MinIO Console | 9001 | Web admin UI |

## Quick Start

```bash
cp .env.example .env
# Set MINIO_ROOT_PASSWORD
docker compose up -d
# The createbuckets service automatically creates MINIO_DEFAULT_BUCKET
```

## Console Login
- URL: http://localhost:9001
- Username: from MINIO_ROOT_USER
- Password: from MINIO_ROOT_PASSWORD

## S3 Client Connection

```typescript
import { S3Client } from '@aws-sdk/client-s3';

const s3 = new S3Client({
  endpoint: 'http://localhost:9000',
  region: 'us-east-1',
  credentials: {
    accessKeyId: process.env.MINIO_ROOT_USER,
    secretAccessKey: process.env.MINIO_ROOT_PASSWORD,
  },
  forcePathStyle: true,   // required for MinIO
});
```

## Notes
- `forcePathStyle: true` is required with MinIO — it uses path-style URLs, not virtual-hosted
- `createbuckets` service runs once and exits — this is normal
- Compatible with any AWS S3 SDK
