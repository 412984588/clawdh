# Full Dev Environment

Complete local development stack with database, cache, object storage, mail testing, and admin UIs — everything you need to run a full-stack app locally.

## Services

| Service | Port | Description |
|---------|------|-------------|
| PostgreSQL | 5432 | Primary relational database |
| Redis | 6379 | Cache and session store |
| MinIO | 9000 / 9001 | S3-compatible object storage + console |
| Mailpit | 1025 (SMTP) / 8025 (UI) | Local email testing, catches all outbound mail |
| Adminer | 8080 | Web-based database admin |
| Redis Commander | 8081 | Web-based Redis browser |

## Quick Start

```bash
cp .env.example .env
# Edit .env — set POSTGRES_PASSWORD at minimum
docker compose up -d
```

## Service URLs

- Adminer: http://localhost:8080
- Redis Commander: http://localhost:8081
- MinIO Console: http://localhost:9001 (minioadmin / minioadmin)
- Mailpit: http://localhost:8025

## Configure Your App

```env
# In your app's .env
DATABASE_URL=postgresql://appuser:changeme@localhost:5432/appdb
REDIS_URL=redis://:redispass@localhost:6379
S3_ENDPOINT=http://localhost:9000
S3_ACCESS_KEY=minioadmin
S3_SECRET_KEY=minioadmin
SMTP_HOST=localhost
SMTP_PORT=1025
```

## What This Stack Replaces

| Service | Replaces |
|---------|----------|
| Mailpit | SendGrid / SES during development |
| MinIO | AWS S3 during development |
| Adminer | TablePlus / DBeaver |
| Redis Commander | RedisInsight |

## Stopping / Resetting

```bash
# Stop without deleting data
docker compose down

# Full reset (deletes all volumes)
docker compose down -v
```
