# Web App Stack

Full web application stack: your app behind Nginx, with PostgreSQL and Redis.

## Services

| Service | Port | Purpose |
|---------|------|---------|
| App | 3000 (internal) | Your application |
| Nginx | 80, 443 | Reverse proxy |
| PostgreSQL 16 | internal only | Database |
| Redis 7 | internal only | Cache |

## Quick Start

```bash
cp .env.example .env
# Set POSTGRES_PASSWORD and REDIS_PASSWORD
docker compose up -d
```

## Setup Required

1. **Dockerfile** — add your app's Dockerfile to the project root
2. **Nginx config** — create `nginx/nginx.conf`:

```nginx
events { worker_connections 1024; }
http {
  upstream app { server app:3000; }
  server {
    listen 80;
    location / { proxy_pass http://app; proxy_set_header Host $host; }
  }
}
```

## Design Notes
- App service uses volume mount for hot-reload in development
- Nginx and Redis are internal-only (not bound to host ports) — access via Nginx
- Remove the `volumes` bind mount in production; use a built image instead
