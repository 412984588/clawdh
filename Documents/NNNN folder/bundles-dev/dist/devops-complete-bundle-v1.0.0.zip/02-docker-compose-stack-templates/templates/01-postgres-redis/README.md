# PostgreSQL + Redis Stack

Local development database stack with admin UIs.

## Services & Ports

| Service | Port | Purpose |
|---------|------|---------|
| PostgreSQL 16 | 5432 | Primary database |
| Redis 7 | 6379 | Cache / sessions |
| pgAdmin 4 | 5050 | PostgreSQL web UI |
| Redis Commander | 8081 | Redis web UI |

## Quick Start

```bash
cp .env.example .env
# Edit .env — set POSTGRES_PASSWORD and REDIS_PASSWORD
docker compose up -d
```

## Connection Strings

```
# PostgreSQL
postgresql://appuser:changeme@localhost:5432/appdb

# Redis
redis://:changeme@localhost:6379
```

## pgAdmin Login
- URL: http://localhost:5050
- Email: admin@local.dev
- Password: pgadmin (from .env)

Add server: host `postgres`, port `5432`, user/pass from `.env`

## Common Commands

```bash
# View logs
docker compose logs -f postgres

# psql shell
docker compose exec postgres psql -U appuser -d appdb

# Redis CLI
docker compose exec redis redis-cli -a $REDIS_PASSWORD

# Stop & remove volumes
docker compose down -v
```
