# Log Aggregation Stack

Centralized log collection and visualization using Grafana Loki, Promtail, and Grafana.

## Services

| Service | Port | Description |
|---------|------|-------------|
| Grafana | 3000 | Dashboards and log exploration |
| Loki | 3100 | Log aggregation backend |
| Promtail | — | Log collector (no external port) |

## Quick Start

```bash
cp .env.example .env
# Mount your Loki and Promtail config files:
mkdir -p loki promtail grafana/provisioning
# Add loki/config.yml, promtail/config.yml, grafana/provisioning datasource

docker compose up -d
```

Access Grafana at http://localhost:3000 (admin / grafana by default).

## Loki Config Example

```yaml
# loki/config.yml
auth_enabled: false
server:
  http_listen_port: 3100
ingester:
  lifecycler:
    ring:
      kvstore:
        store: inmemory
      replication_factor: 1
schema_config:
  configs:
    - from: 2020-10-24
      store: boltdb-shipper
      object_store: filesystem
      schema: v11
      index:
        prefix: index_
        period: 24h
storage_config:
  boltdb_shipper:
    active_index_directory: /loki/boltdb-shipper-active
    cache_location: /loki/boltdb-shipper-cache
  filesystem:
    directory: /loki/chunks
```

## Promtail Config Example

```yaml
# promtail/config.yml
server:
  http_listen_port: 9080
positions:
  filename: /tmp/positions.yaml
clients:
  - url: http://loki:3100/loki/api/v1/push
scrape_configs:
  - job_name: system
    static_configs:
      - targets: [localhost]
        labels:
          job: varlogs
          __path__: /var/log/*log
  - job_name: containers
    static_configs:
      - targets: [localhost]
        labels:
          job: containerlogs
          __path__: /var/lib/docker/containers/*/*log
```

## Querying Logs in Grafana

- Add Loki datasource: `http://loki:3100`
- Use LogQL: `{job="varlogs"} |= "error"`
- Filter by container: `{job="containerlogs"} | json | container_name="myapp"`
