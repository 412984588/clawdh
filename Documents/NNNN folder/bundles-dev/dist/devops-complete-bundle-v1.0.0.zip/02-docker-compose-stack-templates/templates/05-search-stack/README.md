# Elasticsearch Stack

Elasticsearch 8 + Kibana + APM Server for full-text search and application monitoring.

## Services & Ports

| Service | Port | Purpose |
|---------|------|---------|
| Elasticsearch | 9200 | Search engine |
| Kibana | 5601 | Search UI / dashboards |
| APM Server | 8200 | Application performance monitoring |

## Quick Start

```bash
cp .env.example .env
# Set ELASTIC_PASSWORD
# Elasticsearch requires sufficient virtual memory:
sudo sysctl -w vm.max_map_count=262144
docker compose up -d
```

## Notes
- `xpack.security.enabled=false` — simplifies local setup; enable in production
- `ES_JAVA_OPTS=-Xms512m -Xmx512m` — increase for production workloads
- First startup takes ~60s — Kibana won't be ready until ES passes health check
- `vm.max_map_count` must be set on the host (Linux); on Mac/Windows Docker Desktop handles this

## Connection

```javascript
// Elasticsearch client
const client = new Client({ node: 'http://localhost:9200' });
```
