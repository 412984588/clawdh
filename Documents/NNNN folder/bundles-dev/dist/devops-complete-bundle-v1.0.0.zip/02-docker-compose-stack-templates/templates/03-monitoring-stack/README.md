# Monitoring Stack

Prometheus + Grafana + Node Exporter + cAdvisor — full host and container metrics.

## Services & Ports

| Service | Port | Purpose |
|---------|------|---------|
| Prometheus | 9090 | Metrics collection |
| Grafana | 3000 | Dashboards |
| Node Exporter | internal | Host metrics |
| cAdvisor | internal | Container metrics |

## Quick Start

```bash
cp .env.example .env
mkdir -p prometheus grafana/provisioning
# Create prometheus/prometheus.yml (see below)
docker compose up -d
```

## Prometheus Config

Create `prometheus/prometheus.yml`:

```yaml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'node-exporter'
    static_configs:
      - targets: ['node-exporter:9100']

  - job_name: 'cadvisor'
    static_configs:
      - targets: ['cadvisor:8080']
```

## Grafana Login
- URL: http://localhost:3000
- Username: admin
- Password: from GRAFANA_PASSWORD in .env

## Recommended Dashboards
Import from grafana.com:
- Node Exporter Full: ID `1860`
- cAdvisor: ID `14282`
