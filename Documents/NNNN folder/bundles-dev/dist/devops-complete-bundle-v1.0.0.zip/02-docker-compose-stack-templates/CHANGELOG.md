# Changelog

## [1.0.0] — 2026-03-21

### Added
- 8 Docker Compose stack templates across 2 tiers ($19/$39)
- Each stack: docker-compose.yml + .env.example + README.md
- Starter (4): PostgreSQL+Redis, Web App Stack, Monitoring, Message Queue
- Pro (8): + Elasticsearch Stack, MinIO Object Storage, Loki Log Aggregation, Full Dev Environment
- All stacks use Docker Compose V2 syntax (no `version:` field)
- Health checks, named volumes, and restart policies on all services
- Environment variables documented with defaults in .env.example
