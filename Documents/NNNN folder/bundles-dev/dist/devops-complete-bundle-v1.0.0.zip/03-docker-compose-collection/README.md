# Docker Compose Collection

8 ready-to-copy Docker Compose templates for common web application stacks, worker setups, proxies, and local monitoring environments.

## Included Stacks

- `01-mern-stack`
- `02-pern-stack`
- `03-nextjs-supabase`
- `04-fastapi-postgresql`
- `05-redis-celery-worker`
- `06-nginx-reverse-proxy`
- `07-monitoring-prometheus-grafana`
- `08-django-postgresql-celery`

## Tiers

| Tier | Price | Stack Count |
|------|-------|-------------|
| Starter | $19 | 4 |
| Pro | $39 | 6 |
| Complete | $59 | 8 |

## Verification

```bash
cd docker-compose-collection-dev
python3 generate_stacks.py
python3 -m pytest tests/test_bundle.py -q
python3 build_bundle.py
```

## Deliverables

- `dist/docker-compose-collection-starter-v1.0.0.zip`
- `dist/docker-compose-collection-pro-v1.0.0.zip`
- `dist/docker-compose-collection-complete-v1.0.0.zip`

## License

Released under the MIT License. See `LICENSE`.
