# Changelog

## v1.0.0 - 2026-03-20

- Initial release of Docker Compose Collection
- Added 8 Docker Compose stacks across app, worker, proxy, and monitoring use cases
- Added Starter, Pro, and Complete tier packaging
