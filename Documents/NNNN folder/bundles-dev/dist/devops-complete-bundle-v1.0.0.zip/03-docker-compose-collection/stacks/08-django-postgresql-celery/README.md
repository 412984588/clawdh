# Django + PostgreSQL + Celery

Django web app with PostgreSQL, Redis, and Celery worker/beat services for full-featured backend projects.

## Services

- `db`
- `redis`
- `web`
- `worker`
- `beat`

## Quick Start

1. Copy `.env.example` to `.env` and adjust ports or secrets.
2. Review `docker-compose.yml` and any mounted config files before first run.
3. Start the stack with `docker compose up -d`.
4. Visit the exposed ports listed in `.env.example` and validate service health.

## Notes

- This template is intentionally starter-friendly and should be adapted to your repo structure.
- Add Dockerfiles, bind mounts, health checks, and secrets management before production use.
- Keep environment values synchronized between `.env`, application config, and Compose service definitions.
