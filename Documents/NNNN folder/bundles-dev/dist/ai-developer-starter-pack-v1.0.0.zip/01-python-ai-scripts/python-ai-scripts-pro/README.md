# Python AI Scripts — Pro Pack ($29)

20 scripts across 9 categories. Includes everything in Starter plus advanced
data processing, document tools, local LLM support, and more.

## What's Included

### Starter Scripts (10)
text-summarizer, sentiment-analyzer, csv-insight, file-organizer,
openai-chat, email-drafter, code-reviewer, social-post-generator,
invoice-generator, env-checker

### Pro Additions (10)
| Script | Category | Dependencies |
|--------|----------|--------------|
| batch-translator | Text | openai or anthropic |
| report-generator | Data | openai or anthropic |
| web-scraper | Automation | openai or anthropic |
| claude-chat | LLM | anthropic |
| ollama-local | LLM | none (local Ollama) |
| pdf-extractor | Documents | pypdf |
| markdown-converter | Documents | none (stdlib only) |
| readme-generator | Code Tools | openai or anthropic |
| hashtag-optimizer | Social | openai or anthropic |
| api-tester | Dev Tools | none (stdlib only) |

## Quick Start

```bash
cd scripts/<category>/<script-name>
pip install -r requirements.txt
python script.py
```

## Upgrade

Upgrade to Bundle ($39) for all 30 scripts including data visualization,
AI vision, audio transcription, and business tools.
