# Changelog

## [1.0.0] — 2026-03-20

### Added
- Finalized v1.0.0 distribution bundles for Starter, Pro, and Bundle tiers
- Added release `LICENSE` file to all packaged ZIP deliverables
- Promoted the full 30-script collection to the first stable public release

## [0.3.0] — 2026-03-20

### Added (Batch 3 — scripts 21–30)
- Data Visualization: chart-generator (matplotlib bar/line/pie/scatter/area), dashboard-builder (self-contained HTML + Chart.js, zero deps)
- AI Tools: image-describer (GPT-4o + Claude vision, local files + URLs), audio-transcriber (Whisper API, timestamps, translate), meeting-summarizer (full/brief/actions formats)
- Business Tools: invoice-generator (HTML invoices, zero deps), proposal-writer (phased AI proposals), competitor-tracker (scrape + AI compare)
- Dev Tools: api-tester (stdlib urllib, PASS/FAIL/WARN table), env-checker (parse .env.example, mask values, --fix mode)
- Total: 30/30 scripts complete, all validated in demo mode

## [0.2.0] — 2026-03-20

### Added (Batch 2 — scripts 11–20)
- Automation: email-drafter (4 tones), newsletter-generator
- Documents: pdf-extractor (pypdf), markdown-converter (no deps)
- Code Tools: code-reviewer, readme-generator, changelog-writer
- Social Media: social-post-generator, hashtag-optimizer, comment-replier

## [0.1.0] — 2026-03-20

### Added
- Initial 10 scripts across 4 categories
- Text Processing: text-summarizer, sentiment-analyzer, batch-translator
- Data Analysis: csv-insight, report-generator
- Automation: file-organizer, web-scraper
- LLM Integration: openai-chat, claude-chat, ollama-local
- Demo mode for all scripts (runs without API keys)
- Auto-detection of OpenAI/Claude/Ollama providers
