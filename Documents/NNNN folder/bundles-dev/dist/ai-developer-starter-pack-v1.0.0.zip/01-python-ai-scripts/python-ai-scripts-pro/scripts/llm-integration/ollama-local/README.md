# Ollama Local

> **Category:** LLM Integration | **Deps:** None (stdlib only)

Chat with locally running LLMs via Ollama. No API keys needed — completely private, runs on your machine.

## Setup

```bash
pip install -r requirements.txt
```

Create a `.env` file (or export env vars):
```
# No API key needed
# Install Ollama: https://ollama.ai
# Then: ollama serve && ollama pull llama3.2
```

## Usage

**Demo mode** (no API key needed):
```bash
python script.py
```

**With API key:**
```bash
python script.py --model llama3.2
python script.py --list  # show installed models
python script.py --once 'What is Python?'
```

## Options

Run `python script.py --help` for all options.

## Validation

```bash
pip install -r requirements.txt && python script.py
```

Expected: Demo output printed to stdout, exit code 0.
