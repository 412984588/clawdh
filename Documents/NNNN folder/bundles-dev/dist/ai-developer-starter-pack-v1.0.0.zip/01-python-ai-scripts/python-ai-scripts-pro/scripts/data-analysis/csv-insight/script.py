#!/usr/bin/env python3
"""
CSV Insight — Analyze CSV data and generate an AI-written natural language report.
Demo mode runs without API keys using built-in sample data.

Usage:
  python script.py                    # demo with sample sales data
  python script.py data.csv           # analyze your CSV
  python script.py data.csv --out report.md
"""

import argparse
import csv
import io
import os
import sys
from pathlib import Path

SAMPLE_CSV = """\
month,revenue,orders,avg_order_value,returns,new_customers
Jan,42500,285,149.12,12,180
Feb,38200,256,149.22,8,155
Mar,51300,340,150.88,15,210
Apr,48700,318,153.14,11,195
May,55100,360,153.06,14,225
Jun,61200,398,153.77,18,242
"""

DEMO_REPORT = """\
[DEMO MODE — no API key detected]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Sales Performance Report (Jan–Jun)

## Executive Summary
Revenue grew 44% over the 6-month period, rising from $42,500 in January to
$61,200 in June. Orders increased from 285 to 398, while the average order
value remained stable at ~$150, indicating volume-driven rather than
price-driven growth.

## Key Findings
- **Best month**: June ($61,200 revenue, 398 orders)
- **Weakest month**: February ($38,200 — seasonal dip)
- **Growth rate**: +44% revenue, +40% order volume
- **Return rate**: consistently low (2.8–4.5%), trending upward in June

## New Customer Acquisition
New customer additions grew from 180 (Jan) to 242 (Jun), a 34% increase,
suggesting effective acquisition efforts alongside organic growth.

## Recommendations
1. Investigate the February dip — likely seasonal; consider promotions
2. Monitor June's return uptick (18 returns) — may signal quality issues
3. Average order value is flat; consider upsell strategies to drive AOV above $160

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Set OPENAI_API_KEY or ANTHROPIC_API_KEY to analyze your own CSV.
"""


def compute_stats(rows: list[dict]) -> str:
    """计算基础统计信息作为 LLM 上下文"""
    if not rows:
        return "Empty dataset."
    columns = list(rows[0].keys())
    lines = [f"Columns: {', '.join(columns)}", f"Row count: {len(rows)}", ""]

    # 尝试数值列统计
    for col in columns:
        values = []
        for row in rows:
            try:
                values.append(float(row[col].replace(",", "")))
            except (ValueError, AttributeError):
                pass
        if values:
            lines.append(f"{col}: min={min(values):.2f}, max={max(values):.2f}, "
                         f"avg={sum(values)/len(values):.2f}, total={sum(values):.2f}")

    return "\n".join(lines)


def call_llm(prompt: str, provider: str, model: str) -> str:
    if provider == "claude":
        import anthropic  # noqa: PLC0415
        client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        msg = client.messages.create(
            model=model, max_tokens=1000,
            messages=[{"role": "user", "content": prompt}],
        )
        block = msg.content[0]
        return block.text if hasattr(block, "text") else str(block)
    else:
        import openai  # noqa: PLC0415
        client = openai.OpenAI(api_key=os.environ["OPENAI_API_KEY"])
        resp = client.chat.completions.create(
            model=model, max_tokens=1000,
            messages=[{"role": "user", "content": prompt}],
        )
        return resp.choices[0].message.content or ""


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate AI report from CSV data")
    parser.add_argument("input", nargs="?", help="CSV file to analyze (omit for demo)")
    parser.add_argument("--out", help="Save report to file (default: print to stdout)")
    parser.add_argument("--provider", choices=["openai", "claude", "auto"], default="auto")
    parser.add_argument("--model", help="Override model name")
    args = parser.parse_args()

    openai_key = os.environ.get("OPENAI_API_KEY")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")

    if not openai_key and not anthropic_key:
        print(DEMO_REPORT)
        return

    if args.input:
        with open(args.input, encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        raw_csv = Path(args.input).read_text(encoding="utf-8")[:3000]  # 截断防止超 token
    else:
        rows = list(csv.DictReader(io.StringIO(SAMPLE_CSV)))
        raw_csv = SAMPLE_CSV

    stats = compute_stats(rows)
    prompt = (
        "You are a data analyst. Analyze the following CSV data and write a concise "
        "business report in Markdown with: Executive Summary, Key Findings, and "
        "2-3 actionable Recommendations.\n\n"
        f"Statistics:\n{stats}\n\n"
        f"Raw data (first rows):\n{raw_csv}"
    )

    provider = "claude" if (args.provider == "claude" or (args.provider == "auto" and anthropic_key and not openai_key)) else "openai"
    model = args.model or ("claude-haiku-4-5-20251001" if provider == "claude" else "gpt-4o-mini")

    try:
        print("Analyzing data...\n")
        report = call_llm(prompt, provider, model)
        if args.out:
            Path(args.out).write_text(report, encoding="utf-8")
            print(f"✅ Report saved to {args.out}")
        else:
            print(report)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
