# API Tester

Test REST API endpoints and generate summary reports. No API key, no dependencies — uses Python stdlib only.

## Demo (no setup, requires internet)

```bash
python script.py
# Tests 5 public endpoints (JSONPlaceholder + HTTPBin)
```

## Usage

```bash
# Test a single URL
python script.py --url https://api.example.com/users

# Test with expected status code
python script.py --url https://api.example.com/health --expect 200

# Test with custom HTTP method
python script.py --url https://api.example.com/items --method POST

# Test from JSON config file
python script.py endpoints.json

# Save report to Markdown
python script.py endpoints.json --out report.md
```

## JSON Config Format

```json
[
  {
    "name": "List Users",
    "url": "https://api.example.com/users",
    "method": "GET",
    "expect_status": 200,
    "timeout": 10,
    "headers": {"Authorization": "Bearer token123"}
  },
  {
    "name": "Create Item",
    "url": "https://api.example.com/items",
    "method": "POST",
    "expect_status": 201,
    "body": {"name": "test", "value": 42}
  }
]
```

## Output

```
Endpoint                            Status   HTTP     Time     Size
──────────────────────────────────────────────────────────────────────
JSONPlaceholder Posts               ✅ PASS   200     142ms    292B
HTTPBin Status 404                  ✅ PASS   404      89ms     N/A
Slow Endpoint                       ⚠️ WARN   200    3200ms    512B
──────────────────────────────────────────────────────────────────────
Results: 2 passed, 0 failed, 1 warning  (3 total)
```

## Status Logic

| Status | Condition |
|--------|-----------|
| PASS | HTTP status matches expected (or no expected set) |
| FAIL | HTTP status mismatch, connection error, or timeout |
| WARN | Response time > 3000ms |

## Exit Codes

- `0` — all tests passed
- `1` — one or more failures
