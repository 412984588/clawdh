#!/usr/bin/env python3
"""
Text Summarizer — AI-powered text summarization using OpenAI or Claude.
Demo mode runs without API keys using built-in sample text.

Usage:
  python script.py                    # demo mode
  python script.py article.txt        # summarize file
  python script.py --provider claude  # force Claude
"""

import argparse
import os
import sys
from pathlib import Path

SAMPLE_TEXT = """\
Artificial intelligence is rapidly transforming how we work and live. Large
language models can now perform complex reasoning tasks, write code, analyze
data, and generate creative content. Companies are integrating AI into their
workflows to automate repetitive tasks, improve customer service, and
accelerate research. However, concerns about job displacement, privacy, and
the ethical use of AI remain important considerations. Researchers and
policymakers are working to establish guidelines that ensure AI development
benefits humanity while minimizing risks. The next decade will likely see even
more profound changes as AI capabilities continue to advance.
"""

DEMO_SUMMARY = """\
[DEMO MODE — no API key detected]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Sample summary (142 words → 38 words, 73% reduction):

AI reshapes work and life through LLMs capable of reasoning, coding, and
content generation. While businesses embrace AI for efficiency, ethical
concerns around jobs, privacy, and responsible development remain central.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Set OPENAI_API_KEY or ANTHROPIC_API_KEY to summarize real text.
"""


def summarize_with_openai(text: str, model: str) -> str:
    import openai  # noqa: PLC0415
    client = openai.OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": "Summarize the text concisely in 2-3 sentences. Preserve key facts."},
            {"role": "user", "content": text},
        ],
        max_tokens=200,
    )
    return response.choices[0].message.content.strip()


def summarize_with_claude(text: str, model: str) -> str:
    import anthropic  # noqa: PLC0415
    client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
    message = client.messages.create(
        model=model,
        max_tokens=200,
        messages=[{"role": "user", "content": f"Summarize this text concisely in 2-3 sentences:\n\n{text}"}],
    )
    return message.content[0].text.strip()


def main() -> None:
    parser = argparse.ArgumentParser(description="Summarize text using AI")
    parser.add_argument("input", nargs="?", help="Path to text file (omit for demo)")
    parser.add_argument("--provider", choices=["openai", "claude", "auto"], default="auto",
                        help="LLM provider (default: auto-detect from env)")
    parser.add_argument("--model", help="Override model name")
    args = parser.parse_args()

    text = Path(args.input).read_text(encoding="utf-8") if args.input else SAMPLE_TEXT

    openai_key = os.environ.get("OPENAI_API_KEY")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")

    if not openai_key and not anthropic_key:
        print(DEMO_SUMMARY)
        return

    print("Summarizing...\n")
    try:
        use_claude = args.provider == "claude" or (args.provider == "auto" and anthropic_key and not openai_key)
        if use_claude:
            summary = summarize_with_claude(text, args.model or "claude-haiku-4-5-20251001")
        else:
            summary = summarize_with_openai(text, args.model or "gpt-4o-mini")

        words_in = len(text.split())
        words_out = len(summary.split())
        reduction = max(0, 100 - words_out * 100 // words_in)
        print(f"Summary ({words_in} → {words_out} words, {reduction}% reduction):")
        print("━" * 60)
        print(summary)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
