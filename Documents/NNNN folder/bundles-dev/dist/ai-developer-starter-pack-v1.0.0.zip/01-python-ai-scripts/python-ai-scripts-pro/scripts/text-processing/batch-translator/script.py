#!/usr/bin/env python3
"""
Batch Translator — Translate text columns in CSV files using OpenAI or Claude.
Demo mode runs without API keys.

Usage:
  python script.py                           # demo mode
  python script.py data.csv --to zh          # translate column to Chinese
  python script.py data.csv --col title --to es --out translated.csv
"""

import argparse
import csv
import os
import sys
from pathlib import Path

SAMPLE_DATA = [
    {"id": "1", "title": "Getting Started with Python", "category": "tutorial"},
    {"id": "2", "title": "Advanced Machine Learning Techniques", "category": "article"},
    {"id": "3", "title": "Building REST APIs with FastAPI", "category": "guide"},
    {"id": "4", "title": "Docker for Beginners", "category": "tutorial"},
    {"id": "5", "title": "Understanding Neural Networks", "category": "article"},
]

DEMO_OUTPUT = [
    {"id": "1", "title": "Getting Started with Python", "title_zh": "Python 入门指南"},
    {"id": "2", "title": "Advanced Machine Learning Techniques", "title_zh": "高级机器学习技术"},
    {"id": "3", "title": "Building REST APIs with FastAPI", "title_zh": "使用 FastAPI 构建 REST API"},
    {"id": "4", "title": "Docker for Beginners", "title_zh": "Docker 初学者入门"},
    {"id": "5", "title": "Understanding Neural Networks", "title_zh": "理解神经网络"},
]

LANGUAGE_NAMES = {
    "zh": "Chinese (Simplified)", "es": "Spanish", "fr": "French",
    "de": "German", "ja": "Japanese", "ko": "Korean", "pt": "Portuguese",
    "ar": "Arabic", "ru": "Russian", "it": "Italian",
}


def translate_texts(texts: list[str], target_lang: str, provider: str, model: str) -> list[str]:
    """批量翻译，每次最多 10 条合并请求减少 API 调用"""
    results = []
    batch_size = 10
    lang_name = LANGUAGE_NAMES.get(target_lang, target_lang)

    for i in range(0, len(texts), batch_size):
        batch = texts[i:i + batch_size]
        numbered = "\n".join(f"{j + 1}. {t}" for j, t in enumerate(batch))
        prompt = (
            f"Translate the following {len(batch)} texts to {lang_name}. "
            f"Return only numbered translations in the same format, no explanations:\n\n{numbered}"
        )
        raw = call_llm(prompt, provider, model)
        translations = parse_numbered_response(raw, len(batch))
        results.extend(translations)

    return results


def parse_numbered_response(raw: str, expected: int) -> list[str]:
    import re
    lines = [line.strip() for line in raw.strip().split("\n") if line.strip()]
    translations = []
    for line in lines:
        match = re.match(r'^\d+\.\s*(.+)', line)
        if match:
            translations.append(match.group(1).strip())
    # 如果解析失败，按行返回
    if len(translations) != expected:
        translations = [line for line in lines if line][:expected]
    return translations


def call_llm(prompt: str, provider: str, model: str) -> str:
    if provider == "claude":
        import anthropic  # noqa: PLC0415
        client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        msg = client.messages.create(
            model=model, max_tokens=1000,
            messages=[{"role": "user", "content": prompt}],
        )
        return msg.content[0].text
    else:
        import openai  # noqa: PLC0415
        client = openai.OpenAI(api_key=os.environ["OPENAI_API_KEY"])
        resp = client.chat.completions.create(
            model=model, max_tokens=1000,
            messages=[{"role": "user", "content": prompt}],
        )
        return resp.choices[0].message.content


def main() -> None:
    parser = argparse.ArgumentParser(description="Batch translate CSV text column using AI")
    parser.add_argument("input", nargs="?", help="Input CSV file (omit for demo)")
    parser.add_argument("--col", default="text", help="Column to translate (default: text)")
    parser.add_argument("--to", default="zh", metavar="LANG",
                        help=f"Target language code (default: zh). Options: {', '.join(LANGUAGE_NAMES)}")
    parser.add_argument("--out", help="Output CSV path (default: <input>_translated.csv)")
    parser.add_argument("--provider", choices=["openai", "claude", "auto"], default="auto")
    parser.add_argument("--model", help="Override model name")
    args = parser.parse_args()

    openai_key = os.environ.get("OPENAI_API_KEY")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")

    if not openai_key and not anthropic_key:
        print("[DEMO MODE — set OPENAI_API_KEY or ANTHROPIC_API_KEY to translate real data]\n")
        print(f"Sample: English → {LANGUAGE_NAMES.get(args.to, args.to)}")
        print("━" * 60)
        for row in DEMO_OUTPUT:
            print(f"  {row['title']}")
            print(f"  → {row['title_zh']}\n")
        return

    provider = "claude" if (args.provider == "claude" or (args.provider == "auto" and anthropic_key and not openai_key)) else "openai"
    model = args.model or ("claude-haiku-4-5-20251001" if provider == "claude" else "gpt-4o-mini")

    try:
        if args.input:
            input_path = Path(args.input)
            with open(input_path, encoding="utf-8") as f:
                rows = list(csv.DictReader(f))
            col = args.col
            if col not in rows[0]:
                print(f"Error: column '{col}' not found. Available: {list(rows[0].keys())}", file=sys.stderr)
                sys.exit(1)
        else:
            rows = SAMPLE_DATA
            col = "title"

        texts = [row[col] for row in rows]
        print(f"Translating {len(texts)} texts to {LANGUAGE_NAMES.get(args.to, args.to)}...")

        translations = translate_texts(texts, args.to, provider, model)
        out_col = f"{col}_{args.to}"
        for row, translation in zip(rows, translations):
            row[out_col] = translation

        out_path = args.out or (str(Path(args.input).stem) + f"_translated.csv" if args.input else "translated.csv")
        with open(out_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)

        print(f"✅ Done. Saved to {out_path} ({len(rows)} rows, column '{out_col}' added)")
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
