# Batch Translator

> **Category:** Text Processing | **Deps:** openai, anthropic

Translate a text column in CSV files to any language using AI. Supports 10+ languages, processes in batches to minimize API calls.

## Setup

```bash
pip install -r requirements.txt
```

Create a `.env` file (or export env vars):
```
OPENAI_API_KEY=your_key_here
# or
ANTHROPIC_API_KEY=your_key_here
```

## Usage

**Demo mode** (no API key needed):
```bash
python script.py
```

**With API key:**
```bash
OPENAI_API_KEY=sk-... python script.py data.csv --col title --to zh
python script.py data.csv --to es --out translated.csv
```

## Options

Run `python script.py --help` for all options.

## Validation

```bash
pip install -r requirements.txt && python script.py
```

Expected: Demo output printed to stdout, exit code 0.
