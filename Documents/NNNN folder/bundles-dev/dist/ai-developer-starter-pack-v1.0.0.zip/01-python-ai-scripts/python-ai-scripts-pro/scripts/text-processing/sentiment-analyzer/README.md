# Sentiment Analyzer

> **Category:** Text Processing | **Deps:** openai, anthropic

Batch sentiment and emotion analysis for text or CSV files. Returns positive/negative/neutral/mixed with confidence scores.

## Setup

```bash
pip install -r requirements.txt
```

Create a `.env` file (or export env vars):
```
OPENAI_API_KEY=your_key_here
# or
ANTHROPIC_API_KEY=your_key_here
```

## Usage

**Demo mode** (no API key needed):
```bash
python script.py
```

**With API key:**
```bash
OPENAI_API_KEY=sk-... python script.py reviews.csv --column review_text
python script.py --text 'I love this product!'
```

## Options

Run `python script.py --help` for all options.

## Validation

```bash
pip install -r requirements.txt && python script.py
```

Expected: Demo output printed to stdout, exit code 0.
