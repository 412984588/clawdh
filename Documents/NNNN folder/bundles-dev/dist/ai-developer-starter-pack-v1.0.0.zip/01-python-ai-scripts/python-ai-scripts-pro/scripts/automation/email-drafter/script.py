#!/usr/bin/env python3
"""
Email Drafter — Draft professional emails from bullet points or brief descriptions.
Demo mode runs without API keys.

Usage:
  python script.py                              # demo mode
  python script.py --context "Follow up on..." # draft from description
  python script.py --points points.txt         # draft from bullet points file
  python script.py --tone formal --context ... # formal/casual/assertive
"""

import argparse
import os
import sys

DEMO_CONTEXT = "Follow up with the client about the project proposal we sent last week. They haven't responded. Be polite but firm."

DEMO_EMAIL = """\
[DEMO MODE — no API key detected]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Subject: Following Up on Our Project Proposal

Hi [Client Name],

I hope this message finds you well. I wanted to follow up on the project
proposal we sent over last week, as I haven't heard back from you yet.

We're genuinely excited about the opportunity to work together and believe
the solution we've outlined aligns well with your goals. If you have any
questions about the proposal or would like to discuss any aspect in more
detail, I'd be happy to schedule a quick call at your convenience.

Please let me know if you need any additional information to move forward.
I look forward to hearing from you.

Best regards,
[Your Name]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Set OPENAI_API_KEY or ANTHROPIC_API_KEY to draft real emails.
"""

TONES = {
    "formal": "professional, formal business tone — no contractions, full sentences",
    "casual": "friendly and approachable tone — conversational, warm",
    "assertive": "confident and direct tone — clear call-to-action, no hedging",
    "concise": "ultra-brief tone — 3-5 sentences maximum, direct",
}


def call_llm(prompt: str, provider: str, model: str) -> str:
    if provider == "claude":
        import anthropic  # noqa: PLC0415
        client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        msg = client.messages.create(
            model=model, max_tokens=600,
            messages=[{"role": "user", "content": prompt}],
        )
        block = msg.content[0]
        return block.text if hasattr(block, "text") else str(block)
    else:
        import openai  # noqa: PLC0415
        client = openai.OpenAI(api_key=os.environ["OPENAI_API_KEY"])
        resp = client.chat.completions.create(
            model=model, max_tokens=600,
            messages=[
                {"role": "system", "content": "You are a professional email writer. Write complete, ready-to-send emails including subject line."},
                {"role": "user", "content": prompt},
            ],
        )
        return resp.choices[0].message.content or ""


def main() -> None:
    parser = argparse.ArgumentParser(description="Draft professional emails using AI")
    parser.add_argument("--context", "-c", help="Brief description of the email needed")
    parser.add_argument("--points", "-p", help="Text file with bullet points to include")
    parser.add_argument("--tone", choices=list(TONES), default="formal",
                        help="Email tone (default: formal)")
    parser.add_argument("--to", help="Recipient name/role (e.g. 'the client')")
    parser.add_argument("--from-name", help="Sender name")
    parser.add_argument("--provider", choices=["openai", "claude", "auto"], default="auto")
    parser.add_argument("--model", help="Override model name")
    args = parser.parse_args()

    openai_key = os.environ.get("OPENAI_API_KEY")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")

    if not openai_key and not anthropic_key:
        print(DEMO_EMAIL)
        return

    context = args.context or DEMO_CONTEXT
    if args.points:
        from pathlib import Path  # noqa: PLC0415
        points = Path(args.points).read_text(encoding="utf-8")
        context = f"Context: {context}\n\nKey points to include:\n{points}"

    tone_desc = TONES[args.tone]
    recipient = f"to {args.to}" if args.to else ""
    sender = f"\nSign off as: {args.from_name}" if args.from_name else ""

    prompt = (
        f"Write a complete professional email {recipient} with a {tone_desc}.\n"
        f"Include Subject line on the first line.\n"
        f"Context/purpose: {context}{sender}"
    )

    provider = "claude" if (args.provider == "claude" or (args.provider == "auto" and anthropic_key and not openai_key)) else "openai"
    model = args.model or ("claude-haiku-4-5-20251001" if provider == "claude" else "gpt-4o-mini")

    try:
        print("Drafting email...\n")
        email = call_llm(prompt, provider, model)
        print("━" * 60)
        print(email)
        print("━" * 60)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
