# PDF Extractor

> **Category:** Documents | **Deps:** pypdf, openai or anthropic

Extract text from PDF files and optionally generate an AI summary. Handles multi-page PDFs.

## Setup

```bash
pip install -r requirements.txt
```

Create a `.env` file or export env vars:
```
OPENAI_API_KEY=your_key_here
# or
ANTHROPIC_API_KEY=your_key_here
```

## Usage

**Demo mode** (no API key needed):
```bash
python script.py
```

**With API key:**
```bash
python script.py document.pdf
python script.py document.pdf --summarize  # add AI summary
OPENAI_API_KEY=sk-... python script.py report.pdf --summarize --out summary.txt
```

## Options

Run `python script.py --help` for all options.

## Validation

```bash
pip install -r requirements.txt && python script.py
```

Expected: Demo output printed to stdout, exit code 0.
