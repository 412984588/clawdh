#!/usr/bin/env python3
"""
Code Reviewer — AI-powered code review for Python, JS, TypeScript, and more.
Demo mode runs without API keys using built-in sample code.

Usage:
  python script.py                      # demo mode
  python script.py app.py               # review a file
  python script.py src/ --ext .py       # review all .py files in directory
  python script.py app.py --focus security  # focus on security issues
"""

import argparse
import os
import sys
from pathlib import Path

SAMPLE_CODE = """\
# user_service.py
import sqlite3

def get_user(username, password):
    conn = sqlite3.connect("users.db")
    query = f"SELECT * FROM users WHERE username='{username}' AND password='{password}'"
    cursor = conn.execute(query)
    result = cursor.fetchone()
    conn.close()
    return result

def delete_user(user_id):
    conn = sqlite3.connect("users.db")
    conn.execute(f"DELETE FROM users WHERE id={user_id}")
    conn.commit()

API_KEY = "sk-1234567890abcdef"

def process_data(items):
    results = []
    for i in range(len(items)):
        results.append(items[i] * 2)
    return results
"""

DEMO_REVIEW = """\
[DEMO MODE — no API key detected]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Code Review: user_service.py

🔴 CRITICAL — SQL Injection (Lines 6, 13)
  String formatting in SQL queries allows injection attacks.
  Fix: Use parameterized queries:
    cursor = conn.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))

🔴 CRITICAL — Hardcoded API Key (Line 18)
  Secret key exposed in source code.
  Fix: Use environment variable: API_KEY = os.environ.get("API_KEY")

🟡 HIGH — No password hashing
  Passwords stored/compared as plaintext. Use bcrypt or argon2.

🟡 HIGH — No connection pooling / context managers
  DB connections not closed on exception. Use `with sqlite3.connect() as conn:`

🟠 MEDIUM — Inefficient loop (Line 21)
  `for i in range(len(items))` is non-idiomatic.
  Fix: `return [item * 2 for item in items]`

🟢 LOW — Missing type hints
  Add type hints for better IDE support and documentation.

Summary: 2 critical, 2 high, 1 medium, 1 low issues
Overall: Needs significant security fixes before production use.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Set OPENAI_API_KEY or ANTHROPIC_API_KEY to review real code.
"""

FOCUS_PROMPTS = {
    "security": "Focus on security vulnerabilities: injection, auth, secrets, input validation.",
    "performance": "Focus on performance issues: algorithmic complexity, memory leaks, I/O patterns.",
    "style": "Focus on code style, readability, naming conventions, and Pythonic patterns.",
    "all": "Review all aspects: security, performance, style, error handling, and best practices.",
}


def call_llm(code: str, filename: str, focus: str, provider: str, model: str) -> str:
    focus_instruction = FOCUS_PROMPTS.get(focus, FOCUS_PROMPTS["all"])
    prompt = (
        f"Review this code from {filename}. {focus_instruction}\n"
        "Format each issue as: [SEVERITY] — Description (Line X if known)\n"
        "Use severity levels: CRITICAL / HIGH / MEDIUM / LOW\n"
        "End with a 1-line overall assessment.\n\n"
        f"```\n{code}\n```"
    )
    if provider == "claude":
        import anthropic  # noqa: PLC0415
        client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        msg = client.messages.create(
            model=model, max_tokens=1000,
            messages=[{"role": "user", "content": prompt}],
        )
        block = msg.content[0]
        return block.text if hasattr(block, "text") else str(block)
    else:
        import openai  # noqa: PLC0415
        client = openai.OpenAI(api_key=os.environ["OPENAI_API_KEY"])
        resp = client.chat.completions.create(
            model=model, max_tokens=1000,
            messages=[
                {"role": "system", "content": "You are a senior code reviewer. Be specific, actionable, and concise."},
                {"role": "user", "content": prompt},
            ],
        )
        return resp.choices[0].message.content or ""


def review_file(file_path: Path, focus: str, provider: str, model: str) -> None:
    code = file_path.read_text(encoding="utf-8")
    if len(code) > 8000:
        code = code[:8000] + "\n... [truncated]"
    print(f"\n{'━' * 60}")
    print(f"Code Review: {file_path.name}")
    print("━" * 60)
    review = call_llm(code, file_path.name, focus, provider, model)
    print(review)


def main() -> None:
    parser = argparse.ArgumentParser(description="AI-powered code review")
    parser.add_argument("target", nargs="?", help="File or directory to review (omit for demo)")
    parser.add_argument("--ext", default=".py", help="File extension when reviewing directory (default: .py)")
    parser.add_argument("--focus", choices=list(FOCUS_PROMPTS), default="all",
                        help="Review focus area (default: all)")
    parser.add_argument("--provider", choices=["openai", "claude", "auto"], default="auto")
    parser.add_argument("--model", help="Override model name")
    args = parser.parse_args()

    openai_key = os.environ.get("OPENAI_API_KEY")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")

    if not openai_key and not anthropic_key:
        print(DEMO_REVIEW)
        return

    provider = "claude" if (args.provider == "claude" or (args.provider == "auto" and anthropic_key and not openai_key)) else "openai"
    model = args.model or ("claude-haiku-4-5-20251001" if provider == "claude" else "gpt-4o-mini")

    if not args.target:
        # 无目标时用 demo 代码
        from pathlib import Path as P  # noqa: PLC0415
        import tempfile, os as _os  # noqa: PLC0415, E401
        with tempfile.NamedTemporaryFile(suffix=".py", mode="w", delete=False) as f:
            f.write(SAMPLE_CODE)
            tmp = f.name
        try:
            review_file(P(tmp), args.focus, provider, model)
        finally:
            _os.unlink(tmp)
        return

    target = Path(args.target)
    if target.is_file():
        review_file(target, args.focus, provider, model)
    elif target.is_dir():
        files = sorted(target.rglob(f"*{args.ext}"))
        if not files:
            print(f"No {args.ext} files found in {target}")
            return
        print(f"Reviewing {len(files)} file(s)...")
        for f in files:
            try:
                review_file(f, args.focus, provider, model)
            except Exception as exc:
                print(f"  Error reviewing {f}: {exc}", file=sys.stderr)
    else:
        print(f"Error: {args.target} not found", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
