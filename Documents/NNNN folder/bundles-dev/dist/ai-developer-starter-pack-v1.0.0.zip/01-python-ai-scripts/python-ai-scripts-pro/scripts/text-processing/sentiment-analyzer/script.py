#!/usr/bin/env python3
"""
Sentiment Analyzer — Batch sentiment & emotion analysis using OpenAI or Claude.
Demo mode runs without API keys.

Usage:
  python script.py                  # demo mode
  python script.py reviews.csv      # analyze CSV file (text column)
  python script.py --text "I love this product!"
"""

import argparse
import csv
import json
import os
import sys

SAMPLE_TEXTS = [
    "This product completely exceeded my expectations. Absolutely love it!",
    "Terrible experience. The item broke after one day and support was useless.",
    "It's okay, nothing special. Gets the job done but nothing more.",
    "Amazing quality and fast shipping. Will definitely buy again.",
    "Disappointed with the packaging but the product itself is decent.",
]

DEMO_RESULTS = [
    {"text": SAMPLE_TEXTS[0], "sentiment": "positive", "score": 0.95, "emotions": ["joy", "surprise"]},
    {"text": SAMPLE_TEXTS[1], "sentiment": "negative", "score": 0.92, "emotions": ["anger", "disgust"]},
    {"text": SAMPLE_TEXTS[2], "sentiment": "neutral",  "score": 0.78, "emotions": ["indifference"]},
    {"text": SAMPLE_TEXTS[3], "sentiment": "positive", "score": 0.97, "emotions": ["joy", "trust"]},
    {"text": SAMPLE_TEXTS[4], "sentiment": "mixed",    "score": 0.61, "emotions": ["disappointment", "acceptance"]},
]

SYSTEM_PROMPT = """\
You are a sentiment analysis engine. For each text, respond with JSON only:
{"sentiment": "positive|negative|neutral|mixed", "score": 0.0-1.0, "emotions": ["list"]}
No explanations, just valid JSON."""


def analyze_batch(texts: list[str], provider: str, model: str) -> list[dict]:
    results = []
    for text in texts:
        result = analyze_one(text, provider, model)
        result["text"] = text[:80] + ("..." if len(text) > 80 else "")
        results.append(result)
    return results


def analyze_one(text: str, provider: str, model: str) -> dict:
    prompt = f"Analyze sentiment: {text}"
    raw = call_llm(prompt, SYSTEM_PROMPT, provider, model)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        # 从原始文本提取 JSON
        import re
        match = re.search(r'\{.*\}', raw, re.DOTALL)
        if match:
            return json.loads(match.group())
        return {"sentiment": "unknown", "score": 0.0, "emotions": []}


def call_llm(prompt: str, system: str, provider: str, model: str) -> str:
    if provider == "claude":
        import anthropic  # noqa: PLC0415
        client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        msg = client.messages.create(
            model=model, max_tokens=100,
            system=system,
            messages=[{"role": "user", "content": prompt}],
        )
        return msg.content[0].text
    else:
        import openai  # noqa: PLC0415
        client = openai.OpenAI(api_key=os.environ["OPENAI_API_KEY"])
        resp = client.chat.completions.create(
            model=model, max_tokens=100,
            messages=[{"role": "system", "content": system}, {"role": "user", "content": prompt}],
        )
        return resp.choices[0].message.content


def print_results(results: list[dict], demo: bool = False) -> None:
    label = "[DEMO MODE] " if demo else ""
    print(f"\n{label}Sentiment Analysis Results")
    print("━" * 60)
    for r in results:
        emoji = {"positive": "🟢", "negative": "🔴", "neutral": "🟡", "mixed": "🟠"}.get(r["sentiment"], "⚪")
        emotions = ", ".join(r.get("emotions", []))
        print(f"{emoji} {r['sentiment'].upper():8s} ({r.get('score', 0):.2f}) | {r['text']}")
        if emotions:
            print(f"           Emotions: {emotions}")
    print()
    sentiments = [r["sentiment"] for r in results]
    print(f"Summary: {sentiments.count('positive')} positive, {sentiments.count('negative')} negative, "
          f"{sentiments.count('neutral')} neutral, {sentiments.count('mixed')} mixed")


def main() -> None:
    parser = argparse.ArgumentParser(description="Batch sentiment analysis using AI")
    parser.add_argument("input", nargs="?", help="CSV file with text column (omit for demo)")
    parser.add_argument("--text", help="Analyze a single text string")
    parser.add_argument("--column", default="text", help="CSV column name (default: text)")
    parser.add_argument("--provider", choices=["openai", "claude", "auto"], default="auto")
    parser.add_argument("--model", help="Override model name")
    args = parser.parse_args()

    openai_key = os.environ.get("OPENAI_API_KEY")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")
    no_key = not openai_key and not anthropic_key

    if no_key:
        print("[DEMO MODE — set OPENAI_API_KEY or ANTHROPIC_API_KEY to analyze real text]")
        print_results(DEMO_RESULTS, demo=True)
        return

    provider = "claude" if (args.provider == "claude" or (args.provider == "auto" and anthropic_key and not openai_key)) else "openai"
    model = args.model or ("claude-haiku-4-5-20251001" if provider == "claude" else "gpt-4o-mini")

    try:
        if args.text:
            texts = [args.text]
        elif args.input:
            with open(args.input, encoding="utf-8") as f:
                reader = csv.DictReader(f)
                texts = [row[args.column] for row in reader]
        else:
            texts = SAMPLE_TEXTS

        results = analyze_batch(texts, provider, model)
        print_results(results)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
