#!/usr/bin/env python3
"""
OpenAI Chat — Interactive chat wrapper with conversation history and model selection.
Demo mode runs without API key.

Usage:
  python script.py                       # interactive chat (demo or real)
  python script.py --model gpt-4o        # use specific model
  python script.py --system "You are..." # custom system prompt
  python script.py --once "Explain AI"   # single query, non-interactive
"""

import argparse
import os
import sys

DEMO_CONVERSATION = [
    ("user", "What is Python?"),
    ("assistant", "Python is a high-level, interpreted programming language known for its "
                  "clean syntax and readability. Created by Guido van Rossum in 1991, it "
                  "supports multiple paradigms including OOP, functional, and procedural "
                  "programming. It's widely used in web dev, data science, AI/ML, automation, "
                  "and scripting."),
    ("user", "What are its main uses?"),
    ("assistant", "Python's main uses:\n"
                  "1. **Data Science & ML** — NumPy, Pandas, PyTorch, TensorFlow\n"
                  "2. **Web Development** — Django, FastAPI, Flask\n"
                  "3. **Automation** — scripting, task automation, web scraping\n"
                  "4. **AI/LLM** — OpenAI SDK, LangChain, integrations\n"
                  "5. **DevOps** — infrastructure scripts, CI/CD tooling"),
]

DEFAULT_SYSTEM = "You are a helpful, concise assistant. Keep answers clear and to the point."


def chat_demo() -> None:
    print("\n[DEMO MODE — set OPENAI_API_KEY to use real OpenAI]\n")
    print("=" * 60)
    for role, content in DEMO_CONVERSATION:
        prefix = "You: " if role == "user" else "Assistant: "
        print(f"\n{prefix}")
        print(content)
    print("\n" + "=" * 60)
    print("\nSet OPENAI_API_KEY in your environment to start a real conversation.")


def interactive_chat(client, model: str, system: str) -> None:
    import openai  # noqa: PLC0415
    messages = [{"role": "system", "content": system}]
    print(f"\nModel: {model} | Type 'quit' or Ctrl+C to exit\n")

    while True:
        try:
            user_input = input("You: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nGoodbye!")
            break

        if not user_input:
            continue
        if user_input.lower() in ("quit", "exit", "bye"):
            print("Goodbye!")
            break

        messages.append({"role": "user", "content": user_input})
        try:
            resp = client.chat.completions.create(
                model=model,
                messages=messages,
                max_tokens=1000,
                stream=True,
            )
            print("\nAssistant: ", end="", flush=True)
            full_response = ""
            for chunk in resp:
                delta = chunk.choices[0].delta.content or ""
                print(delta, end="", flush=True)
                full_response += delta
            print("\n")
            messages.append({"role": "assistant", "content": full_response})
        except openai.OpenAIError as e:
            print(f"\nAPI error: {e}", file=sys.stderr)


def main() -> None:
    parser = argparse.ArgumentParser(description="Interactive OpenAI chat with history")
    parser.add_argument("--model", default="gpt-4o-mini", help="OpenAI model (default: gpt-4o-mini)")
    parser.add_argument("--system", default=DEFAULT_SYSTEM, help="System prompt")
    parser.add_argument("--once", metavar="QUERY", help="Single query mode (non-interactive)")
    args = parser.parse_args()

    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        chat_demo()
        return

    import openai  # noqa: PLC0415
    client = openai.OpenAI(api_key=api_key)

    if args.once:
        try:
            resp = client.chat.completions.create(
                model=args.model,
                messages=[
                    {"role": "system", "content": args.system},
                    {"role": "user", "content": args.once},
                ],
                max_tokens=1000,
            )
            print(resp.choices[0].message.content)
        except Exception as exc:
            print(f"Error: {exc}", file=sys.stderr)
            sys.exit(1)
    else:
        interactive_chat(client, args.model, args.system)


if __name__ == "__main__":
    main()
