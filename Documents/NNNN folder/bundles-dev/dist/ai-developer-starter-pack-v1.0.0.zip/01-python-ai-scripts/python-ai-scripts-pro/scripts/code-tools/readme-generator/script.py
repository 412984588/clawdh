#!/usr/bin/env python3
"""
README Generator — Auto-generate README.md from a project directory.
Scans code files and uses AI to write documentation. Demo mode included.

Usage:
  python script.py                   # demo mode
  python script.py /path/to/project  # generate README for project
  python script.py . --out README.md # generate and save
"""

import argparse
import os
import sys
from pathlib import Path

DEMO_README = """\
[DEMO MODE — no API key detected]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# FastTask — CLI Task Manager

A lightweight command-line task manager built with Python and SQLite.
Track your todos without leaving the terminal.

## Features

- ✅ Add, complete, and delete tasks from the command line
- 📋 List tasks with priority and due date filtering
- 🏷️ Tag-based organization
- 💾 Local SQLite storage — no cloud, no account required
- 🔍 Full-text search across task titles and descriptions

## Installation

```bash
git clone https://github.com/user/fasttask
cd fasttask
pip install -r requirements.txt
```

## Usage

```bash
python fasttask.py add "Buy groceries" --priority high --due 2026-03-25
python fasttask.py list
python fasttask.py list --filter pending
python fasttask.py done 3
python fasttask.py delete 3
```

## Requirements

- Python 3.11+
- click >= 8.0
- sqlite3 (stdlib)

## License

MIT

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Set OPENAI_API_KEY or ANTHROPIC_API_KEY to generate README for real projects.
"""

# 要扫描的代码文件扩展名
CODE_EXTENSIONS = {".py", ".js", ".ts", ".go", ".rs", ".java", ".rb", ".php"}
SKIP_DIRS = {"node_modules", ".git", "__pycache__", ".venv", "venv", "dist", "build", ".next"}


def scan_project(project_path: Path) -> dict:
    """扫描项目目录，提取关键信息"""
    info: dict = {
        "name": project_path.name,
        "files": [],
        "languages": set(),
        "has_tests": False,
        "entry_points": [],
        "dependencies": [],
        "description_hints": [],
    }

    for p in sorted(project_path.rglob("*")):
        if any(skip in p.parts for skip in SKIP_DIRS):
            continue
        if p.is_file():
            ext = p.suffix.lower()
            rel = p.relative_to(project_path)

            if ext in CODE_EXTENSIONS:
                info["files"].append(str(rel))
                info["languages"].add(ext.lstrip("."))

            if p.name in ("requirements.txt", "package.json", "go.mod", "Cargo.toml", "pyproject.toml"):
                try:
                    info["dependencies"].append(p.read_text(encoding="utf-8", errors="ignore")[:500])
                except OSError:
                    pass

            if p.name in ("main.py", "app.py", "index.py", "cli.py", "server.py", "index.js", "index.ts"):
                info["entry_points"].append(str(rel))

            if "test" in p.name.lower() or "spec" in p.name.lower():
                info["has_tests"] = True

    info["languages"] = sorted(info["languages"])
    return info


def call_llm(project_info: dict, provider: str, model: str) -> str:
    files_sample = "\n".join(project_info["files"][:30])
    deps_sample = "\n---\n".join(project_info["dependencies"][:2])

    prompt = (
        f"Generate a professional README.md for a project called '{project_info['name']}'.\n"
        f"Languages: {', '.join(project_info['languages']) or 'unknown'}\n"
        f"Has tests: {project_info['has_tests']}\n"
        f"Entry points: {', '.join(project_info['entry_points']) or 'none detected'}\n\n"
        f"Project files:\n{files_sample}\n\n"
        f"Dependencies:\n{deps_sample or 'none found'}\n\n"
        "Write a README with: project name + tagline, features list, installation, "
        "basic usage with code examples, requirements, and license (assume MIT). "
        "Use Markdown formatting with emoji where appropriate."
    )

    if provider == "claude":
        import anthropic  # noqa: PLC0415
        client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        msg = client.messages.create(
            model=model, max_tokens=1500,
            messages=[{"role": "user", "content": prompt}],
        )
        block = msg.content[0]
        return block.text if hasattr(block, "text") else str(block)
    else:
        import openai  # noqa: PLC0415
        client = openai.OpenAI(api_key=os.environ["OPENAI_API_KEY"])
        resp = client.chat.completions.create(
            model=model, max_tokens=1500,
            messages=[
                {"role": "system", "content": "You are a technical writer. Generate clear, helpful README files."},
                {"role": "user", "content": prompt},
            ],
        )
        return resp.choices[0].message.content or ""


def main() -> None:
    parser = argparse.ArgumentParser(description="Auto-generate README.md from project directory")
    parser.add_argument("project", nargs="?", default=".", help="Project directory (default: current dir)")
    parser.add_argument("--out", help="Output file path (default: print to stdout)")
    parser.add_argument("--provider", choices=["openai", "claude", "auto"], default="auto")
    parser.add_argument("--model", help="Override model name")
    args = parser.parse_args()

    openai_key = os.environ.get("OPENAI_API_KEY")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")

    if not openai_key and not anthropic_key:
        print(DEMO_README)
        return

    project_path = Path(args.project).resolve()
    if not project_path.is_dir():
        print(f"Error: {args.project} is not a directory", file=sys.stderr)
        sys.exit(1)

    print(f"Scanning {project_path}...")
    info = scan_project(project_path)
    print(f"Found {len(info['files'])} code files in {', '.join(info['languages']) or 'unknown'} language(s)")

    provider = "claude" if (args.provider == "claude" or (args.provider == "auto" and anthropic_key and not openai_key)) else "openai"
    model = args.model or ("claude-haiku-4-5-20251001" if provider == "claude" else "gpt-4o-mini")

    try:
        print("Generating README...\n")
        readme = call_llm(info, provider, model)
        if args.out:
            Path(args.out).write_text(readme, encoding="utf-8")
            print(f"✅ README saved to {args.out}")
        else:
            print(readme)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
