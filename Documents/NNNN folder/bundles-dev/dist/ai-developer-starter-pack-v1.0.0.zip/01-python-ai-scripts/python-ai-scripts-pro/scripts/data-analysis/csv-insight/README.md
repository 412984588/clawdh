# CSV Insight

> **Category:** Data Analysis | **Deps:** openai, anthropic

Analyze any CSV dataset and generate a natural language business report. Computes statistics automatically and asks AI for interpretation.

## Setup

```bash
pip install -r requirements.txt
```

Create a `.env` file (or export env vars):
```
OPENAI_API_KEY=your_key_here
# or
ANTHROPIC_API_KEY=your_key_here
```

## Usage

**Demo mode** (no API key needed):
```bash
python script.py
```

**With API key:**
```bash
OPENAI_API_KEY=sk-... python script.py sales.csv
python script.py data.csv --out report.md
```

## Options

Run `python script.py --help` for all options.

## Validation

```bash
pip install -r requirements.txt && python script.py
```

Expected: Demo output printed to stdout, exit code 0.
