# Claude Chat

> **Category:** LLM Integration | **Deps:** anthropic

Interactive chat wrapper for Anthropic Claude with real-time streaming output, multi-turn history, and model selection.

## Setup

```bash
pip install -r requirements.txt
```

Create a `.env` file (or export env vars):
```
ANTHROPIC_API_KEY=your_key_here
```

## Usage

**Demo mode** (no API key needed):
```bash
python script.py
```

**With API key:**
```bash
ANTHROPIC_API_KEY=sk-ant-... python script.py
python script.py --model claude-opus-4-6
python script.py --once 'Review this code'
```

## Options

Run `python script.py --help` for all options.

## Validation

```bash
pip install -r requirements.txt && python script.py
```

Expected: Demo output printed to stdout, exit code 0.
