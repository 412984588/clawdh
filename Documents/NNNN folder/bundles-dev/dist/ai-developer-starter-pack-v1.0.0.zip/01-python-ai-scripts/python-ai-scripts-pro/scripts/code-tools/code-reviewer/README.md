# Code Reviewer

> **Category:** Code Tools | **Deps:** openai, anthropic

AI-powered code review for Python, JS, TypeScript and more. Groups issues by severity: CRITICAL/HIGH/MEDIUM/LOW.

## Setup

```bash
pip install -r requirements.txt
```

Create a `.env` file or export env vars:
```
OPENAI_API_KEY=your_key_here
# or
ANTHROPIC_API_KEY=your_key_here
```

## Usage

**Demo mode** (no API key needed):
```bash
python script.py
```

**With API key:**
```bash
OPENAI_API_KEY=sk-... python script.py app.py
python script.py src/ --ext .py  # review directory
python script.py app.py --focus security
```

## Options

Run `python script.py --help` for all options.

## Validation

```bash
pip install -r requirements.txt && python script.py
```

Expected: Demo output printed to stdout, exit code 0.
