#!/usr/bin/env python3
"""
Social Post Generator — Create platform-optimized social media posts from content.
Demo mode runs without API keys.

Usage:
  python script.py                                        # demo mode
  python script.py --content "Launched our new AI tool"  # generate posts
  python script.py --file article.md --platforms twitter,linkedin
  python script.py --content "..." --tone professional
"""

import argparse
import os
import sys
from pathlib import Path

PLATFORMS = {
    "twitter":   {"name": "Twitter/X", "max_chars": 280,  "style": "punchy, hooks, use 1-2 hashtags, may use thread format"},
    "linkedin":  {"name": "LinkedIn",  "max_chars": 3000, "style": "professional, insight-driven, story arc, 3-5 hashtags"},
    "instagram": {"name": "Instagram", "max_chars": 2200, "style": "visual storytelling, emotion-driven, 5-10 hashtags, CTA"},
    "reddit":    {"name": "Reddit",    "max_chars": 10000,"style": "authentic, value-first, no sales language, community-focused"},
}

DEMO_CONTENT = "We just launched Python AI Scripts Pack — 30 ready-to-run Python scripts for AI automation. Works in demo mode without API keys."

DEMO_OUTPUT = """\
[DEMO MODE — no API key detected]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🐦 Twitter/X (280 chars):
─────────────────────────────
Just shipped: Python AI Scripts Pack 🐍

30 ready-to-run scripts for AI automation.
Best part? Demo mode works without any API keys.

Pick up and run in 2 minutes. 👇
[link]

#Python #AI #OpenSource

💼 LinkedIn (Professional):
─────────────────────────────
We spent weeks building something we wish had existed when we started
with AI development.

Python AI Scripts Pack: 30 battle-tested scripts covering text processing,
data analysis, automation, and LLM integration.

What makes it different: every script runs in demo mode without API keys.
Download → run → see results. No setup friction.

The scripts that resonated most in beta:
→ CSV Insight (AI-written business reports from your data)
→ Code Reviewer (security + style analysis in seconds)
→ Ollama Local (completely private, runs on your machine)

Available now. Link in comments.

#Python #AI #Developer #Automation #LLM

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Set OPENAI_API_KEY or ANTHROPIC_API_KEY to generate posts for real content.
"""


def call_llm(prompt: str, provider: str, model: str) -> str:
    if provider == "claude":
        import anthropic  # noqa: PLC0415
        client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        msg = client.messages.create(
            model=model, max_tokens=1200,
            messages=[{"role": "user", "content": prompt}],
        )
        block = msg.content[0]
        return block.text if hasattr(block, "text") else str(block)
    else:
        import openai  # noqa: PLC0415
        client = openai.OpenAI(api_key=os.environ["OPENAI_API_KEY"])
        resp = client.chat.completions.create(
            model=model, max_tokens=1200,
            messages=[
                {"role": "system", "content": "You are a social media expert. Write authentic, engaging posts optimized for each platform."},
                {"role": "user", "content": prompt},
            ],
        )
        return resp.choices[0].message.content or ""


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate social media posts from content using AI")
    parser.add_argument("--content", "-c", help="Content or announcement to post about")
    parser.add_argument("--file", "-f", help="Read content from file")
    parser.add_argument("--platforms", default="twitter,linkedin",
                        help=f"Comma-separated platforms (default: twitter,linkedin). Options: {','.join(PLATFORMS)}")
    parser.add_argument("--tone", choices=["professional", "casual", "excited", "educational"], default="casual",
                        help="Tone of voice (default: casual)")
    parser.add_argument("--cta", help="Call-to-action (e.g. 'Link in bio', 'Comment below')")
    parser.add_argument("--provider", choices=["openai", "claude", "auto"], default="auto")
    parser.add_argument("--model", help="Override model name")
    args = parser.parse_args()

    openai_key = os.environ.get("OPENAI_API_KEY")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")

    if not openai_key and not anthropic_key:
        print(DEMO_OUTPUT)
        return

    content = args.content
    if args.file:
        content = Path(args.file).read_text(encoding="utf-8")
    if not content:
        content = DEMO_CONTENT

    platform_names = [p.strip() for p in args.platforms.split(",")]
    valid_platforms = {k: v for k, v in PLATFORMS.items() if k in platform_names}
    if not valid_platforms:
        print(f"No valid platforms. Choose from: {', '.join(PLATFORMS)}", file=sys.stderr)
        sys.exit(1)

    platform_specs = "\n".join(
        f"- {info['name']}: max {info['max_chars']} chars, style: {info['style']}"
        for info in valid_platforms.values()
    )
    cta_note = f"\nCall-to-action: {args.cta}" if args.cta else ""

    prompt = (
        f"Write optimized social media posts for the following platforms:\n{platform_specs}\n\n"
        f"Content/announcement:\n{content}\n"
        f"Tone: {args.tone}{cta_note}\n\n"
        "Format each post clearly with the platform name as a header. "
        "Stay within character limits. Include appropriate hashtags."
    )

    provider = "claude" if (args.provider == "claude" or (args.provider == "auto" and anthropic_key and not openai_key)) else "openai"
    model = args.model or ("claude-haiku-4-5-20251001" if provider == "claude" else "gpt-4o-mini")

    try:
        print("Generating posts...\n")
        posts = call_llm(prompt, provider, model)
        print("━" * 60)
        print(posts)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
