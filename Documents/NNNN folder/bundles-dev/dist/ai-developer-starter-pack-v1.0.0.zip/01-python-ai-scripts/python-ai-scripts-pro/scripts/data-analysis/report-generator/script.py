#!/usr/bin/env python3
"""
Report Generator — Convert structured JSON/CSV data into formatted Markdown reports.
Demo mode runs without API keys.

Usage:
  python script.py                       # demo with sample project data
  python script.py data.json             # generate report from JSON
  python script.py data.csv --type table # render as formatted table
  python script.py data.json --out report.md
"""

import argparse
import csv
import json
import os
import sys
from pathlib import Path

SAMPLE_DATA = {
    "project": "Q2 Product Launch",
    "period": "April–June 2026",
    "team_size": 8,
    "milestones": [
        {"name": "Design Complete", "status": "done", "date": "2026-04-15"},
        {"name": "Backend API", "status": "done", "date": "2026-05-01"},
        {"name": "Frontend Beta", "status": "done", "date": "2026-05-20"},
        {"name": "QA Testing", "status": "in_progress", "date": "2026-06-01"},
        {"name": "Production Launch", "status": "pending", "date": "2026-06-15"},
    ],
    "metrics": {"bugs_found": 23, "bugs_fixed": 19, "test_coverage": "78%", "performance_score": 94},
    "blockers": ["Stripe webhook integration delayed", "iOS certificate renewal pending"],
}

DEMO_REPORT = """\
[DEMO MODE — no API key detected]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Q2 Product Launch — Status Report
**Period:** April–June 2026 | **Team:** 8 members

## Milestone Progress

| Milestone | Status | Date |
|-----------|--------|------|
| ✅ Design Complete | Done | Apr 15 |
| ✅ Backend API | Done | May 1 |
| ✅ Frontend Beta | Done | May 20 |
| 🔄 QA Testing | In Progress | Jun 1 |
| ⏳ Production Launch | Pending | Jun 15 |

**Progress: 60% complete (3/5 milestones done)**

## Quality Metrics
- Test coverage: 78%
- Bugs found: 23 | Fixed: 19 (83% resolution rate)
- Performance score: 94/100

## Blockers
1. Stripe webhook integration delayed
2. iOS certificate renewal pending

## Assessment
The project is on track for the June 15 launch. QA is active and the
high performance score (94) indicates solid engineering. The two blockers
should be resolved this week to keep the timeline intact.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Set OPENAI_API_KEY or ANTHROPIC_API_KEY to generate reports from your own data.
"""


def call_llm(prompt: str, provider: str, model: str) -> str:
    if provider == "claude":
        import anthropic  # noqa: PLC0415
        client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        msg = client.messages.create(
            model=model, max_tokens=1200,
            messages=[{"role": "user", "content": prompt}],
        )
        block = msg.content[0]
        return block.text if hasattr(block, "text") else str(block)
    else:
        import openai  # noqa: PLC0415
        client = openai.OpenAI(api_key=os.environ["OPENAI_API_KEY"])
        resp = client.chat.completions.create(
            model=model, max_tokens=1200,
            messages=[
                {"role": "system", "content": "You are a professional report writer. Use Markdown formatting."},
                {"role": "user", "content": prompt},
            ],
        )
        return resp.choices[0].message.content or ""


def load_data(path: str) -> dict | list:
    p = Path(path)
    if p.suffix == ".json":
        return json.loads(p.read_text(encoding="utf-8"))
    elif p.suffix == ".csv":
        with open(p, encoding="utf-8") as f:
            return list(csv.DictReader(f))
    else:
        raise ValueError(f"Unsupported file format: {p.suffix}. Use .json or .csv")


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate Markdown report from structured data")
    parser.add_argument("input", nargs="?", help="JSON or CSV file (omit for demo)")
    parser.add_argument("--out", help="Output .md file path")
    parser.add_argument("--title", default="", help="Report title override")
    parser.add_argument("--provider", choices=["openai", "claude", "auto"], default="auto")
    parser.add_argument("--model", help="Override model name")
    args = parser.parse_args()

    openai_key = os.environ.get("OPENAI_API_KEY")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")

    if not openai_key and not anthropic_key:
        print(DEMO_REPORT)
        return

    data = load_data(args.input) if args.input else SAMPLE_DATA
    data_str = json.dumps(data, indent=2, ensure_ascii=False)[:4000]
    title = args.title or (args.input and Path(args.input).stem) or "Report"

    prompt = (
        f"Generate a professional Markdown report titled '{title}' from this data. "
        "Include relevant sections, tables where appropriate, and a brief assessment. "
        "Be concise and actionable.\n\n"
        f"Data:\n{data_str}"
    )

    provider = "claude" if (args.provider == "claude" or (args.provider == "auto" and anthropic_key and not openai_key)) else "openai"
    model = args.model or ("claude-haiku-4-5-20251001" if provider == "claude" else "gpt-4o-mini")

    try:
        print("Generating report...\n")
        report = call_llm(prompt, provider, model)
        if args.out:
            Path(args.out).write_text(report, encoding="utf-8")
            print(f"✅ Report saved to {args.out}")
        else:
            print(report)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
