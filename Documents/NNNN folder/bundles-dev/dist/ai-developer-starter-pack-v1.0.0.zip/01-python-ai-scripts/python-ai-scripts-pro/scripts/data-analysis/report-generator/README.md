# Report Generator

> **Category:** Data Analysis | **Deps:** openai, anthropic

Convert JSON or CSV structured data into formatted Markdown reports with tables, summaries, and recommendations.

## Setup

```bash
pip install -r requirements.txt
```

Create a `.env` file (or export env vars):
```
OPENAI_API_KEY=your_key_here
# or
ANTHROPIC_API_KEY=your_key_here
```

## Usage

**Demo mode** (no API key needed):
```bash
python script.py
```

**With API key:**
```bash
OPENAI_API_KEY=sk-... python script.py project.json --out report.md
python script.py metrics.csv --title 'Q2 Performance'
```

## Options

Run `python script.py --help` for all options.

## Validation

```bash
pip install -r requirements.txt && python script.py
```

Expected: Demo output printed to stdout, exit code 0.
