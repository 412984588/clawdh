# Invoice Generator

Generate professional HTML invoices from JSON data. No API key needed — pure Python, outputs a polished self-contained HTML file.

## Demo (no setup)

```bash
python script.py
# Generates invoice.html with sample data
```

## Usage

```bash
# Generate from JSON
python script.py invoice.json

# Custom output file
python script.py invoice.json --out my-invoice.html

# Auto-open in browser
python script.py invoice.json --open

# Demo (sample invoice)
python script.py --open
```

## Input Format

```json
{
  "invoice_number": "INV-2026-042",
  "issue_date": "2026-03-20",
  "due_date": "2026-04-03",
  "from": {
    "name": "Acme Design Studio",
    "address": "123 Creative Ave, San Francisco, CA 94105",
    "email": "billing@acme.co",
    "tax_id": "US-12-3456789"
  },
  "to": {
    "name": "TechCorp Inc.",
    "address": "456 Innovation Blvd, New York, NY 10001",
    "email": "accounts@techcorp.com"
  },
  "items": [
    {"description": "Brand Identity Design", "qty": 1, "rate": 2500.00},
    {"description": "Revision Rounds",        "qty": 3, "rate": 250.00}
  ],
  "tax_rate": 0.08,
  "currency": "USD",
  "notes": "Payment due within 14 days.",
  "bank_details": "Bank: Chase | Account: 1234567890"
}
```

## Options

| Flag | Default | Description |
|------|---------|-------------|
| `input` | demo | JSON invoice data file |
| `--out` | `invoice.html` | Output HTML file |
| `--open` | false | Auto-open in browser |

## Features

- Automatic subtotal, tax, and total calculation
- "Due in N days" / "Overdue" badge
- Tax ID line (optional)
- Notes and bank details section
- Print-ready CSS layout
