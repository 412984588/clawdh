#!/usr/bin/env python3
"""
Markdown Converter — Convert HTML, plain text, or RST to clean Markdown.
AI polishes the output. Demo mode runs without API keys.

Usage:
  python script.py                         # demo mode
  python script.py page.html               # convert HTML to Markdown
  python script.py notes.txt --format rst  # convert RST to Markdown
  python script.py page.html --no-ai       # convert without AI cleanup
  python script.py page.html --out page.md
"""

import argparse
import html.parser
import os
import re
import sys
from pathlib import Path

SAMPLE_HTML = """\
<html><body>
<h1>Getting Started with FastAPI</h1>
<p>FastAPI is a <strong>modern, fast</strong> web framework for building APIs with Python.</p>
<h2>Installation</h2>
<p>Install with pip:</p>
<pre><code>pip install fastapi uvicorn</code></pre>
<h2>Quick Example</h2>
<p>Create a simple API in <em>three lines</em>:</p>
<ul>
<li>Import FastAPI</li>
<li>Create an app instance</li>
<li>Define route functions</li>
</ul>
<p>FastAPI automatically generates <a href="https://fastapi.tiangolo.com">interactive docs</a>.</p>
</body></html>
"""

DEMO_OUTPUT = """\
[DEMO MODE — no API key detected]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Converted Markdown:

# Getting Started with FastAPI

FastAPI is a **modern, fast** web framework for building APIs with Python.

## Installation

Install with pip:

```
pip install fastapi uvicorn
```

## Quick Example

Create a simple API in *three lines*:

- Import FastAPI
- Create an app instance
- Define route functions

FastAPI automatically generates [interactive docs](https://fastapi.tiangolo.com).

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Set OPENAI_API_KEY or ANTHROPIC_API_KEY for AI-polished Markdown output.
"""


class HtmlToMarkdown(html.parser.HTMLParser):
    """简单 HTML → Markdown 转换器（无外部依赖）"""

    def __init__(self) -> None:
        super().__init__()
        self._output: list[str] = []
        self._in_pre = False
        self._in_code = False
        self._list_depth = 0
        self._current_tag = ""

    def handle_starttag(self, tag: str, attrs: list) -> None:
        self._current_tag = tag
        attr_dict = dict(attrs)
        if tag in ("h1", "h2", "h3", "h4"):
            level = int(tag[1])
            self._output.append("\n" + "#" * level + " ")
        elif tag == "p":
            self._output.append("\n\n")
        elif tag == "strong" or tag == "b":
            self._output.append("**")
        elif tag == "em" or tag == "i":
            self._output.append("*")
        elif tag == "pre":
            self._in_pre = True
            self._output.append("\n\n```\n")
        elif tag == "code" and not self._in_pre:
            self._output.append("`")
        elif tag == "a":
            href = attr_dict.get("href", "")
            self._output.append("[")
            self._href = href
        elif tag in ("ul", "ol"):
            self._list_depth += 1
        elif tag == "li":
            self._output.append("\n" + "  " * (self._list_depth - 1) + "- ")
        elif tag == "br":
            self._output.append("  \n")

    def handle_endtag(self, tag: str) -> None:
        if tag in ("h1", "h2", "h3", "h4"):
            self._output.append("\n")
        elif tag == "strong" or tag == "b":
            self._output.append("**")
        elif tag == "em" or tag == "i":
            self._output.append("*")
        elif tag == "pre":
            self._in_pre = False
            self._output.append("\n```\n")
        elif tag == "code" and not self._in_pre:
            self._output.append("`")
        elif tag == "a":
            self._output.append(f"]({getattr(self, '_href', '')})")
        elif tag in ("ul", "ol"):
            self._list_depth = max(0, self._list_depth - 1)
            self._output.append("\n")

    def handle_data(self, data: str) -> None:
        self._output.append(data)

    def get_markdown(self) -> str:
        raw = "".join(self._output)
        # 清理多余空行
        raw = re.sub(r'\n{3,}', '\n\n', raw)
        return raw.strip()


def html_to_markdown(html_text: str) -> str:
    parser = HtmlToMarkdown()
    parser.feed(html_text)
    return parser.get_markdown()


def text_to_markdown(text: str) -> str:
    """纯文本基础 Markdown 处理"""
    lines = text.split("\n")
    result = []
    for line in lines:
        stripped = line.strip()
        if stripped.isupper() and len(stripped) < 80:
            result.append(f"## {stripped.title()}")
        else:
            result.append(line)
    return "\n".join(result)


def polish_with_ai(markdown: str, provider: str, model: str) -> str:
    prompt = (
        "Clean up and polish this Markdown content. Fix formatting issues, ensure consistent "
        "heading hierarchy, and improve readability. Return only the improved Markdown, "
        "no explanations.\n\n" + markdown
    )
    if provider == "claude":
        import anthropic  # noqa: PLC0415
        client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        msg = client.messages.create(
            model=model, max_tokens=2000,
            messages=[{"role": "user", "content": prompt}],
        )
        block = msg.content[0]
        return block.text if hasattr(block, "text") else str(block)
    else:
        import openai  # noqa: PLC0415
        client = openai.OpenAI(api_key=os.environ["OPENAI_API_KEY"])
        resp = client.chat.completions.create(
            model=model, max_tokens=2000,
            messages=[{"role": "user", "content": prompt}],
        )
        return resp.choices[0].message.content or ""


def main() -> None:
    parser = argparse.ArgumentParser(description="Convert HTML/text to Markdown with AI cleanup")
    parser.add_argument("input", nargs="?", help="Input file (omit for demo)")
    parser.add_argument("--format", choices=["html", "text", "auto"], default="auto",
                        help="Input format (default: auto-detect)")
    parser.add_argument("--no-ai", action="store_true", help="Skip AI polish step")
    parser.add_argument("--out", help="Output .md file path")
    parser.add_argument("--provider", choices=["openai", "claude", "auto"], default="auto")
    parser.add_argument("--model", help="Override model name")
    args = parser.parse_args()

    openai_key = os.environ.get("OPENAI_API_KEY")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")

    if not args.input:
        print(DEMO_OUTPUT)
        return

    content = Path(args.input).read_text(encoding="utf-8")
    fmt = args.format
    if fmt == "auto":
        fmt = "html" if args.input.endswith((".html", ".htm")) else "text"

    print(f"Converting {args.input} ({fmt} → markdown)...")
    markdown = html_to_markdown(content) if fmt == "html" else text_to_markdown(content)

    if not args.no_ai and (openai_key or anthropic_key):
        provider = "claude" if (args.provider == "claude" or (args.provider == "auto" and anthropic_key and not openai_key)) else "openai"
        model = args.model or ("claude-haiku-4-5-20251001" if provider == "claude" else "gpt-4o-mini")
        print("AI polishing...")
        markdown = polish_with_ai(markdown, provider, model)

    if args.out:
        Path(args.out).write_text(markdown, encoding="utf-8")
        print(f"✅ Saved to {args.out}")
    else:
        print("\n" + "━" * 50)
        print(markdown)


if __name__ == "__main__":
    main()
