# Hashtag Optimizer

> **Category:** Social Media | **Deps:** openai, anthropic

AI-powered hashtag research grouped by volume (high/medium/niche). Includes a copy-paste ready recommended mix.

## Setup

```bash
pip install -r requirements.txt
```

Create a `.env` file or export env vars:
```
OPENAI_API_KEY=your_key_here
# or
ANTHROPIC_API_KEY=your_key_here
```

## Usage

**Demo mode** (no API key needed):
```bash
python script.py
```

**With API key:**
```bash
OPENAI_API_KEY=sk-... python script.py --content 'Python FastAPI tutorial'
python script.py --content '...' --platform instagram --count 30
```

## Options

Run `python script.py --help` for all options.

## Validation

```bash
pip install -r requirements.txt && python script.py
```

Expected: Demo output printed to stdout, exit code 0.
