#!/usr/bin/env python3
"""
PDF Extractor — Extract text from PDFs and optionally summarize with AI.
Demo mode runs without API keys or PDF files.

Usage:
  python script.py                      # demo mode
  python script.py document.pdf         # extract text
  python script.py document.pdf --summarize   # extract + AI summary
  python script.py document.pdf --out extracted.txt
"""

import argparse
import os
import sys
from pathlib import Path

DEMO_TEXT = """\
[Extracted from: sample_report.pdf — Page 1 of 3]

Executive Summary

This report analyzes the performance of our AI-powered customer service
platform over Q1 2026. Key metrics show a 34% reduction in average response
time, a 28% improvement in customer satisfaction scores (CSAT), and a 15%
decrease in escalations to human agents.

The platform handled 142,000 customer interactions during the quarter, with
an AI resolution rate of 78%. Cost per interaction dropped from $4.20 to
$2.85, representing a 32% cost reduction compared to the fully human-staffed
baseline from Q1 2025.

[Page 2 of 3]

Methodology

Data was collected from our CRM system, Zendesk integration, and internal
analytics platform. Customer satisfaction was measured through post-interaction
surveys with a response rate of 23%...
"""

DEMO_SUMMARY = """\
[DEMO MODE — no API key detected]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PDF: sample_report.pdf (3 pages, ~1,200 words)

AI Summary:
The Q1 2026 report shows strong ROI from the AI customer service platform:
response times down 34%, satisfaction up 28%, and cost per interaction reduced
from $4.20 to $2.85 (-32%). The AI resolved 78% of 142K interactions without
human intervention.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Install pypdf and set OPENAI_API_KEY or ANTHROPIC_API_KEY to process real PDFs.
"""


def extract_pdf_text(pdf_path: str) -> tuple[str, int]:
    """提取 PDF 文本，返回 (全文, 页数)"""
    try:
        import pypdf  # noqa: PLC0415
    except ImportError:
        print("Error: pypdf not installed. Run: pip install pypdf", file=sys.stderr)
        sys.exit(1)

    reader = pypdf.PdfReader(pdf_path)
    pages = []
    for i, page in enumerate(reader.pages):
        text = page.extract_text() or ""
        if text.strip():
            pages.append(f"[Page {i + 1}]\n{text}")
    return "\n\n".join(pages), len(reader.pages)


def call_llm(text: str, provider: str, model: str) -> str:
    prompt = (
        "Summarize this PDF document concisely. Include: main topic, key findings/points, "
        "and any important numbers or conclusions. Be brief (3-5 sentences).\n\n"
        f"Document text:\n{text[:4000]}"
    )
    if provider == "claude":
        import anthropic  # noqa: PLC0415
        client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        msg = client.messages.create(
            model=model, max_tokens=400,
            messages=[{"role": "user", "content": prompt}],
        )
        block = msg.content[0]
        return block.text if hasattr(block, "text") else str(block)
    else:
        import openai  # noqa: PLC0415
        client = openai.OpenAI(api_key=os.environ["OPENAI_API_KEY"])
        resp = client.chat.completions.create(
            model=model, max_tokens=400,
            messages=[{"role": "user", "content": prompt}],
        )
        return resp.choices[0].message.content or ""


def main() -> None:
    parser = argparse.ArgumentParser(description="Extract text from PDFs and summarize with AI")
    parser.add_argument("pdf", nargs="?", help="PDF file path (omit for demo)")
    parser.add_argument("--summarize", "-s", action="store_true", help="Generate AI summary")
    parser.add_argument("--out", help="Save extracted text to file")
    parser.add_argument("--pages", help="Page range to extract (e.g. '1-5' or '3')")
    parser.add_argument("--provider", choices=["openai", "claude", "auto"], default="auto")
    parser.add_argument("--model", help="Override model name")
    args = parser.parse_args()

    openai_key = os.environ.get("OPENAI_API_KEY")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")

    if not args.pdf:
        if not openai_key and not anthropic_key:
            print(DEMO_SUMMARY)
        else:
            print(DEMO_TEXT)
            print("\n[No PDF provided — showing sample extraction. Pass a PDF path to process real files.]")
        return

    if not Path(args.pdf).exists():
        print(f"Error: file not found: {args.pdf}", file=sys.stderr)
        sys.exit(1)

    print(f"Extracting text from {args.pdf}...")
    text, page_count = extract_pdf_text(args.pdf)

    if not text.strip():
        print("Warning: no text extracted (PDF may be image-based)")
        return

    word_count = len(text.split())
    print(f"Extracted {word_count} words from {page_count} pages\n")

    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
        print(f"✅ Text saved to {args.out}")
    else:
        print(text[:2000])
        if len(text) > 2000:
            print(f"\n... [{len(text) - 2000} more characters — use --out to save full text]")

    if args.summarize and (openai_key or anthropic_key):
        provider = "claude" if (args.provider == "claude" or (args.provider == "auto" and anthropic_key and not openai_key)) else "openai"
        model = args.model or ("claude-haiku-4-5-20251001" if provider == "claude" else "gpt-4o-mini")
        print("\nGenerating AI summary...")
        summary = call_llm(text, provider, model)
        print("\nSummary:")
        print("━" * 50)
        print(summary)
    elif args.summarize:
        print("\n[Set OPENAI_API_KEY or ANTHROPIC_API_KEY to enable AI summary]")


if __name__ == "__main__":
    main()
