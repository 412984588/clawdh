#!/usr/bin/env python3
"""
Ollama Local — Chat with locally running LLMs via Ollama.
Demo mode runs without Ollama installed.

Requirements: Ollama running locally (https://ollama.ai)
  ollama serve          # start server
  ollama pull llama3.2  # download model

Usage:
  python script.py                         # demo or interactive chat
  python script.py --model mistral         # use specific model
  python script.py --list                  # list available models
  python script.py --once "Explain LLMs"  # single query
"""

import argparse
import json
import sys
from urllib.request import Request, urlopen
from urllib.error import URLError

OLLAMA_BASE = "http://localhost:11434"

DEMO_OUTPUT = """\
[DEMO MODE — Ollama not detected at localhost:11434]

To use this script:
  1. Install Ollama: https://ollama.ai
  2. Start the server: ollama serve
  3. Pull a model:    ollama pull llama3.2
  4. Run this script: python script.py

Supported models (examples):
  • llama3.2      — Meta LLaMA 3.2 (recommended, fast)
  • mistral       — Mistral 7B
  • gemma3        — Google Gemma 3
  • phi4          — Microsoft Phi-4 (small, efficient)
  • codellama     — Code-optimized LLaMA
  • qwen2.5       — Alibaba Qwen 2.5

Example session (simulated):
  You: What is machine learning?
  llama3.2: Machine learning is a subset of AI where systems learn patterns
  from data to make predictions or decisions without being explicitly
  programmed for each task...
"""


def ollama_available() -> bool:
    try:
        req = Request(f"{OLLAMA_BASE}/api/tags")
        with urlopen(req, timeout=2):
            return True
    except (URLError, OSError):
        return False


def list_models() -> list[str]:
    req = Request(f"{OLLAMA_BASE}/api/tags")
    with urlopen(req) as resp:
        data = json.loads(resp.read())
    return [m["name"] for m in data.get("models", [])]


def chat_once(model: str, prompt: str, system: str | None) -> str:
    """单次非流式请求"""
    payload = {"model": model, "prompt": prompt, "stream": False}
    if system:
        payload["system"] = system
    body = json.dumps(payload).encode()
    req = Request(f"{OLLAMA_BASE}/api/generate", data=body,
                  headers={"Content-Type": "application/json"})
    with urlopen(req, timeout=120) as resp:
        data = json.loads(resp.read())
    return data.get("response", "")


def chat_stream(model: str, messages: list[dict], system: str | None) -> str:
    """流式对话接口"""
    payload = {"model": model, "messages": messages, "stream": True}
    if system:
        payload["system"] = system
    body = json.dumps(payload).encode()
    req = Request(f"{OLLAMA_BASE}/api/chat", data=body,
                  headers={"Content-Type": "application/json"})
    full = ""
    with urlopen(req, timeout=120) as resp:
        for line in resp:
            if not line.strip():
                continue
            try:
                chunk = json.loads(line)
                content = chunk.get("message", {}).get("content", "")
                print(content, end="", flush=True)
                full += content
                if chunk.get("done"):
                    break
            except json.JSONDecodeError:
                pass
    return full


def interactive_chat(model: str, system: str | None) -> None:
    messages: list[dict] = []
    print(f"\nModel: {model} | Type 'quit' or Ctrl+C to exit\n")

    while True:
        try:
            user_input = input("You: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nGoodbye!")
            break

        if not user_input:
            continue
        if user_input.lower() in ("quit", "exit", "bye"):
            print("Goodbye!")
            break

        messages.append({"role": "user", "content": user_input})
        print(f"\n{model}: ", end="", flush=True)
        try:
            response = chat_stream(model, messages, system)
            print("\n")
            messages.append({"role": "assistant", "content": response})
        except Exception as exc:
            print(f"\nError: {exc}", file=sys.stderr)


def main() -> None:
    parser = argparse.ArgumentParser(description="Chat with local Ollama models")
    parser.add_argument("--model", default="llama3.2", help="Model name (default: llama3.2)")
    parser.add_argument("--system", help="System prompt")
    parser.add_argument("--once", metavar="QUERY", help="Single query mode")
    parser.add_argument("--list", action="store_true", help="List available models and exit")
    args = parser.parse_args()

    if not ollama_available():
        print(DEMO_OUTPUT)
        return

    if args.list:
        models = list_models()
        if models:
            print("Available models:")
            for m in models:
                print(f"  • {m}")
        else:
            print("No models installed. Run: ollama pull llama3.2")
        return

    if args.once:
        try:
            result = chat_once(args.model, args.once, args.system)
            print(result)
        except Exception as exc:
            print(f"Error: {exc}", file=sys.stderr)
            sys.exit(1)
    else:
        interactive_chat(args.model, args.system)


if __name__ == "__main__":
    main()
