# README Generator

> **Category:** Code Tools | **Deps:** openai, anthropic

Scan a project directory and auto-generate a README.md. Detects languages, entry points, and dependencies.

## Setup

```bash
pip install -r requirements.txt
```

Create a `.env` file or export env vars:
```
OPENAI_API_KEY=your_key_here
# or
ANTHROPIC_API_KEY=your_key_here
```

## Usage

**Demo mode** (no API key needed):
```bash
python script.py
```

**With API key:**
```bash
OPENAI_API_KEY=sk-... python script.py /path/to/project
python script.py . --out README.md
```

## Options

Run `python script.py --help` for all options.

## Validation

```bash
pip install -r requirements.txt && python script.py
```

Expected: Demo output printed to stdout, exit code 0.
