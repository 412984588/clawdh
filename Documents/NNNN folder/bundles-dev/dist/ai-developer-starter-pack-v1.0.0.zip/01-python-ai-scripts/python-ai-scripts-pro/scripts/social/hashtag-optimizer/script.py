#!/usr/bin/env python3
"""
Hashtag Optimizer — AI-powered hashtag research and optimization for social media.
Demo mode runs without API keys.

Usage:
  python script.py                              # demo mode
  python script.py --content "Python tutorial on FastAPI"
  python script.py --content "..." --platform instagram --count 15
  python script.py --content "..." --mix popular,niche
"""

import argparse
import os
import sys

DEMO_OUTPUT = """\
[DEMO MODE — no API key detected]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Content: "Python tutorial on building REST APIs with FastAPI"
Platform: Instagram | Target: 30 hashtags

🔥 High Volume (broad reach, more competition):
#python #programming #coding #developer #softwareengineering #tech #webdev #api

📈 Medium Volume (balanced reach):
#pythonprogramming #fastapi #webdevelopment #restapi #pythondeveloper
#backenddev #apidevelopment #learnpython

🎯 Niche (targeted, engaged audience):
#fastapitutorial #pythonbackend #apifirst #pythondev #asyncpython
#pythonframework #restapidevelopment #buildinpublic

💡 Trending (check before posting):
#100daysofcode #codelife #devlife

📋 Recommended Mix (copy-paste ready):
#python #fastapi #programming #webdevelopment #pythonprogramming
#restapi #developer #backenddev #pythondeveloper #apidevelopment
#learnpython #coding #softwareengineering #100daysofcode #buildinpublic

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Set OPENAI_API_KEY or ANTHROPIC_API_KEY to generate hashtags for real content.
"""


def call_llm(prompt: str, provider: str, model: str) -> str:
    if provider == "claude":
        import anthropic  # noqa: PLC0415
        client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        msg = client.messages.create(
            model=model, max_tokens=800,
            messages=[{"role": "user", "content": prompt}],
        )
        block = msg.content[0]
        return block.text if hasattr(block, "text") else str(block)
    else:
        import openai  # noqa: PLC0415
        client = openai.OpenAI(api_key=os.environ["OPENAI_API_KEY"])
        resp = client.chat.completions.create(
            model=model, max_tokens=800,
            messages=[
                {"role": "system", "content": "You are a social media expert specializing in hashtag strategy and discoverability."},
                {"role": "user", "content": prompt},
            ],
        )
        return resp.choices[0].message.content or ""


def main() -> None:
    parser = argparse.ArgumentParser(description="AI-powered hashtag research and optimization")
    parser.add_argument("--content", "-c", help="Post content to generate hashtags for")
    parser.add_argument("--platform", choices=["instagram", "twitter", "linkedin", "tiktok"], default="instagram",
                        help="Target platform (default: instagram)")
    parser.add_argument("--count", type=int, default=20, help="Number of hashtags to generate (default: 20)")
    parser.add_argument("--mix", default="popular,niche",
                        help="Hashtag mix strategy: popular,niche,trending (default: popular,niche)")
    parser.add_argument("--avoid", help="Comma-separated hashtags to avoid")
    parser.add_argument("--provider", choices=["openai", "claude", "auto"], default="auto")
    parser.add_argument("--model", help="Override model name")
    args = parser.parse_args()

    openai_key = os.environ.get("OPENAI_API_KEY")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")

    if not openai_key and not anthropic_key:
        print(DEMO_OUTPUT)
        return

    content = args.content or "Python programming tutorial"
    avoid_note = f"\nAvoid these hashtags: {args.avoid}" if args.avoid else ""

    prompt = (
        f"Generate {args.count} optimized hashtags for {args.platform} for this content:\n"
        f"\"{content}\"\n\n"
        f"Strategy: {args.mix} mix\n"
        f"Group them by volume: High Volume, Medium Volume, Niche, and provide a "
        f"'Recommended Mix' section with the best {min(args.count, 15)} to actually use.{avoid_note}\n"
        "Format each hashtag with # prefix. Explain the strategy briefly."
    )

    provider = "claude" if (args.provider == "claude" or (args.provider == "auto" and anthropic_key and not openai_key)) else "openai"
    model = args.model or ("claude-haiku-4-5-20251001" if provider == "claude" else "gpt-4o-mini")

    try:
        print(f"Generating hashtags for {args.platform}...\n")
        result = call_llm(prompt, provider, model)
        print("━" * 60)
        print(result)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
