# Env Checker

Validate required environment variables from `.env.example` files. Pure Python stdlib — no API key needed.

## Demo (no setup)

```bash
python script.py
# Shows sample environment check output
```

## Usage

```bash
# Check current directory
python script.py

# Check a specific project
python script.py /path/to/project

# Check specific example file
python script.py --file .env.example

# Generate .env.missing for unset variables
python script.py --fix

# Don't auto-load .env file
python script.py --no-dotenv
```

## Example Output

```
Environment Check — myproject/
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Checking .env.example...

  ✅ OPENAI_API_KEY               set (sk-...abc)
  ❌ ANTHROPIC_API_KEY            NOT SET
  ✅ DATABASE_URL                 set (pos...ql/)
  ⚠️  DEBUG                       looks like a placeholder

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Summary: 2 set, 1 missing, 1 warnings  (4 total)

❌ Missing variables:
   ANTHROPIC_API_KEY
```

## How It Works

1. Finds `.env.example`, `.env.sample`, or `.env.template` in the project
2. Auto-loads `.env` if present (unless `--no-dotenv`)
3. Checks each variable against `os.environ`
4. Masks sensitive values (shows only first/last 3 chars)
5. Flags placeholder values (`your-key-here`, `<YOUR_KEY>`, etc.)

## `--fix` Mode

Generates a `.env.missing` file with all unset variables pre-filled with their default values from the example file.

## Exit Codes

- `0` — all variables are set
- `1` — one or more variables missing
