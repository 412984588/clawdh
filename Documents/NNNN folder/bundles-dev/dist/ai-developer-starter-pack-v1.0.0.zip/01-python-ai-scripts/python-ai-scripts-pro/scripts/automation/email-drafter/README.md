# Email Drafter

> **Category:** Automation | **Deps:** openai, anthropic

Draft professional emails from a brief description or bullet points. Supports formal/casual/assertive/concise tones.

## Setup

```bash
pip install -r requirements.txt
```

Create a `.env` file or export env vars:
```
OPENAI_API_KEY=your_key_here
# or
ANTHROPIC_API_KEY=your_key_here
```

## Usage

**Demo mode** (no API key needed):
```bash
python script.py
```

**With API key:**
```bash
OPENAI_API_KEY=sk-... python script.py --context 'Follow up on proposal' --tone formal
python script.py --context '...' --to 'the client' --from-name 'John'
```

## Options

Run `python script.py --help` for all options.

## Validation

```bash
pip install -r requirements.txt && python script.py
```

Expected: Demo output printed to stdout, exit code 0.
