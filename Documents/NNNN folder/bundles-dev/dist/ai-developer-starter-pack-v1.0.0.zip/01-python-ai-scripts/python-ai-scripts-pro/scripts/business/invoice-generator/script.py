#!/usr/bin/env python3
"""
Invoice Generator — Create professional HTML invoices from JSON data.
No API key needed — pure Python, generates self-contained HTML.

Usage:
  python script.py                          # demo: generate sample invoice
  python script.py invoice.json             # generate from JSON data
  python script.py invoice.json --out invoice.html
  python script.py --open                   # auto-open in browser
"""

import argparse
import json
from datetime import date, timedelta
from pathlib import Path

SAMPLE_INVOICE = {
    "invoice_number": "INV-2026-042",
    "issue_date": "2026-03-20",
    "due_date": "2026-04-03",
    "from": {
        "name": "Acme Design Studio",
        "address": "123 Creative Ave, San Francisco, CA 94105",
        "email": "billing@acmedesign.co",
        "tax_id": "US-12-3456789",
    },
    "to": {
        "name": "TechCorp Inc.",
        "address": "456 Innovation Blvd, New York, NY 10001",
        "email": "accounts@techcorp.com",
    },
    "items": [
        {"description": "Brand Identity Design — Logo + Guidelines", "qty": 1, "rate": 2500.00},
        {"description": "Website UI Design (5 pages)", "qty": 1, "rate": 3200.00},
        {"description": "Revision Rounds", "qty": 3, "rate": 250.00},
        {"description": "Source Files Delivery", "qty": 1, "rate": 150.00},
    ],
    "tax_rate": 0.0,
    "currency": "USD",
    "notes": "Payment due within 14 days. Wire transfer or Stripe accepted.",
    "bank_details": "Bank: Chase | Account: 1234567890 | Routing: 021000021",
}

HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Invoice {invoice_number}</title>
<style>
  *{{box-sizing:border-box;margin:0;padding:0}}
  body{{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;color:#1a1a2e;background:#f0f2f5;padding:32px}}
  .page{{background:white;max-width:800px;margin:0 auto;padding:48px;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,.08)}}
  .header{{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:40px;padding-bottom:24px;border-bottom:2px solid #e5e7eb}}
  .logo{{font-size:1.4rem;font-weight:700;color:#1a1a2e}}
  .invoice-title{{text-align:right}}
  .invoice-title h1{{font-size:2rem;color:#4C72B0;font-weight:800;letter-spacing:-.02em}}
  .invoice-title p{{color:#666;font-size:.85rem;margin-top:4px}}
  .parties{{display:grid;grid-template-columns:1fr 1fr;gap:32px;margin-bottom:36px}}
  .party-label{{font-size:.72rem;text-transform:uppercase;letter-spacing:.08em;color:#999;margin-bottom:8px;font-weight:600}}
  .party-name{{font-weight:700;font-size:1rem;margin-bottom:4px}}
  .party-detail{{font-size:.85rem;color:#555;line-height:1.5}}
  table{{width:100%;border-collapse:collapse;margin-bottom:24px}}
  th{{background:#f8f9fa;text-align:left;padding:12px 16px;font-size:.78rem;text-transform:uppercase;letter-spacing:.06em;color:#666;border-bottom:2px solid #e5e7eb}}
  td{{padding:14px 16px;border-bottom:1px solid #f3f4f6;font-size:.9rem}}
  .text-right{{text-align:right}}
  .totals{{display:flex;justify-content:flex-end;margin-bottom:32px}}
  .totals-box{{min-width:260px}}
  .totals-row{{display:flex;justify-content:space-between;padding:8px 0;font-size:.9rem;border-bottom:1px solid #f3f4f6}}
  .totals-row.total{{font-weight:700;font-size:1.1rem;border-bottom:none;border-top:2px solid #1a1a2e;padding-top:12px;margin-top:4px}}
  .badge{{display:inline-block;padding:4px 12px;border-radius:20px;font-size:.75rem;font-weight:600;background:#dcfce7;color:#16a34a}}
  .notes{{background:#f8f9fa;border-radius:8px;padding:16px;margin-bottom:24px}}
  .notes-label{{font-size:.75rem;text-transform:uppercase;letter-spacing:.06em;color:#999;margin-bottom:6px;font-weight:600}}
  .notes-text{{font-size:.85rem;color:#555;line-height:1.5}}
  .footer{{text-align:center;color:#aaa;font-size:.78rem;margin-top:24px}}
</style>
</head>
<body>
<div class="page">
  <div class="header">
    <div>
      <div class="logo">{from_name}</div>
      <div style="color:#666;font-size:.82rem;margin-top:6px">{from_address}<br>{from_email}</div>
      {tax_id_line}
    </div>
    <div class="invoice-title">
      <h1>INVOICE</h1>
      <p>{invoice_number}</p>
      <div style="margin-top:12px;font-size:.85rem;color:#555">
        Issue Date: <strong>{issue_date}</strong><br>
        Due Date: <strong>{due_date}</strong><br>
        <span class="badge">Due {days_left}</span>
      </div>
    </div>
  </div>
  <div class="parties">
    <div><div class="party-label">From</div><div class="party-name">{from_name}</div><div class="party-detail">{from_address}<br>{from_email}</div></div>
    <div><div class="party-label">Bill To</div><div class="party-name">{to_name}</div><div class="party-detail">{to_address}<br>{to_email}</div></div>
  </div>
  <table>
    <thead><tr><th>Description</th><th class="text-right">Qty</th><th class="text-right">Rate</th><th class="text-right">Amount</th></tr></thead>
    <tbody>{items_rows}</tbody>
  </table>
  <div class="totals">
    <div class="totals-box">
      <div class="totals-row"><span>Subtotal</span><span>{currency} {subtotal}</span></div>
      {tax_row}
      <div class="totals-row total"><span>Total Due</span><span>{currency} {total}</span></div>
    </div>
  </div>
  {notes_block}
  <div class="footer">Thank you for your business!</div>
</div>
</body>
</html>
"""


def fmt_money(amount: float) -> str:
    return f"{amount:,.2f}"


def generate_invoice(data: dict, out_path: str) -> None:
    items = data.get("items", [])
    subtotal = sum(item["qty"] * item["rate"] for item in items)
    tax_rate = data.get("tax_rate", 0.0)
    tax_amount = subtotal * tax_rate
    total = subtotal + tax_amount
    currency = data.get("currency", "USD")

    items_rows = "".join(
        f'<tr><td>{item["description"]}</td>'
        f'<td class="text-right">{item["qty"]}</td>'
        f'<td class="text-right">{currency} {fmt_money(item["rate"])}</td>'
        f'<td class="text-right">{currency} {fmt_money(item["qty"] * item["rate"])}</td></tr>'
        for item in items
    )

    tax_row = (
        f'<div class="totals-row"><span>Tax ({tax_rate*100:.0f}%)</span><span>{currency} {fmt_money(tax_amount)}</span></div>'
        if tax_rate > 0 else ""
    )

    # 计算剩余天数
    try:
        due = date.fromisoformat(data.get("due_date", date.today().isoformat()))
        days = (due - date.today()).days
        days_left = f"in {days} days" if days > 0 else ("today" if days == 0 else f"overdue {-days}d")
    except ValueError:
        days_left = ""

    from_info = data.get("from", {})
    to_info = data.get("to", {})
    tax_id = from_info.get("tax_id", "")
    tax_id_line = f'<div style="color:#666;font-size:.82rem">Tax ID: {tax_id}</div>' if tax_id else ""

    notes = data.get("notes", "")
    bank = data.get("bank_details", "")
    notes_text = notes + (f"\n{bank}" if bank else "")
    notes_block = (
        f'<div class="notes"><div class="notes-label">Notes & Payment Details</div>'
        f'<div class="notes-text">{notes_text}</div></div>'
    ) if notes_text else ""

    html = HTML_TEMPLATE.format(
        invoice_number=data.get("invoice_number", "INV-001"),
        issue_date=data.get("issue_date", date.today().isoformat()),
        due_date=data.get("due_date", (date.today() + timedelta(days=14)).isoformat()),
        days_left=days_left,
        from_name=from_info.get("name", ""),
        from_address=from_info.get("address", "").replace("\n", "<br>"),
        from_email=from_info.get("email", ""),
        tax_id_line=tax_id_line,
        to_name=to_info.get("name", ""),
        to_address=to_info.get("address", "").replace("\n", "<br>"),
        to_email=to_info.get("email", ""),
        items_rows=items_rows,
        subtotal=fmt_money(subtotal),
        tax_row=tax_row,
        total=fmt_money(total),
        currency=currency,
        notes_block=notes_block,
    )

    Path(out_path).write_text(html, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate professional HTML invoices from JSON")
    parser.add_argument("input", nargs="?", help="JSON invoice data file (omit for demo)")
    parser.add_argument("--out", default="invoice.html", help="Output HTML file (default: invoice.html)")
    parser.add_argument("--open", action="store_true", help="Auto-open in browser")
    args = parser.parse_args()

    data = json.loads(Path(args.input).read_text(encoding="utf-8")) if args.input else SAMPLE_INVOICE
    generate_invoice(data, args.out)

    items = data.get("items", [])
    total = sum(item["qty"] * item["rate"] for item in items)
    currency = data.get("currency", "USD")
    print(f"✅ Invoice {data.get('invoice_number', '')} generated: {args.out}")
    print(f"   Total: {currency} {total:,.2f} | Due: {data.get('due_date', 'N/A')}")
    print(f"   Open in browser: file://{Path(args.out).resolve()}")

    if args.open:
        import webbrowser  # noqa: PLC0415
        webbrowser.open(f"file://{Path(args.out).resolve()}")


if __name__ == "__main__":
    main()
