#!/usr/bin/env python3
"""
API Tester — Test REST API endpoints and generate a summary report.
No API key needed — uses stdlib urllib.

Usage:
  python script.py                        # demo with public test APIs
  python script.py endpoints.json         # test from JSON config
  python script.py --url https://api.example.com/users --method GET
  python script.py endpoints.json --out report.md
"""

import argparse
import json
import sys
import time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

SAMPLE_ENDPOINTS = [
    {"name": "JSONPlaceholder Posts",  "url": "https://jsonplaceholder.typicode.com/posts/1",  "method": "GET",  "expect_status": 200},
    {"name": "JSONPlaceholder Users",  "url": "https://jsonplaceholder.typicode.com/users/1",  "method": "GET",  "expect_status": 200},
    {"name": "HTTPBin GET",            "url": "https://httpbin.org/get",                        "method": "GET",  "expect_status": 200},
    {"name": "HTTPBin Status 404",     "url": "https://httpbin.org/status/404",                 "method": "GET",  "expect_status": 404},
    {"name": "HTTPBin Delay (fast)",   "url": "https://httpbin.org/delay/1",                    "method": "GET",  "expect_status": 200, "timeout": 5},
]

STATUS_COLORS = {
    "PASS": "✅",
    "FAIL": "❌",
    "WARN": "⚠️",
    "SKIP": "⏭️",
}


def test_endpoint(endpoint: dict) -> dict:
    url = endpoint["url"]
    method = endpoint.get("method", "GET").upper()
    expected = endpoint.get("expect_status")
    timeout = endpoint.get("timeout", 10)
    headers = endpoint.get("headers", {})
    body = endpoint.get("body")

    result = {
        "name": endpoint.get("name", url),
        "url": url,
        "method": method,
        "expected_status": expected,
        "actual_status": None,
        "response_time_ms": None,
        "response_size": None,
        "error": None,
        "status": "FAIL",
    }

    req = Request(url, method=method)
    for k, v in headers.items():
        req.add_header(k, v)

    if body:
        data = json.dumps(body).encode() if isinstance(body, dict) else body.encode()
        req.data = data
        req.add_header("Content-Type", "application/json")

    start = time.monotonic()
    try:
        with urlopen(req, timeout=timeout) as resp:
            elapsed_ms = int((time.monotonic() - start) * 1000)
            content = resp.read()
            result["actual_status"] = resp.status
            result["response_time_ms"] = elapsed_ms
            result["response_size"] = len(content)
    except HTTPError as e:
        elapsed_ms = int((time.monotonic() - start) * 1000)
        result["actual_status"] = e.code
        result["response_time_ms"] = elapsed_ms
        result["error"] = str(e.reason)
    except URLError as e:
        result["error"] = str(e.reason)
        result["status"] = "FAIL"
        return result
    except TimeoutError:
        result["error"] = f"Timeout after {timeout}s"
        return result

    # 判断通过/失败
    if expected and result["actual_status"] != expected:
        result["status"] = "FAIL"
    elif result["response_time_ms"] and result["response_time_ms"] > 3000:
        result["status"] = "WARN"  # 慢响应
    else:
        result["status"] = "PASS"

    return result


def print_results(results: list[dict]) -> None:
    pass_count = sum(1 for r in results if r["status"] == "PASS")
    fail_count = sum(1 for r in results if r["status"] == "FAIL")
    warn_count = sum(1 for r in results if r["status"] == "WARN")

    print(f"\n{'━' * 70}")
    print(f"{'Endpoint':<35} {'Status':>8} {'HTTP':>6} {'Time':>8} {'Size':>8}")
    print(f"{'━' * 70}")

    for r in results:
        icon = STATUS_COLORS.get(r["status"], "?")
        http = str(r["actual_status"] or "ERR")
        time_str = f"{r['response_time_ms']}ms" if r["response_time_ms"] else "N/A"
        size_str = f"{r['response_size']}B" if r["response_size"] else "N/A"
        name = r["name"][:33]
        print(f"{name:<35} {icon} {r['status'][:4]:>4} {http:>6} {time_str:>8} {size_str:>8}")
        if r["error"] and r["status"] != "PASS":
            print(f"  {'└─ Error: ' + r['error']}")

    print(f"{'━' * 70}")
    print(f"Results: {pass_count} passed, {fail_count} failed, {warn_count} warnings  ({len(results)} total)")

    avg_time = sum(r["response_time_ms"] for r in results if r["response_time_ms"]) // max(1, sum(1 for r in results if r["response_time_ms"]))
    print(f"Avg response time: {avg_time}ms")


def main() -> None:
    parser = argparse.ArgumentParser(description="Test REST API endpoints")
    parser.add_argument("config", nargs="?", help="JSON config file with endpoints (omit for demo)")
    parser.add_argument("--url", help="Single URL to test")
    parser.add_argument("--method", default="GET", help="HTTP method (default: GET)")
    parser.add_argument("--expect", type=int, help="Expected status code")
    parser.add_argument("--out", help="Save report to file")
    args = parser.parse_args()

    if args.url:
        endpoints = [{"name": args.url, "url": args.url, "method": args.method, "expect_status": args.expect}]
    elif args.config:
        data = json.loads(Path(args.config).read_text(encoding="utf-8"))
        endpoints = data if isinstance(data, list) else data.get("endpoints", [])
    else:
        print("[Demo mode — testing public APIs (requires internet connection)]\n")
        endpoints = SAMPLE_ENDPOINTS

    print(f"Testing {len(endpoints)} endpoint(s)...")
    results = []
    for ep in endpoints:
        sys.stdout.write(f"  {ep.get('name', ep['url'])[:50]}...")
        sys.stdout.flush()
        result = test_endpoint(ep)
        icon = STATUS_COLORS.get(result["status"], "?")
        print(f" {icon}")
        results.append(result)

    print_results(results)

    if args.out:
        report_lines = [f"# API Test Report\n"]
        for r in results:
            icon = STATUS_COLORS.get(r["status"], "?")
            report_lines.append(
                f"## {r['name']}\n"
                f"- URL: `{r['url']}`\n"
                f"- Status: {icon} {r['status']}\n"
                f"- HTTP: {r['actual_status']} (expected: {r['expected_status']})\n"
                f"- Response time: {r['response_time_ms']}ms\n"
                + (f"- Error: {r['error']}\n" if r["error"] else "")
            )
        Path(args.out).write_text("\n".join(report_lines), encoding="utf-8")
        print(f"\n✅ Report saved to {args.out}")

    # 有失败则非零退出
    if any(r["status"] == "FAIL" for r in results):
        sys.exit(1)


if __name__ == "__main__":
    main()
