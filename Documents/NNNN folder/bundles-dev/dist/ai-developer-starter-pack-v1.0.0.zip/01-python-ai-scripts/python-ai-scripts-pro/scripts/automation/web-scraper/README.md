# Web Scraper + AI Summary

> **Category:** Automation | **Deps:** openai, anthropic (optional — needed for AI summary)

Fetch any URL and generate an AI summary. Works without API keys for scraping only; add a key for the AI summary.

## Setup

```bash
pip install -r requirements.txt
```

Create a `.env` file (or export env vars):
```
OPENAI_API_KEY=your_key_here
# or
ANTHROPIC_API_KEY=your_key_here
```

## Usage

**Demo mode** (no API key needed):
```bash
python script.py
```

**With API key:**
```bash
OPENAI_API_KEY=sk-... python script.py https://example.com
python script.py https://example.com --no-ai  # scrape only
```

## Options

Run `python script.py --help` for all options.

## Validation

```bash
pip install -r requirements.txt && python script.py
```

Expected: Demo output printed to stdout, exit code 0.
