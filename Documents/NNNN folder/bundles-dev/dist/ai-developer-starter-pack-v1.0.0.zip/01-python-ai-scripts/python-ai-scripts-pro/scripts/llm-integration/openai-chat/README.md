# OpenAI Chat

> **Category:** LLM Integration | **Deps:** openai

Interactive chat wrapper for OpenAI models with conversation history, streaming output, and custom system prompts.

## Setup

```bash
pip install -r requirements.txt
```

Create a `.env` file (or export env vars):
```
OPENAI_API_KEY=your_key_here
```

## Usage

**Demo mode** (no API key needed):
```bash
python script.py
```

**With API key:**
```bash
OPENAI_API_KEY=sk-... python script.py
python script.py --model gpt-4o --system 'You are a Python expert'
python script.py --once 'Explain async/await'
```

## Options

Run `python script.py --help` for all options.

## Validation

```bash
pip install -r requirements.txt && python script.py
```

Expected: Demo output printed to stdout, exit code 0.
