# Markdown Converter

> **Category:** Documents | **Deps:** openai, anthropic (optional for polish)

Convert HTML or plain text to clean Markdown. AI polishes the output for consistent formatting.

## Setup

```bash
pip install -r requirements.txt
```

Create a `.env` file or export env vars:
```
OPENAI_API_KEY=your_key_here
# or
ANTHROPIC_API_KEY=your_key_here
```

## Usage

**Demo mode** (no API key needed):
```bash
python script.py
```

**With API key:**
```bash
python script.py page.html
python script.py page.html --out page.md
python script.py notes.txt --no-ai  # convert without AI cleanup
```

## Options

Run `python script.py --help` for all options.

## Validation

```bash
pip install -r requirements.txt && python script.py
```

Expected: Demo output printed to stdout, exit code 0.
