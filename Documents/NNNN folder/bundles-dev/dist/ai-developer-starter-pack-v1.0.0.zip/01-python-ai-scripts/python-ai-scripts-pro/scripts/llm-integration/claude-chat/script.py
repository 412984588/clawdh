#!/usr/bin/env python3
"""
Claude Chat — Interactive chat wrapper for Anthropic Claude with streaming output.
Demo mode runs without API key.

Usage:
  python script.py                               # interactive chat (demo or real)
  python script.py --model claude-opus-4-6       # use specific model
  python script.py --system "You are..."         # custom system prompt
  python script.py --once "Explain Claude"       # single query
"""

import argparse
import os
import sys

DEMO_CONVERSATION = [
    ("user", "What makes Claude different from other AI assistants?"),
    ("assistant", "Claude is built by Anthropic with a focus on safety and helpfulness. "
                  "Key differentiators:\n\n"
                  "• **Constitutional AI** — trained with a 'constitution' of principles rather "
                  "than purely RLHF, making responses more reliably helpful and honest\n"
                  "• **Long context** — handles up to 200K tokens (entire codebases, long docs)\n"
                  "• **Code understanding** — strong at analyzing and generating code across "
                  "many languages\n"
                  "• **Nuanced reasoning** — tends toward careful, nuanced responses over "
                  "confident-sounding but shallow ones"),
]

DEFAULT_SYSTEM = "You are a helpful, concise assistant. Keep answers clear and to the point."
DEFAULT_MODEL = "claude-haiku-4-5-20251001"


def chat_demo() -> None:
    print("\n[DEMO MODE — set ANTHROPIC_API_KEY to use real Claude]\n")
    print("=" * 60)
    for role, content in DEMO_CONVERSATION:
        prefix = "You: " if role == "user" else "Claude: "
        print(f"\n{prefix}")
        print(content)
    print("\n" + "=" * 60)
    print("\nSet ANTHROPIC_API_KEY in your environment to start a real conversation.")


def interactive_chat(client, model: str, system: str) -> None:
    import anthropic  # noqa: PLC0415
    messages: list[dict] = []
    print(f"\nModel: {model} | Type 'quit' or Ctrl+C to exit\n")

    while True:
        try:
            user_input = input("You: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nGoodbye!")
            break

        if not user_input:
            continue
        if user_input.lower() in ("quit", "exit", "bye"):
            print("Goodbye!")
            break

        messages.append({"role": "user", "content": user_input})
        try:
            print("\nClaude: ", end="", flush=True)
            full_response = ""
            with client.messages.stream(
                model=model,
                max_tokens=1000,
                system=system,
                messages=messages,
            ) as stream:
                for text in stream.text_stream:
                    print(text, end="", flush=True)
                    full_response += text
            print("\n")
            messages.append({"role": "assistant", "content": full_response})
        except anthropic.APIError as e:
            print(f"\nAPI error: {e}", file=sys.stderr)


def main() -> None:
    parser = argparse.ArgumentParser(description="Interactive Claude chat with streaming")
    parser.add_argument("--model", default=DEFAULT_MODEL, help=f"Claude model (default: {DEFAULT_MODEL})")
    parser.add_argument("--system", default=DEFAULT_SYSTEM, help="System prompt")
    parser.add_argument("--once", metavar="QUERY", help="Single query mode (non-interactive)")
    args = parser.parse_args()

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        chat_demo()
        return

    import anthropic  # noqa: PLC0415
    client = anthropic.Anthropic(api_key=api_key)

    if args.once:
        try:
            msg = client.messages.create(
                model=args.model,
                max_tokens=1000,
                system=args.system,
                messages=[{"role": "user", "content": args.once}],
            )
            block = msg.content[0]
            print(block.text if hasattr(block, "text") else str(block))
        except Exception as exc:
            print(f"Error: {exc}", file=sys.stderr)
            sys.exit(1)
    else:
        interactive_chat(client, args.model, args.system)


if __name__ == "__main__":
    main()
