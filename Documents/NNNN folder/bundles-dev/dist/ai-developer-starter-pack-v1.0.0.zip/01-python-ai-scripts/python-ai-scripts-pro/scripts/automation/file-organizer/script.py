#!/usr/bin/env python3
"""
File Organizer — AI-powered file categorization and organization.
Analyzes filenames (and optionally content) to suggest or execute organization.
Demo mode runs without API keys.

Usage:
  python script.py                    # demo with sample filenames
  python script.py ~/Downloads        # analyze a directory (dry-run)
  python script.py ~/Downloads --move # execute the organization
"""

import argparse
import json
import os
import shutil
import sys
from pathlib import Path

SAMPLE_FILES = [
    "invoice_2026_03_acme.pdf",
    "photo_vacation_hawaii_001.jpg",
    "meeting_notes_q1_review.docx",
    "budget_2026_final.xlsx",
    "resume_john_doe_v3.pdf",
    "screenshot_2026_03_15.png",
    "contract_supplier_nda.pdf",
    "project_roadmap_v2.pptx",
    "bank_statement_march.pdf",
    "family_photo_christmas.jpg",
    "tax_return_2025.pdf",
    "video_tutorial_python.mp4",
]

DEMO_CATEGORIES = {
    "Finance": ["invoice_2026_03_acme.pdf", "budget_2026_final.xlsx",
                "bank_statement_march.pdf", "tax_return_2025.pdf"],
    "Documents": ["meeting_notes_q1_review.docx", "resume_john_doe_v3.pdf",
                  "contract_supplier_nda.pdf", "project_roadmap_v2.pptx"],
    "Photos": ["photo_vacation_hawaii_001.jpg", "screenshot_2026_03_15.png",
               "family_photo_christmas.jpg"],
    "Media": ["video_tutorial_python.mp4"],
}


def categorize_with_ai(filenames: list[str], provider: str, model: str) -> dict[str, list[str]]:
    file_list = "\n".join(f"- {f}" for f in filenames)
    prompt = (
        "Categorize these files into logical folders. "
        "Respond with JSON only: {\"FolderName\": [\"file1\", \"file2\"], ...}\n\n"
        f"Files:\n{file_list}"
    )

    raw = call_llm(prompt, provider, model)
    # JSON 提取
    import re
    match = re.search(r'\{[\s\S]*\}', raw)
    if not match:
        return {"Unsorted": filenames}
    try:
        return json.loads(match.group())
    except json.JSONDecodeError:
        return {"Unsorted": filenames}


def call_llm(prompt: str, provider: str, model: str) -> str:
    if provider == "claude":
        import anthropic  # noqa: PLC0415
        client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        msg = client.messages.create(
            model=model, max_tokens=500,
            messages=[{"role": "user", "content": prompt}],
        )
        block = msg.content[0]
        return block.text if hasattr(block, "text") else str(block)
    else:
        import openai  # noqa: PLC0415
        client = openai.OpenAI(api_key=os.environ["OPENAI_API_KEY"])
        resp = client.chat.completions.create(
            model=model, max_tokens=500,
            messages=[{"role": "user", "content": prompt}],
        )
        return resp.choices[0].message.content or ""


def print_plan(categories: dict[str, list[str]], source_dir: str | None = None, demo: bool = False) -> None:
    label = "[DEMO MODE] " if demo else ""
    print(f"\n{label}Organization Plan:")
    print("━" * 50)
    for folder, files in sorted(categories.items()):
        print(f"\n📁 {folder}/ ({len(files)} files)")
        for f in sorted(files):
            print(f"   {f}")
    total = sum(len(v) for v in categories.values())
    print(f"\nTotal: {total} files → {len(categories)} folders")
    if not demo and source_dir:
        print("\nRun with --move to execute")


def execute_move(categories: dict[str, list[str]], source_dir: Path) -> None:
    moved = 0
    for folder, files in categories.items():
        dest = source_dir / folder
        dest.mkdir(exist_ok=True)
        for filename in files:
            src = source_dir / filename
            if src.exists():
                shutil.move(str(src), str(dest / filename))
                moved += 1
    print(f"✅ Moved {moved} files into {len(categories)} folders")


def main() -> None:
    parser = argparse.ArgumentParser(description="AI-powered file organization")
    parser.add_argument("directory", nargs="?", help="Directory to organize (omit for demo)")
    parser.add_argument("--move", action="store_true", help="Execute moves (default: dry-run only)")
    parser.add_argument("--provider", choices=["openai", "claude", "auto"], default="auto")
    parser.add_argument("--model", help="Override model name")
    args = parser.parse_args()

    openai_key = os.environ.get("OPENAI_API_KEY")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")

    if not openai_key and not anthropic_key:
        print("[DEMO MODE — set OPENAI_API_KEY or ANTHROPIC_API_KEY to organize real files]")
        print_plan(DEMO_CATEGORIES, demo=True)
        return

    source_dir = Path(args.directory).expanduser() if args.directory else None
    if source_dir and not source_dir.is_dir():
        print(f"Error: {source_dir} is not a directory", file=sys.stderr)
        sys.exit(1)

    filenames = (
        [f.name for f in source_dir.iterdir() if f.is_file()]
        if source_dir else SAMPLE_FILES
    )

    if not filenames:
        print("No files found.")
        return

    provider = "claude" if (args.provider == "claude" or (args.provider == "auto" and anthropic_key and not openai_key)) else "openai"
    model = args.model or ("claude-haiku-4-5-20251001" if provider == "claude" else "gpt-4o-mini")

    try:
        print(f"Analyzing {len(filenames)} files...")
        categories = categorize_with_ai(filenames, provider, model)
        print_plan(categories, str(source_dir) if source_dir else None)

        if args.move and source_dir:
            execute_move(categories, source_dir)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
