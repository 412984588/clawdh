#!/usr/bin/env python3
"""
Web Scraper + AI Summary — Fetch web page content and generate an AI summary.
Demo mode runs without API keys (shows scraped content without AI summary).

Usage:
  python script.py                                    # demo with sample URL
  python script.py https://example.com               # scrape and summarize
  python script.py https://example.com --no-ai       # scrape only
  python script.py urls.txt --batch                  # process URL list
"""

import argparse
import os
import re
import sys
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError

SAMPLE_URL = "https://en.wikipedia.org/wiki/Python_(programming_language)"

DEMO_OUTPUT = """\
[DEMO MODE — no API key detected]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

URL: https://en.wikipedia.org/wiki/Python_(programming_language)

Scraped text (first 500 chars):
  Python is a high-level, general-purpose programming language. Its design
  philosophy emphasizes code readability, with the use of significant
  indentation. Python is dynamically typed and garbage-collected. It supports
  multiple programming paradigms, including structured, object-oriented and
  functional programming...

[AI Summary would appear here with OPENAI_API_KEY or ANTHROPIC_API_KEY set]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Set OPENAI_API_KEY or ANTHROPIC_API_KEY to enable AI summaries.
"""


def fetch_page(url: str, timeout: int = 10) -> str:
    """抓取页面 HTML，返回清理后的文本"""
    headers = {"User-Agent": "Mozilla/5.0 (compatible; PythonScraper/1.0)"}
    req = Request(url, headers=headers)
    with urlopen(req, timeout=timeout) as resp:
        html = resp.read().decode("utf-8", errors="replace")
    return clean_html(html)


def clean_html(html: str) -> str:
    """简单 HTML → 纯文本（不依赖 BeautifulSoup）"""
    # 移除 script/style 块
    html = re.sub(r'<script[^>]*>[\s\S]*?</script>', ' ', html, flags=re.IGNORECASE)
    html = re.sub(r'<style[^>]*>[\s\S]*?</style>', ' ', html, flags=re.IGNORECASE)
    # 将段落/标题标签替换为换行
    html = re.sub(r'<(p|br|h[1-6]|div|li)[^>]*>', '\n', html, flags=re.IGNORECASE)
    # 移除所有剩余标签
    html = re.sub(r'<[^>]+>', '', html)
    # 清理空白
    lines = [line.strip() for line in html.split('\n')]
    lines = [l for l in lines if l and len(l) > 10]
    return '\n'.join(lines[:200])  # 最多 200 行


def call_llm(text: str, url: str, provider: str, model: str) -> str:
    prompt = (
        f"Summarize the key information from this web page in 3-5 bullet points. "
        f"Be concise and factual.\n\nURL: {url}\n\nContent:\n{text[:3000]}"
    )
    if provider == "claude":
        import anthropic  # noqa: PLC0415
        client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        msg = client.messages.create(
            model=model, max_tokens=400,
            messages=[{"role": "user", "content": prompt}],
        )
        block = msg.content[0]
        return block.text if hasattr(block, "text") else str(block)
    else:
        import openai  # noqa: PLC0415
        client = openai.OpenAI(api_key=os.environ["OPENAI_API_KEY"])
        resp = client.chat.completions.create(
            model=model, max_tokens=400,
            messages=[{"role": "user", "content": prompt}],
        )
        return resp.choices[0].message.content or ""


def process_url(url: str, provider: str | None, model: str | None, no_ai: bool) -> None:
    print(f"\nURL: {url}")
    print("Fetching...")
    try:
        text = fetch_page(url)
        print(f"Scraped {len(text)} chars\n")
        print("Content preview:")
        print("─" * 50)
        print(text[:500])
        print("─" * 50)

        if not no_ai and provider:
            print("\nGenerating AI summary...")
            summary = call_llm(text, url, provider, model or "gpt-4o-mini")
            print("\nAI Summary:")
            print("━" * 50)
            print(summary)
    except URLError as e:
        print(f"  Fetch error: {e}", file=sys.stderr)
    except Exception as exc:
        print(f"  Error: {exc}", file=sys.stderr)


def main() -> None:
    parser = argparse.ArgumentParser(description="Web scraper with AI summary")
    parser.add_argument("url", nargs="?", help="URL to scrape (omit for demo)")
    parser.add_argument("--batch", action="store_true", help="Treat url arg as file with one URL per line")
    parser.add_argument("--no-ai", action="store_true", help="Skip AI summary, scrape only")
    parser.add_argument("--provider", choices=["openai", "claude", "auto"], default="auto")
    parser.add_argument("--model", help="Override model name")
    args = parser.parse_args()

    openai_key = os.environ.get("OPENAI_API_KEY")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")
    no_key = not openai_key and not anthropic_key

    if no_key and not args.no_ai:
        print(DEMO_OUTPUT)
        return

    provider = None
    model = None
    if not no_key and not args.no_ai:
        provider = "claude" if (args.provider == "claude" or (args.provider == "auto" and anthropic_key and not openai_key)) else "openai"
        model = args.model or ("claude-haiku-4-5-20251001" if provider == "claude" else "gpt-4o-mini")

    if args.batch and args.url:
        urls = [u.strip() for u in Path(args.url).read_text().splitlines() if u.strip()]
    else:
        urls = [args.url or SAMPLE_URL]

    for url in urls:
        process_url(url, provider, model, args.no_ai)


if __name__ == "__main__":
    main()
