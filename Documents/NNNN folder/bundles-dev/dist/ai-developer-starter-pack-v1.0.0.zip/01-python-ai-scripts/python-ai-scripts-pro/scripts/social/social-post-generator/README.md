# Social Post Generator

> **Category:** Social Media | **Deps:** openai, anthropic

Generate platform-optimized posts for Twitter, LinkedIn, Instagram, and Reddit from any content.

## Setup

```bash
pip install -r requirements.txt
```

Create a `.env` file or export env vars:
```
OPENAI_API_KEY=your_key_here
# or
ANTHROPIC_API_KEY=your_key_here
```

## Usage

**Demo mode** (no API key needed):
```bash
python script.py
```

**With API key:**
```bash
OPENAI_API_KEY=sk-... python script.py --content 'Launched new product'
python script.py --file article.md --platforms twitter,linkedin --tone professional
```

## Options

Run `python script.py --help` for all options.

## Validation

```bash
pip install -r requirements.txt && python script.py
```

Expected: Demo output printed to stdout, exit code 0.
