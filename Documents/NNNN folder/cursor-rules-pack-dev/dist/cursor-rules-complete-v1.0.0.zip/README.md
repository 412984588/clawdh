# Cursor Rules Pack

20 个精心编写的 `.cursorrules` 文件，覆盖最流行的开发框架和技术栈。

## 包含框架

| # | 框架 | 技术栈 |
|---|------|--------|
| 1 | Next.js App Router | TypeScript, Tailwind, Shadcn UI |
| 2 | Next.js + Supabase | TypeScript, SSR Auth, RLS |
| 3 | FastAPI Python | Async, Pydantic v2, SQLAlchemy 2.0 |
| 4 | React TypeScript | Vite, React Query, Zustand |
| 5 | Vue 3 + Nuxt 3 | Composition API, Pinia, Nitro |
| 6 | Django Python | DRF, Celery, PostgreSQL |
| 7 | Chrome Extension MV3 | TypeScript, Service Worker |
| 8 | Tauri + Rust | Desktop App, Rust Commands |
| 9 | Flutter + Dart | Riverpod, GoRouter, Freezed |
| 10 | Golang | Gin/Chi, Clean Architecture |
| 11 | Solidity | Hardhat, OpenZeppelin, EVM |
| 12 | AI Python ML | PyTorch, HuggingFace, LangChain |
| 13 | Node.js Express | TypeScript, Prisma, JWT |
| 14 | Svelte + SvelteKit | Svelte 5 Runes, Form Actions |
| 15 | Unity C# | MonoBehaviour, Object Pooling |
| 16 | Monorepo Turborepo | pnpm workspaces, Changesets |
| 17 | SaaS Next.js + Stripe | Subscriptions, Webhooks |
| 18 | Data Science Jupyter | pandas, scikit-learn, wandb |
| 19 | Landing Page Tailwind | SEO, CRO, Performance |
| 20 | iOS SwiftUI | SwiftData, @Observable, async/await |

## 使用方法

1. 将对应的 `.cursorrules` 文件复制到你的项目根目录
2. 在 Cursor IDE 中打开项目
3. AI 将自动按照规则提供符合框架最佳实践的代码建议

## 层级说明

- **Starter ($14)** — 10 个最流行框架的规则
- **Pro ($27)** — 全部 20 个框架规则
- **Complete ($39)** — 全部 20 个 + 框架选择指南 + 自定义模板
