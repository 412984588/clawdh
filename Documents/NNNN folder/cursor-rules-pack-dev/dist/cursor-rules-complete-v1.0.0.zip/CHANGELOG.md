# Changelog

## [1.0.0] - 2026-03-20

### Added
- 20 个 `.cursorrules` 文件，覆盖主流开发框架
- 3 个定价 tier：Starter ($14), Pro ($27), Complete ($39)
- `build_bundle.py` — 自动打包脚本
- `tests/test_rules.py` — pytest 质量验证测试
- `tiers.json` — 层级配置文件
