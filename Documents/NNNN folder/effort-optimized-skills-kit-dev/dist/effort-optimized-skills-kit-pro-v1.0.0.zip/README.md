# Effort-Optimized Skills Kit for Claude Code

**25 production-ready SKILL.md files — each pre-tuned with `effort` and `model` frontmatter.**

Your commit message generator shouldn't run at the same effort level as your security audit. This kit fixes that: every skill is configured to the right cost/quality point, with the reasoning documented so you understand why.

## The Problem

The `effort` frontmatter field shipped in Claude Code v2.1.80. It lets each skill declare its own effort level, overriding the session default. Without it, every skill runs at session default — you're overpaying for cheap tasks and potentially underpaying for critical ones.

123+ "awesome-claude-skills" repos contain zero skills with `effort` frontmatter. This kit is the first.

## Quick Start

```bash
# Install all skills (places in ~/.claude/skills/effort-kit/)
bash templates/01-skills-core/install.sh

# Use a skill
/effort-kit/commit-message
/effort-kit/security-audit-critical
```

## What's Inside

### Starter ($29) — 25 Skills + Reference

**Scout Profile** (`sonnet+low`) — fast, cheap, mechanical:
- `commit-message`, `pr-summary`, `quick-docstring`, `dependency-audit`
- `file-organizer`, `test-name-generator`, `env-setup-check`, `changelog-entry`

**Workhorse Profile** (`sonnet+high`) — development reasoning:
- `error-classifier`, `pr-review-quick`, `test-generator`, `code-explainer`
- `refactor-planner`, `debug-triage`

**Deep Work Profile** (`opus+high`) — architecture and security:
- `api-design-review`, `security-audit-standard`, `architecture-review`
- `dependency-vulnerability`, `performance-bottleneck`, `database-schema-review`

**Burst Profile** (`opus+max`) — one-shot critical analysis:
- `security-audit-critical`, `codebase-summary`, `incident-postmortem`
- `tech-debt-assessment`, `hiring-rubric-generator`

**Reference Pack:**
- Effort decision flowchart — pick the right profile in 30 seconds
- Cost calculator — see your actual monthly savings

### Pro ($49) — Everything Above Plus

- 15 domain-specific skills (Fintech × 5, DevOps × 5, Data Engineering × 5)
- 4 multi-agent orchestration templates (effort-routed subagents)
- Team deployment guide + shared `settings.json` template

## The Math

A `sonnet+low` commit message costs ~$0.003. The same task at `opus+high` (session default if you're running architecture reviews) costs ~$0.08. 20 commits/day: $1.80/month vs $48/month — for commit messages alone.

## Effort Levels

| Level | Behavior | When to Use |
|-------|----------|-------------|
| `low` | Fast, cheaper, less thorough | Mechanical tasks: commit messages, file ops |
| `medium` | Balanced (model default) | Everyday tasks |
| `high` | Deeper reasoning, higher cost | Code review, debugging, planning |
| `max` | No token cap, Opus 4.6 only | One-shot critical analysis |

`effort:` in frontmatter overrides session default for that invocation, then reverts.
`CLAUDE_CODE_EFFORT_LEVEL` env var always wins over frontmatter.

## Requirements

Claude Code v2.1.80+
