# Changelog

## [1.0.0] — 2026-03-21

### Added
- 25 production-ready SKILL.md files with `effort` and `model` frontmatter
- 4 effort profiles: Scout (sonnet+low), Workhorse (sonnet+high), Deep Work (opus+high), Burst (opus+max)
- PROFILES.md quick reference for effort level selection
- install.sh — drops all skills into ~/.claude/skills/effort-kit/ in one command
- Effort decision flowchart (Markdown, printable)
- Cost calculator worksheet with monthly savings estimate
- Pro: 15 domain-specific skills (Fintech, DevOps, Data Engineering)
- Pro: 4 multi-agent orchestration templates with effort routing
- Pro: Team deployment guide and shared settings.json template
